﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnpointNotificationLib
{
    class NotificationResponse
    {
        public string message_id { get; set; }
        //public string status_message { get; set; }
        //public MessageCode response { get; set; }
    }
}
