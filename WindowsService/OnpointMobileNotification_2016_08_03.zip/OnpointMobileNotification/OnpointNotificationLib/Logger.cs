﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnpointNotificationLib
{
    public class Logger
    {
        public bool WriteInfoToTextFile(string infoMessage, string callingFrom, string source, EventLogEntryType type)
        {
            bool Status = false;
            try
            {
                var isLoggingEnabled = ConfigurationManager.AppSettings[Constants.configKeyLogEnabled].ToString();
                if (isLoggingEnabled != null && isLoggingEnabled.Equals(Constants.stringTrue, StringComparison.CurrentCultureIgnoreCase))
                {
                    var LogDirectory = ConfigurationManager.AppSettings[Constants.logFilePath].ToString();
                    if (!string.IsNullOrEmpty(LogDirectory))
                    {
                        DateTime CurrentDateTime = DateTime.Now;
                        string CurrentDateTimeString = CurrentDateTime.ToString();
                        CheckCreateLogDirectory(LogDirectory);
                        string logLine = BuildLogLine(CurrentDateTime, infoMessage, callingFrom, source, type);
                        LogDirectory = (LogDirectory + string.Format(Constants.logFileName, LogFileName(DateTime.Now)));
                        lock (typeof(Logger))
                        {
                            StreamWriter oStreamWriter = null;
                            try
                            {
                                oStreamWriter = new StreamWriter(LogDirectory, true);
                                oStreamWriter.WriteLine(logLine);
                                Status = true;
                            }
                            catch
                            {
                            }
                            finally
                            {
                                if (oStreamWriter != null)
                                {
                                    oStreamWriter.Close();
                                }
                            }
                        }
                    }
                }
            }
            catch { }
            return Status;
        }
        private bool CheckCreateLogDirectory(string LogPath)
        {
            bool loggingDirectoryExists = false;
            DirectoryInfo oDirectoryInfo = new DirectoryInfo(LogPath);
            if (oDirectoryInfo.Exists)
            {
                loggingDirectoryExists = true;
            }
            else
            {
                try
                {
                    Directory.CreateDirectory(LogPath);
                    loggingDirectoryExists = true;
                }
                catch
                {
                }
            }
            return loggingDirectoryExists;
        }
        private string BuildLogLine(DateTime CurrentDateTime, string LogMessage, string callingFrom, string source, EventLogEntryType type)
        {
            StringBuilder loglineStringBuilder = new StringBuilder();
            loglineStringBuilder.Append(LogFileEntryDateTime(CurrentDateTime));
            loglineStringBuilder.Append(string.Format(Constants.logMessageLine, callingFrom, source, type, LogMessage));
            //loglineStringBuilder.Append("Calling From : " + callingFrom);
            //loglineStringBuilder.Append(" \t");
            //loglineStringBuilder.Append("Source : " + source);
            //loglineStringBuilder.Append(" \t");
            //loglineStringBuilder.Append("Level : " + type);
            //loglineStringBuilder.Append(" \t");
            //loglineStringBuilder.Append("Message : " + LogMessage);            
            return loglineStringBuilder.ToString();
        }
        public string LogFileEntryDateTime(DateTime CurrentDateTime)
        {
            return CurrentDateTime.ToString(Constants.dateTimeFormat);
        }
        private string LogFileName(DateTime CurrentDateTime)
        {
            return CurrentDateTime.ToString(Constants.dateFormat);
        }
        //public void Log(string infoMessage, string callingFrom, string source, Guid siteId, EventLogEntryType type)
        //{
        //    var traceSeverity = TraceSeverity.Verbose;
        //    var eventSeverity = EventSeverity.Information;
        //    var LogMessage = string.Format(Constants.threeParamString, source, callingFrom, infoMessage);
        //    var category = Constants.category;
        //    if (type == EventLogEntryType.Error)
        //    {
        //        traceSeverity = TraceSeverity.Unexpected;
        //        eventSeverity = EventSeverity.Error;
        //    }
        //    SPDiagnosticsService.Local.WriteTrace(0, new SPDiagnosticsCategory(category, traceSeverity, eventSeverity), traceSeverity, LogMessage);
        //}
    }


}
