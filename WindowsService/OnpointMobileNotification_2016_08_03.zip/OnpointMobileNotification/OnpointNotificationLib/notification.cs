﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnpointNotificationLib
{
    class Notification
    {
        public string body { get; set; }
        public string title { get; set; }
        public string sound { get; set; }
        public string click_action { get; set; }
    }
}
