﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnpointNotificationLib
{
    class DAL
    {
        string connString = string.Empty;
        Logger log = null;
        public DAL()
        {
            this.Initialize();
        }

        public void Initialize()
        {
            try
            {
                log = new Logger();
                Helperclass helperclass = new Helperclass();
                connString = connString = helperclass.CreateConnection();
            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, Constants.functNameInitialize, Constants.classNameDAL, EventLogEntryType.Error);
            }
        }
        public int ExecuteNonQuery(string procName, SqlParameter[] paramArray)
        {
            SqlConnection conn = null;
            SqlCommand cmd = null;
            int rowsAffected = 0;
            try
            {
                if (!string.IsNullOrEmpty(connString))
                {
                    conn = new SqlConnection(connString);
                    cmd = new SqlCommand();
                    cmd.Connection = conn;
                    if (paramArray != null && paramArray.Length != 0)
                    {
                        foreach (var array in paramArray)
                        {
                            cmd.Parameters.Add(array);
                        }
                    }
                    cmd.CommandText = procName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    rowsAffected = cmd.ExecuteNonQuery();
                    conn.Close();
                }
            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, Constants.functNameCallStoreProc, Constants.classNameDAL, EventLogEntryType.Error);
            }
            finally
            {
                conn.Dispose();
                cmd.Dispose();
            }
            return rowsAffected;
        }
        public DataSet CallStoreProc(string procName, SqlParameter[] paramArray)
        {
            SqlConnection conn = null;
            SqlCommand cmd = null;
            DataSet ds = null;
            SqlDataAdapter dad = null;
            try
            {

                if (!string.IsNullOrEmpty(connString))
                {
                    conn = new SqlConnection(connString);
                    cmd = new SqlCommand();
                    ds = new DataSet();
                    cmd.Connection = conn;

                    if (paramArray != null && paramArray.Length != 0)
                    {
                        foreach (var array in paramArray)
                        {
                            cmd.Parameters.Add(array);
                        }
                    }
                    cmd.CommandText = procName;
                    cmd.CommandType = CommandType.StoredProcedure;
                    dad = new SqlDataAdapter();
                    dad.SelectCommand = cmd;
                    dad.Fill(ds);
                }
            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, Constants.functNameCallStoreProc, Constants.classNameDAL, EventLogEntryType.Error);
            }
            finally
            {
                conn.Dispose();
                cmd.Dispose();
                dad.Dispose();
            }
            return ds;
        }
    }
}
