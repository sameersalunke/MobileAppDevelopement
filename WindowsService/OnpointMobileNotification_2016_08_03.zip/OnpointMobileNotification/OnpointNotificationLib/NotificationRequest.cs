﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OnpointNotificationLib
{
    class NotificationRequest
    {
        public string to { get; set; }
        public string priority { get; set; }
        public Notification notification { get; set; }
        public Data data { get; set; }
    }
}
