﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using System;
using System.Configuration;
using System.Diagnostics;
using System.IO;
using System.Web;
using System.Xml;

namespace OnpointNotificationLib
{
    class Helperclass
    {
        public string CreateConnection()
        {
            try
            {
                string connectionString = string.Empty;
                string siteUrl = Convert.ToString(ConfigurationManager.AppSettings["spSiteURL"]);
                string data = string.Empty;
                ClientContext context = new ClientContext(siteUrl);
                context.ExecutingWebRequest += clientContext_ExecutingWebRequest;
                System.Net.CredentialCache cache = new System.Net.CredentialCache();
                //cache.Add(new Uri(ConfigurationManager.AppSettings["spSiteURL"].ToString()), "NTLM",
                //            new System.Net.NetworkCredential("Administrator", "Vn24Qtu402", "AD2012.LOC"));
                //context.Credentials = new System.Net.NetworkCredential("Administrator", "Vn24Qtu402", "AD2012.LOC");// System.Net.CredentialCache.DefaultCredentials;
                Web web = context.Web;
                context.Load(web.CurrentUser);
                context.ExecuteQuery();
                string currentUser = context.Web.CurrentUser.LoginName;
                
                //var currentuser = web.CurrentUser;
                List list = web.Lists.GetByTitle(ConfigurationManager.AppSettings[Constants.onPointDataListName].ToString());
                CamlQuery camlQuery = new CamlQuery();
                camlQuery.ViewXml = "<View Scope='RecursiveAll'></View>";
                ListItemCollection listItems = list.GetItems(camlQuery);
                context.Load(listItems);
                context.ExecuteQuery();
                //SPList docLib = web.Lists[ConfigurationManager.AppSettings[Constants.onPointDataListName].ToString()];
                foreach (ListItem item in listItems)
                {
                    context.Load(item, i => i.File);
                    context.ExecuteQuery();
                    Microsoft.SharePoint.Client.File file = item.File;
                    byte[] bArray;
                    if (file != null && file.Name == ConfigurationManager.AppSettings[Constants.onPointDataConnectionFile].ToString())
                    {
                        var fileRef = file.ServerRelativeUrl;
                        var fileInfo = Microsoft.SharePoint.Client.File.OpenBinaryDirect(context, fileRef);

                        Stream stream = fileInfo.Stream;
                        byte[] buffer = new byte[16 * 1024];
                        using (MemoryStream ms = new MemoryStream())
                        {
                            int read;
                            while ((read = stream.Read(buffer, 0, buffer.Length)) > 0)
                            {
                                ms.Write(buffer, 0, read);
                            }
                            bArray = ms.ToArray();
                        }

                        data = System.Text.Encoding.UTF8.GetString(bArray, 0, bArray.Length);
                        data = data.Substring(data.IndexOf(Constants.xmlStartString));
                        XmlDocument doc = new XmlDocument();
                        doc.LoadXml(data);
                        XmlNode connStringElement = doc.GetElementsByTagName(Constants.connectString)[0];
                        connectionString = connStringElement.InnerText;
                        break;
                    }
                }
                return connectionString;
            }
            catch (Exception ex)
            {
                Logger log = new Logger();
                log.WriteInfoToTextFile(ex.Message, Constants.functionNameCreateConnection, Constants.clssNameConnHelper, EventLogEntryType.Error);
                log = null;
                throw ex;
            }
           
        }
        static void clientContext_ExecutingWebRequest(object sender, WebRequestEventArgs e)
        {
            try
            {
                e.WebRequestExecutor.WebRequest.Headers.Add("X-FORMS_BASED_AUTH_ACCEPTED", "f");
            }
            catch
            { throw; }

        }
    }
}
