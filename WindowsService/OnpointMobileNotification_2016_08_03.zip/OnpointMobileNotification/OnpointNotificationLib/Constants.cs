﻿
namespace OnpointNotificationLib
{
    public static class Constants
    {
        //Messages
        public static string notificationAlert = "Site: {0}, Needs your immediate attention";
        public static string notificationFilter = "/topics/{0}";
        public static string high = "high";
        public static string soundDefault = "default";
        public static string titleBioclinica = "New Event";
        public static string clickActionValue = "FCM_PLUGIN_ACTIVITY";
        //Connection Helper Class
        public static string connectString = "ConnectString";
        public static string xmlStartString = "<?xml";
        public static string functionNameCreateConnection = "CreateConnection";
        public static string clssNameConnHelper = "ConnectionHelper";

        //Logger Class        
        public static string stringTrue = "true";
        public static string stringFalse = "false";
        public static string logFileName = "\\NotificationServiceLog_{0}.txt";
        public static string logMessageLine = " \tCalling From : {0}  \tSource : {1}  \tLevel : {2} \tMessage : {3}";
        public static string dateTimeFormat = "dd-MM-yyyy HH:mm:ss";
        public static string dateFormat = "dd_MMM_yyyy";
        public static string threeParamString = "{0},{1},{2}";
        public static string category = "OnPoint";

        //DAL class
        public static string classNameDAL = "DAL";
        public static string classNameOnpointNotificationDll = "OnpointNotificationDll";
        public static string functNameInitialize = "Initialize";
        public static string functNameCallStoreProc = "CallStoreProc";
        public static string functNameCheckNewSAEs = "CheckNewSAEs";

        //sql Parameters        
        public static string sqlParamStatus = "Status";
        public static string sqlParamMessageId = "MessageId";
        public static string sqlParamErrorMessage = "ErrorMessage";
        public static string sqlParamUserName = "userName";
        
        //GetSAEDetails        
        public static string spGetNewSAEs = "[Mobile.SPGetNewSAEs]";
        public static string spUpdateSAENotification = "[Mobile.SPUpdateSAENotification]";

        //Table Columns
        public static string title = "Title";
        public static string id = "ID";
        public static string linkedStudy = "Linked Study";
        public static string linkedSite = "Linked Site";
        public static string UserName = "UserName";
        public static string AccountId = "AccountId";

        //Config AppSetting Keys        
        public static string logFilePath = "LogFilePath";
        public static string configKeyLogEnabled = "LogEnabled";
        public static string onPointDataListName = "OnPointDataListName";
        public static string onPointDataConnectionFile = "OnPointDataConnectionFile";
        public static string ApplicationId = "ApplicationId";
        public static string ApiKey = "ApiKey";
        public static string IonicPushURL = "IonicPushURL";

        public static string POST = "POST";
        //public static string ContentTypeKey = "Content-Type";
        public static string AuthorizationHeader = "Authorization";
        public static string ApplicationIdHeader = "X-Ionic-Application-Id";
        public static string AuthorizationValue = "key={0}";
        public static string jsonContentType = "application/Json";
        

    }
}
