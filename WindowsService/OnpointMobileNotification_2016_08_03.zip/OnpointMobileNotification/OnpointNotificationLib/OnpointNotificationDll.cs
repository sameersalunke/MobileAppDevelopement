﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace OnpointNotificationLib
{
    public class OnpointNotificationDll
    {
        DAL dal = null;
        Logger log = null;
        public OnpointNotificationDll()
        {
            dal = new DAL();
            log = new Logger();
        }
        public void CheckNewSAEs()
        {
            try
            {
                DataSet ds = dal.CallStoreProc(Constants.spGetNewSAEs, null);
                if (ds != null && ds.Tables.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        string notificationAlert = string.Format(Constants.notificationAlert, dr[Constants.linkedSite]);
                        string saeId = dr[Constants.id].ToString();
                        string AccountId = dr[Constants.AccountId].ToString(); //"904ef048-3697-478c-a986-98a897c32768";
                        string jsonNotificationRequest = CreateNotificationRequestBody(notificationAlert, AccountId,saeId);
                        string result = CallNotificationService(jsonNotificationRequest);
                        if (result != null)
                        {
                            ProcessNotificationResponse(result, dr);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, Constants.functNameCheckNewSAEs, Constants.classNameOnpointNotificationDll, EventLogEntryType.Error);
            }
        }
        public string CallNotificationService(string jsonNotificationRequest)
        {
            string result = null;
            HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(ConfigurationManager.AppSettings[Constants.IonicPushURL].ToString());
            httpWebRequest.Method = Constants.POST;
            httpWebRequest.ContentType = Constants.jsonContentType;
            //httpWebRequest.Headers.Add(Constants.ContentTypeKey,Constants.jsonContentType);
            httpWebRequest.Headers.Add(Constants.AuthorizationHeader,
                                       string.Format(Constants.AuthorizationValue, ConfigurationManager.AppSettings[Constants.ApplicationId].ToString()));
            //httpWebRequest.Credentials = CredentialCache.DefaultCredentials;
            httpWebRequest.ContentLength = jsonNotificationRequest.Length;

            using (StreamWriter streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                streamWriter.Write(jsonNotificationRequest);
            }
            try
            {
                using (var reader = new StreamReader(httpWebRequest.GetResponse().GetResponseStream()))
                {
                    result = reader.ReadToEnd();
                }
            }
            catch (WebException ex)
            {
                if (ex.Response != null)
                {
                    using (var errorResponse = (HttpWebResponse)ex.Response)
                    {
                        using (var reader = new StreamReader(errorResponse.GetResponseStream()))
                        {
                            result = reader.ReadToEnd();
                        }
                    }
                }
            }
            return result;
        }
        public void ProcessNotificationResponse(string response,DataRow dr)
        {            
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            NotificationResponse responseBody = new NotificationResponse();
            try
            {
                responseBody = serializer.Deserialize<NotificationResponse>(response);
            }
            catch
            {   
            }
            
            SqlParameter[] paramArray;       
            
            if (responseBody.message_id != null)
            {
                paramArray = new SqlParameter[4];
                paramArray[0] = new SqlParameter(Constants.id, dr[Constants.id].ToString());
                paramArray[1] = new SqlParameter(Constants.sqlParamStatus,true);
                paramArray[2] = new SqlParameter(Constants.sqlParamUserName, dr[Constants.UserName].ToString());
                paramArray[3] = new SqlParameter(Constants.sqlParamMessageId, responseBody.message_id);
            }
            else
            {
                paramArray = new SqlParameter[3];
                paramArray[0] = new SqlParameter(Constants.id, dr[Constants.id].ToString());
                paramArray[1] = new SqlParameter(Constants.sqlParamStatus, false);
                paramArray[2] = new SqlParameter(Constants.sqlParamErrorMessage, response);
            }
            dal.ExecuteNonQuery(Constants.spUpdateSAENotification, paramArray);
        }
        public string CreateNotificationRequestBody(string notificationAlert, string AccountId, string saeId)
        {
            NotificationRequest notificationRequest = new NotificationRequest();
            notificationRequest.to = string.Format(Constants.notificationFilter,
                // ConfigurationManager.AppSettings[Constants.ApplicationId].ToString(),
                                                                       AccountId.ToLower());
            notificationRequest.priority = Constants.high; //ConfigurationManager.AppSettings[Constants.ApiKey].ToString();
            notificationRequest.notification = new Notification();
            notificationRequest.notification.body = notificationAlert;

            notificationRequest.notification.sound = Constants.soundDefault;// DateTime.Now.ToString("u").Replace("Z", ""); 
            notificationRequest.notification.title = Constants.titleBioclinica;
            notificationRequest.notification.click_action = Constants.clickActionValue;

            notificationRequest.data = new Data();
            notificationRequest.data.saeid = saeId;
            notificationRequest.data.body = Constants.titleBioclinica;
            notificationRequest.data.title = notificationAlert;
            
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Serialize(notificationRequest);
        }
    }
}
