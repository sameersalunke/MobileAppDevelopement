﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OnpointNotificationLib
{
    class Data
    {
        public string saeid { get; set; }
        public string body { get; set; }
        public string title { get; set; }
    }
}
