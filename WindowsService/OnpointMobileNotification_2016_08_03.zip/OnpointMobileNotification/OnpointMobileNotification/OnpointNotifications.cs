﻿using OnpointNotificationLib;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace OnpointMobileNotification
{
    public partial class OnpointNotifications : ServiceBase
    {
        System.Timers.Timer timer = null;
        OnpointNotificationDll objNotification = null;
        internal static volatile bool isRunning;
        Logger log = null;
        public OnpointNotifications()
        {
            try
            {
                InitializeComponent();
                timer = new System.Timers.Timer();
                objNotification = new OnpointNotificationDll();
                timer.Interval = Convert.ToDouble(ConfigurationManager.AppSettings["TimeInterval"]) * 60000;  // 60 seconds
                timer.Elapsed += new System.Timers.ElapsedEventHandler(this.OnTimerExecuting);
                log = new Logger();
            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, "OnpointNotifications", "OnpointNotifications", EventLogEntryType.Error);
            }
            
        }

        protected override void OnStart(string[] args)
        {
            timer.Start();
        }
        protected void OnTimerExecuting(object sender, System.Timers.ElapsedEventArgs args)
        {
            if (isRunning) return;
            isRunning = true;
            try
            {
                objNotification.CheckNewSAEs();
            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, "OnTimerExecuting", "OnpointNotifications", EventLogEntryType.Error);
            }
            finally { isRunning = false; }  
        }
        protected override void OnStop()
        {
            timer.Stop();
        }
    }
}
