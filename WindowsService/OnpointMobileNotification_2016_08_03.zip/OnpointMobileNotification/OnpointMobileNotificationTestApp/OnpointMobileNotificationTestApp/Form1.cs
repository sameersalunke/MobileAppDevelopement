﻿using System;
using System.Configuration;
using System.Windows.Forms;
using OnpointNotificationLib;
namespace OnpointMobileNotificationTestApp
{
    public partial class Form1 : Form
    {
        System.Timers.Timer timer = null;
        OnpointNotificationDll objNotification = null;
        internal static volatile bool isRunning;
        public Form1()
        {
            InitializeComponent();
            timer = new System.Timers.Timer();
            objNotification = new OnpointNotificationDll();
            timer.Interval = Convert.ToDouble(ConfigurationManager.AppSettings["TimeInterval"]) * 60000;  // 60 seconds
            timer.Elapsed += new System.Timers.ElapsedEventHandler(this.OnTimerExecuting);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {            
            timer.Start();
        }
        protected void OnTimerExecuting(object sender, System.Timers.ElapsedEventArgs args)
        {
            if (isRunning) return;
            isRunning = true;
            try
            {
                objNotification.CheckNewSAEs();
            }
            catch (Exception)
            {
                
            }
            finally { isRunning = false; }  
            
        }
        private void btnStop_Click(object sender, EventArgs e)
        {
            timer.Stop();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
