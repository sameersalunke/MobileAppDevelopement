SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Mobile_NewSAE]') AND type in (N'U'))
BEGIN

CREATE TABLE [dbo].[Mobile_NewSAE](
	[Object ID] [uniqueidentifier] NOT NULL,
	[SAE ID] [uniqueidentifier] NOT NULL,
	[Status] [bit] NOT NULL,
	[NotificationSentTo] [varchar](100) NULL,
	[MessageId] [varchar](50) NULL,
	[ErrorMessage] [varchar](max) NULL,
	[CreatedDate] [datetime] NOT NULL,
	[ModifiedDate] [datetime] NOT NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
SET ANSI_PADDING OFF
ALTER TABLE [dbo].[Mobile_NewSAE] ADD  CONSTRAINT [DF_Mobile_NewSAE_Status]  DEFAULT ((0)) FOR [Status]

END

GO






