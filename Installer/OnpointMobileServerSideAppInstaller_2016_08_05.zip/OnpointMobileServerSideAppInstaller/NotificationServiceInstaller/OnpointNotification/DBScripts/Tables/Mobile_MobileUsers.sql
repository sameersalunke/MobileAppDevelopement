/****** Object:  Table [dbo].[Mobile_MobileUsers]    Script Date: 6/19/2016 10:50:32 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Mobile_MobileUsers]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Mobile_MobileUsers](
	[Object ID] [uniqueidentifier] NOT NULL,
	[Account ID] [uniqueidentifier] NOT NULL,
	[OnpointUserID] [varchar](50) NOT NULL,
	[Active] [bit] NOT NULL,
 CONSTRAINT [PK_Mobile_MobileUsers] PRIMARY KEY CLUSTERED 
(
	[Object ID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
SET ANSI_PADDING OFF

ALTER TABLE [dbo].[Mobile_MobileUsers] ADD  CONSTRAINT [DF_Mobile_MobileUsers_Active]  DEFAULT ((1)) FOR [Active]

END

GO





