IF EXISTS (SELECT * FROM sys.triggers WHERE object_id = OBJECT_ID(N'[dbo].[trg_insert_SAE]'))
DROP TRIGGER [dbo].[trg_insert_SAE]
go

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [dbo].[trg_insert_SAE] 
	ON [dbo].[Data_217A27C5_C634_45DE_A795_A323517DCA69]
	AFTER INSERT
AS 
insert into Mobile_NewSAE([Object ID],[SAE ID],[CreatedDate],[ModifiedDate]) select NEWID(),i.ObjectID,GETDATE(),GETDATE()
from inserted i
GO


