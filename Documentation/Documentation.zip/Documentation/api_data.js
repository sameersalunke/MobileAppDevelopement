define({ "api": [
  {
    "type": "post",
    "url": "UpdateData.svc/ActionItem",
    "title": "Updating Action Items",
    "name": "UpdateActionItem",
    "group": "ActionItem",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Cookie",
            "description": "<p>FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>application/json</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "ID",
            "description": "<p>Unique GUID of Action Item</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "Description",
            "description": "<p>Comments to be updated</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "Percent_Complete",
            "description": "<p>Completion status in boolean value</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\n  \"ID\":\"cbf1406c-43be-4515-a1a3-07877e54db2f\",\n  \"Percent_Complete\":\"0\",\n  \"Description\":\"Follow-up on the waiver for this site's protocol deviation DEV-00001\",\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "errorMessage",
            "description": "<p>If error occurs its description comes here</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "result",
            "description": "<p>In case of success message you get Guid here</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "success",
            "description": "<p>True or false in case of success or failure respectively</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "\n{\n \"errorMessage\": null,\n \"result\": \"fc4fd955-08eb-4a53-b88b-fec6dff5e66c\",\n \"success\": \"true\"\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "\n{\n     \"errorMessage\": \"ID can not be null or blank\",\n     \"result\": null,\n     \"success\": \"false\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./UpdateData.svc.cs",
    "groupTitle": "ActionItem"
  },
  {
    "type": "get",
    "url": "ListData.svc/ActionItems",
    "title": "Listing Action Items",
    "name": "ActionItems",
    "group": "ActionItems",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Cookie",
            "description": "<p>FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Accept",
            "description": "<p>'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "top",
            "description": "<p>Query string param to select top records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "skip",
            "description": "<p>Query string param to skip number of records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "orderby",
            "description": "<p>Query string param to sort records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "filter",
            "description": "<p>Query string param to apply filter.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "/ActionItems?$top=10&$skip=20                                                //For Paging\n/ActionItems?$orderby=Title                                                  //For Sorting\n/ActionItems?$filter=ID eq '93675ca8-0941-487f-afb3-0451c1e28eed'            //For Filter",
        "type": "json"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Task_Name",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "ID",
            "description": "<p>Unique Id of Action Item</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Action_Item_Deviation_Number",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Start_Date",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Due_Date",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Assigned_To",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Assigned_To_Id",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Percent_Complete",
            "description": "<p>Action Item Completion Status</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Description",
            "description": "<p>Action Item Comments</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Action_Item_Deviation_Category",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Action_Item_Created_By",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Study",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Site",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Visit",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "AIRRecs_Linked_Visit",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Assigned_Monitor",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n {\n      \"d\":[\n              {\n                  \"__metadata\":{\n                  \"uri\":\"https://op34110-portal.bioclinica.com/_vti_bin/anonsvc/MobileAPI/ListData.svc/ActionItems('9d78306f-1826-42ef-89c7-8f01a1040687')\",\n                  \"type\":\"MobileAppWCF.Models.ActionItems\"\n                  },\n                  \"Task_Name\":\"File IRB approval of Protocol Amendment 2\",\n                  \"ID\":\"9d78306f-1826-42ef-89c7-8f01a1040687\",\n                  \"Action_Item_Deviation_Number\":\"AIT-00011\",\n                  \"Start_Date\":\"2008-05-23T00:00:00Z\",\n                  \"Due_Date\":\"2008-05-23T00:00:00Z\",\n                  \"Assigned_To\":\"Clinical Administrator\",\n                  \"Assigned_To_Id\":\" 1B0F355E-E267-4569-9DB8-06185782311A, 5FCBDDED-C6B6-43BA-95DA-CF6A35822588\",\n                  \"Status\":\"0\",\n                  \"Description\":\"File IRB approval of Protocol Amendment 2 upon its receipt (pending, it was submitted 6/02/08), per IRB \",\n                  \"Action_Item_Deviation_Category\":\"Protocol Deviation\",\n                  \"Action_Item_Created_By\":\"3f8a4442-9e8f-4f6a-825c-455acf8ca593\",\n                  \"Linked_Study\":\"SDY-001\",\n                  \"Linked_Site\":\"003\",\n                  \"Linked_Visit\":\"VIS-00003\",\n                  \"AIRRecs_Linked_Visit\":\"fbb69daa-5dac-48d6-a0a6-0ab6c955814b\",\n                  \"Linked_Assigned_Monitor\":\"Rehm, Jeremiah\"\n              }\n          ]\n }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./ListData.svc.cs",
    "groupTitle": "ActionItems"
  },
  {
    "type": "get",
    "url": "ListData.svc/OnpointUser",
    "title": "Onpoint User Account Details",
    "name": "OnpointUser",
    "group": "OnpointUser",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Cookie",
            "description": "<p>FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Accept",
            "description": "<p>'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "top",
            "description": "<p>Query string param to select top records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "skip",
            "description": "<p>Query string param to skip number of records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "orderby",
            "description": "<p>Query string param to sort records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "filter",
            "description": "<p>Query string param to apply filter.</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "ID",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "OnpointUserName",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n  {\n      \"d\" : [\n              {\n                 \"__metadata\": {\n                        \"uri\": \"https://op34110-portal.bioclinica.com/_vti_bin/anonsvc/MobileAPI/ListData.svc/OnpointUser('904ef048-3697-478c-a986-98a897c32768')\", \"type\": \"MobileAppWCF.Models.UserDetails\"\n                  }, \"OnpointUserName\": \"jrehm\", \"ID\": \"904ef048-3697-478c-a986-98a897c32768\"\n              }\n            ]\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./ListData.svc.cs",
    "groupTitle": "OnpointUser"
  },
  {
    "type": "post",
    "url": "UpdateData.svc/ProtocolDeviation",
    "title": "Updating Protocol Deviation",
    "name": "UpdateProtocolDeviation",
    "group": "ProtocolDeviation",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Cookie",
            "description": "<p>FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>application/json</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "ID",
            "description": "<p>Unique GUID of Protocol Deviation</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "New_Comment",
            "description": "<p>Comments to be updated</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "Resolution",
            "description": "<p>Resolution for the deviation</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\"ID\":\"2984f2cb-87f8-4e0c-8b94-8dbe7905e680\",\"New_Comment\":\"Some New Comment Here\",\"Resolution\":\"Some Resolution\"}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "errorMessage",
            "description": "<p>If error occurs its description comes here</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "result",
            "description": "<p>In case of success message you get Guid here</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "success",
            "description": "<p>True or false in case of success or failure respectively</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "\n{\n \"errorMessage\": null,\n \"result\": \"fc4fd955-08eb-4a53-b88b-fec6dff5e66c\",\n \"success\": \"true\"\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "\n{\n     \"errorMessage\": \"ID can not be null or blank\",\n     \"result\": null,\n     \"success\": \"false\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./UpdateData.svc.cs",
    "groupTitle": "ProtocolDeviation"
  },
  {
    "type": "get",
    "url": "ListData.svc/ProtocolDeviations",
    "title": "Listing Protocol Deviations",
    "name": "ProtocolDeviations",
    "group": "ProtocolDeviations",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Cookie",
            "description": "<p>FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Accept",
            "description": "<p>'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "top",
            "description": "<p>Query string param to select top records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "skip",
            "description": "<p>Query string param to skip number of records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "orderby",
            "description": "<p>Query string param to sort records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "filter",
            "description": "<p>Query string param to apply filter.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "/ProtocolDeviations?$top=10&$skip=20                                                //For Paging\n/ProtocolDeviations?$orderby=Title                                                  //For Sorting\n/ProtocolDeviations?$filter=ID eq '93675ca8-0941-487f-afb3-0451c1e28eed'            //For Filter",
        "type": "json"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Title",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "ID",
            "description": "<p>Unique Id of Protocol Deviation</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Modified_Date",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Site",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Study",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Visit",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Screening",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Deviation_Number",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Deviation_Date",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Description",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Deviation_Submitted_to_IRB",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Deviation_CRA_Reviewer",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Deviation_Category",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Deviation_Planned",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Deviation_Protocol_Section_Reference",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Deviation_Date_Signed",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Deviation_Signed_By",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Deviation_Comments",
            "description": "<p>We get Deviation Comments at this field</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Send_Notification_to_Investigator",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "New_Comment",
            "description": "<p>New comments to be sent through this field and that then gets appended to Deviation_Comments</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Resolution",
            "description": "<p>Resolution to Deviation</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n  {\n      \"d\":[\n              {\n                  \"__metadata\":{\n                  \"uri\":\"https://uvo1m9f8ggv60cbfnu3.env.cloudshare.com/_vti_bin/anonsvc/MobileAPI/ListData.svc/ProtocolDeviations('91a45753-495b-444e-b4e8-5b6471118b98')\",\n                  \"type\":\"MobileAppWCF.Models.ProtocolDeviation\"\n                  },\n                  \"Title\":\"DEV-00010 - Inclusion/Exclusion Criteria\",\n                  \"ID\":\"91a45753-495b-444e-b4e8-5b6471118b98\",\n                  \"Modified_Date\":\"2016-07-28T07:53:04Z\",\n                  \"Linked_Site\":\"002\",\n                  \"Linked_Study\":\"SDY-005\",\n                  \"Linked_Visit\":\"VIS-00006\",\n                  \"Linked_Screening\":\"002-009\",\n                  \"Deviation_Number\":\"DEV-00010\",\n                  \"Deviation_Date\":\"2016-07-14T00:00:00Z\",\n                  \"Description\":\"Inclusion/Exclusion Criteria\",\n                  \"Deviation_Submitted_to_IRB\":\"False\",\n                  \"Deviation_CRA_Reviewer\":\"CRA2 CRA2\",\n                  \"Deviation_Category\":\"Waiver\",\n                  \"Deviation_Planned\":\"True\",\n                  \"Deviation_Protocol_Section_Reference\":\"as\",\n                  \"Deviation_Date_Signed\":\"\",\n                  \"Deviation_Signed_By\":\"\",\n                  \"Deviation_Comments\":\"28Jul2016 00:53 [jrehm]: MyNewComm\\r\\n19Jul2016 09:15 [cra1]: First comment\",\n                  \"Send_Notification_to_Investigator\":\"False\",\n                  \"New_Comment\":\"\",\n                  \"Resolution\":\"dsad\"\n              }\n          ]\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./ListData.svc.cs",
    "groupTitle": "ProtocolDeviations"
  },
  {
    "type": "get",
    "url": "ListData.svc/SAEDetails",
    "title": "Listing SAE records",
    "name": "GetSAEDetails",
    "group": "SAE",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Cookie",
            "description": "<p>FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Accept",
            "description": "<p>'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "top",
            "description": "<p>Query string param to select top records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "skip",
            "description": "<p>Query string param to skip number of records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "orderby",
            "description": "<p>Query string param to sort records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "filter",
            "description": "<p>Query string param to apply filter.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "/SAEDetails?$top=10&$skip=20                                                //For Paging\n/SAEDetails?$orderby=Title                                                  //For Sorting\n/SAEDetails?$filter=ID eq '93675ca8-0941-487f-afb3-0451c1e28eed'            //For Filter",
        "type": "json"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Date_Reported_to_Product_Container",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Date_Reported_to_IRB",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Date_Site_Notified",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Event_Grade",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "ID",
            "description": "<p>Unique ID for SAE Record.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "IRB_Notified",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Monitoring_Visit",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Screening",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Site",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Study",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Recorded_on_AE_Log",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Report_Type",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "SAE_Comments",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "SAE_Description",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "SAE_Number",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "SAE_Onset_Date",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "SAE_Reported_Term",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Title",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Was_SAE_Expected",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n{\n  \"d\":[\n          {\n              \"__metadata\":{\n                              \"uri\":\"https://uvo1m9f8ggv60cbfnu3.env.cloudshare.com/_vti_bin/anonsvc/MobileAPI/ListData.svc/SAEDetails('069cadd1-976b-49ac-9b29-14e6ca313a7d')\",\n                              \"type\":\"MobileAppWCF.Models.SAEDetails\"\n                           },\n              \"Title\":\"SAE-00006\",\n              \"ID\":\"069cadd1-976b-49ac-9b29-14e6ca313a7d\",\n              \"SAE_Number\":\"SAE-00006\",\n              \"SAE_Onset_Date\":\"2016-07-15T00:00:00Z\",\n              \"SAE_Reported_Term\":\"\",\n              \"Date_Site_Notified\":\"2016-07-21T00:00:00Z\",\n              \"Date_Reported_to_Product_Container\":\"2016-07-20T00:00:00Z\",\n              \"IRB_Notified\":\"\",\n              \"Date_Reported_to_IRB\":\"2016-07-12T00:00:00Z\",\n              \"Recorded_on_AE_Log\":\"True\",\n              \"Was_SAE_Expected\":\"True\",\n              \"Report_Type\":\"Routine\",\n              \"Event_Grade\":\"3 (Severe)\",\n              \"SAE_Description\":\"\",\n              \"SAE_Comments\":\"Test sam\",\n              \"Linked_Study\":\"SDY-005\",\n              \"Linked_Site\":\"002\",\n              \"Linked_Monitoring_Visit\":\"VIS-00011\",\n              \"Linked_Screening\":\"002-003\"\n          }\n      ]\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./ListData.svc.cs",
    "groupTitle": "SAE"
  },
  {
    "type": "post",
    "url": "UpdateData.svc/SAEDetail",
    "title": "Updating SAE Comments",
    "name": "UpdateSAEDetail",
    "group": "SAE",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Cookie",
            "description": "<p>FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>application/json</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "ID",
            "description": "<p>Unique GUID of SAE Record.</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "SAE_Comments",
            "description": "<p>Comments to be updated.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\"ID\":\"fc4fd955-08eb-4a53-b88b-fec6dff5e66c\",\"SAE_Comments\":\"This case was withdrawn because it is not a reportable event.\"}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "errorMessage",
            "description": "<p>If error occurs its description comes here</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "result",
            "description": "<p>In case of success message you get Guid here</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "success",
            "description": "<p>True or false in case of success or failure respectively</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "\n{\n \"errorMessage\": null,\n \"result\": \"fc4fd955-08eb-4a53-b88b-fec6dff5e66c\",\n \"success\": \"true\"\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "\n{\n     \"errorMessage\": \"ID can not be null or blank\",\n     \"result\": null,\n     \"success\": \"false\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./UpdateData.svc.cs",
    "groupTitle": "SAE"
  },
  {
    "type": "post",
    "url": "UpdateData.svc/SiteVisit",
    "title": "Updating Site Visit",
    "name": "UpdateSiteVisit",
    "group": "SiteVisit",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Cookie",
            "description": "<p>FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Content-Type",
            "description": "<p>application/json</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "ID",
            "description": "<p>Unique GUID of Site Visit</p>"
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "Start_Date",
            "description": ""
          },
          {
            "group": "Parameter",
            "type": "string",
            "optional": false,
            "field": "End_Date",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Request-Example:",
          "content": "{\"ID\":\"3a0cb59d-c64e-4a53-9f9e-03b39a52808f\",\"Start_Date\":\"7\\/16\\/2008 12:00:00 AM\",\"End_Date\":\"7\\/18\\/2008 12:00:00 AM\"}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "errorMessage",
            "description": "<p>If error occurs its description comes here</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "result",
            "description": "<p>In case of success message you get Guid here</p>"
          },
          {
            "group": "Success 200",
            "type": "string",
            "optional": false,
            "field": "success",
            "description": "<p>True or false in case of success or failure respectively</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "\n{\n \"errorMessage\": null,\n \"result\": \"fc4fd955-08eb-4a53-b88b-fec6dff5e66c\",\n \"success\": \"true\"\n }",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "\n{\n     \"errorMessage\": \"ID can not be null or blank\",\n     \"result\": null,\n     \"success\": \"false\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./UpdateData.svc.cs",
    "groupTitle": "SiteVisit"
  },
  {
    "type": "get",
    "url": "ListData.svc/SiteVisits",
    "title": "Listing Site Visits",
    "name": "SiteVisits",
    "group": "SiteVisits",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Cookie",
            "description": "<p>FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "top",
            "description": "<p>Query string param to select top records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "skip",
            "description": "<p>Query string param to skip number of records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "orderby",
            "description": "<p>Query string param to sort records.</p>"
          },
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "filter",
            "description": "<p>Query string param to apply filter.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "/SiteVisits?$top=10&$skip=20                                                //For Paging\n/SiteVisits?$orderby=Title                                                  //For Sorting\n/SiteVisits?$filter=ID eq '93675ca8-0941-487f-afb3-0451c1e28eed'            //For Filter",
        "type": "json"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Title",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "ID",
            "description": "<p>Unique Id of SiteVisits</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Start_Date",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "End_Date",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "All_Day_Event",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Monitoring_Visit_Number",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Monitoring_Visit_status",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Visit_Type",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Assigned_To",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Study",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Site",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Linked_Monitor",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "Location",
            "description": ""
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n  {\n      \"d\":[\n              {\n                  \"__metadata\":{\n                  \"uri\":\"https://uvo1m9f8ggv60cbfnu3.env.cloudshare.com/_vti_bin/anonsvc/MobileAPI/ListData.svc/SiteVisits('3a0cb59d-c64e-4a53-9f9e-03b39a52808f')\",\n                  \"type\":\"MobileAppWCF.Models.SiteVisit\"\n                  },\n                  \"Title\":\"VIS-00005 (SMV): 001 - Rehm\",\n                  \"ID\":\"3a0cb59d-c64e-4a53-9f9e-03b39a52808f\",\n                  \"Start_Date\":\"2016-07-30T00:00:00Z\",\n                  \"End_Date\":\"2016-08-04T00:00:00Z\",\n                  \"All_Day_Event\":\"True\",\n                  \"Monitoring_Visit_Number\":\"VIS-00005\",\n                  \"Monitoring_Visit_status\":\"Planned\",\n                  \"Visit_Type\":\"SMV\",\n                  \"Assigned_To\":\"Rehm, Jeremiah\",\n                  \"Linked_Study\":\"SDY-005\",\n                  \"Linked_Site\":\"001\",\n                  \"Linked_Monitor\":\"Rehm, Jeremiah\",\n                  \"Location\":\"1959 NE Pacific, Suite 250, Seattle 98195, Phone: 206-555-5555, Fax: 206-555-5556\"\n              }\n         ]\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./ListData.svc.cs",
    "groupTitle": "SiteVisits"
  },
  {
    "type": "get",
    "url": "ListData.svc/Sites",
    "title": "Listing SAE records",
    "name": "Sites",
    "group": "Sites",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Cookie",
            "description": "<p>FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Accept",
            "description": "<p>'application/json'</p>"
          }
        ]
      }
    },
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "String",
            "optional": false,
            "field": "StudyId",
            "description": "<p>Linked study to serch sites.</p>"
          }
        ]
      }
    },
    "examples": [
      {
        "title": "Example usage:",
        "content": "https://uvo1m9f8ggv60cbfnu3.env.cloudshare.com/_vti_bin/anonsvc/MobileAPI/ListData.svc/Sites?StudyId='aea01232-4945-4362-a8eb-b99848335dc0'",
        "type": "url"
      }
    ],
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "SiteNo",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "ID",
            "description": "<p>Unique ID of site</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n  {\n      \"d\":[\n              {\n                  \"__metadata\":{\n                                  \"type\":\"MobileAppWCF.Models.Site\"\n                               },\n                  \"SiteNo\":\"_SITE-001\",\n                  \"ID\":\"264bc5f3-5ac7-41bb-b92c-9be3a16eed37\"\n              }\n          ]\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./ListData.svc.cs",
    "groupTitle": "Sites"
  },
  {
    "type": "get",
    "url": "ListData.svc/Studies",
    "title": "Listing Site Visits",
    "name": "Studies",
    "group": "Studies",
    "header": {
      "fields": {
        "Header": [
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Cookie",
            "description": "<p>FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…</p>"
          },
          {
            "group": "Header",
            "type": "String",
            "optional": false,
            "field": "Accept",
            "description": "<p>'application/json'</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "StudyNo",
            "description": ""
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "ID",
            "description": "<p>Unique Id of Study</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Success-Response:",
          "content": "HTTP/1.1 200 OK\n  {\n      \"d\":[\n              {\n                  \"__metadata\":{\n                      \"uri\":\"https://uvo1m9f8ggv60cbfnu3.env.cloudshare.com/_vti_bin/anonsvc/MobileAPI/ListData.svc/Studies('aea01232-4945-4362-a8eb-b99848335dc0')\",\n                      \"type\":\"MobileAppWCF.Models.Study\"\n                  },\n              \"StudyNo\":\"_STUDY-001\",\n              \"ID\":\"aea01232-4945-4362-a8eb-b99848335dc0\"\n              }\n          ]\n  }",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./ListData.svc.cs",
    "groupTitle": "Studies"
  }
] });
