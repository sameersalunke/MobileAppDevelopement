define({
  "name": "Onpoint Mobile API",
  "version": "0.0.0",
  "description": "API Documentation For Onpoint Mobile API",
  "sampleUrl": false,
  "apidoc": "0.2.0",
  "generator": {
    "name": "apidoc",
    "time": "2016-08-04T14:57:01.859Z",
    "url": "http://apidocjs.com",
    "version": "0.16.1"
  }
});
