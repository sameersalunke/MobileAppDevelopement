﻿#region Using Block

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System.IO;
using System.Xml;
using System.Web.Configuration;


#endregion

namespace MobileAppWCF.HelperClasses
{
    public static class Helper
    {
        #region Private Variables and constants

        private const string discoveryService = "discovery.svc";
        private const string onPointService = "OnPointService.svc";
        private static string _serviceUrl;       

        public enum AuthenticationType
        {
            Windows,
            Claims
        }
        
        #endregion

        #region Property

        public static string ServiceUrl
        {
            get
            {
                if (string.IsNullOrEmpty(_serviceUrl))
                {
                    GetServiceUrl();
                }
                return _serviceUrl;
            }
        }

        public static string PartServiceUrl
        {
            get
            {
                if (string.IsNullOrEmpty(_serviceUrl))
                {
                    GetServiceUrl();
                }
                return _serviceUrl.Replace(onPointService, "");
            }
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Fetches the service URL of the Discovery service
        /// </summary>
        private static void GetServiceUrl()
        {
            _serviceUrl = SharePointHelper.GetOnPointServiceURL();
        }

        /// <summary>
        /// Write the error message to the event log
        /// </summary>
        /// <param name="exceptionMessage"></param>
        /// <param name="callingFrom"> </param>
        /// <param name="source"></param>
        public static void WriteToEventLog(string exceptionMessage, string callingFrom, string source)
        {

            SPSecurity.RunWithElevatedPrivileges(delegate
            {
                using (var eventLog = new EventLog())
                {
                    try
                    {
                        eventLog.Log = "Application";
                        eventLog.Source = "BioClinica Study Site Creation";
                        eventLog.ModifyOverflowPolicy(OverflowAction.DoNotOverwrite, 0);

                        //var user = "";
                        //if (SPContext.Current != null)
                        //    using (var site = new SPSite(SPContext.Current.Site.ID))
                        //    {
                        //        user = site.RootWeb.CurrentUser.Name;
                        //        user += ": ";
                        //    }
                        //else
                        //    user = "OWSTimer: ";

                        eventLog.WriteEntry("Calling From: " + callingFrom + "\r\nSource: " + source + "\r\nException: " +
                            exceptionMessage, EventLogEntryType.Error);
                    }
                    catch (Exception)
                    {
                        //Do Nothing
                    }
                }
            });
        }

       
        public static AuthenticationType GetAuthenticationType(this Microsoft.SharePoint.Administration.SPWebApplication spWebApplication)
        {

            return spWebApplication.UseClaimsAuthentication ? AuthenticationType.Claims : AuthenticationType.Windows;

        }
      
        #endregion

    }
}
