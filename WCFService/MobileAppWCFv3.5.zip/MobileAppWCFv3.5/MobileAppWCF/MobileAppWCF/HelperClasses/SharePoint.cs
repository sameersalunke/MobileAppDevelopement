﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration.Claims;
using System;
using System.Linq;

namespace MobileAppWCF.HelperClasses
{
    public class SharePointHelper
    {
        public static string GetOnPointServiceURL()
        {
            string returnValue = string.Empty;

            try
            {
                returnValue = GetOnPointService(SPContext.Current.Site.RootWeb.Url);
            }
            catch { }

            return returnValue;
        }

        public static string GetOnPointServiceURL(string siteURL)
        {
            string returnValue = string.Empty;

            try
            {
                returnValue = GetOnPointService(siteURL);
            }
            catch { }

            return returnValue;
        }

        public static string GetOnPointServiceURLError()
        {
            string webServiceURL = string.Empty;
            string returnValue = string.Empty;

            try
            {
                webServiceURL = GetOnPointService(SPContext.Current.Site.RootWeb.Url);
            }
            catch (Exception ex)
            {
                returnValue = ex.Message;
            }

            if (String.IsNullOrEmpty(webServiceURL))
            {
                if (String.IsNullOrEmpty(returnValue))
                {
                    returnValue = listTitle + " " + itemType + " URL could not be found.";
                }
            }

            return returnValue;
        }

        public static string GetOnPointServiceURLError(string siteURL)
        {
            string webServiceURL = string.Empty;
            string returnValue = string.Empty;

            try
            {
                webServiceURL = GetOnPointService(siteURL);
            }
            catch (Exception ex)
            {
                returnValue = ex.Message;
            }

            if (String.IsNullOrEmpty(webServiceURL))
            {
                if (String.IsNullOrEmpty(returnValue))
                {
                    returnValue = listTitle + " " + itemType + " URL could not be found.";
                }
            }

            return returnValue;
        }

        private static string GetOnPointService(string siteURL)
        {
            string returnValue = string.Empty;
            SPListItem spListItem = null;

            using (SPSite oSPsite = new SPSite(siteURL))
            {
                using (SPWeb oSPWeb = oSPsite.OpenWeb())
                {
                    SPList discoverList = oSPWeb.Lists.TryGetList(listTitle);

                    if (discoverList != null)
                    {
                        SPListItemCollection spListItemCollection = discoverList.GetItems();
                        if (spListItemCollection.Count == 1)
                        {
                            spListItem = spListItemCollection.Cast<SPListItem>().FirstOrDefault();
                        }
                        else
                        {
                            foreach (SPListItem item in spListItemCollection.Cast<SPListItem>())
                            {
                                if (item["Title"].ToString() == itemType)
                                {
                                    spListItem = item;
                                    break;
                                }
                            }
                        }

                        if (spListItem != null)
                        {
                            string clibusUrl = spListItem[itemField].ToString();

                            if (!String.IsNullOrEmpty(clibusUrl))
                            {
                                returnValue = clibusUrl.ToLower().Replace(discoveryServiceURI, webServiceURI);
                            }
                        }

                    }
                }
            }

            return returnValue;
        }

        public static string GetSharePointUserName(SPUser user)
        {
            if (user == null)
            {
                return string.Empty; // in case we do not get the user object, return empty string
            }

            string userName = user.LoginName;

            if (string.IsNullOrEmpty(userName))
            {
                return string.Empty; // in case we do not get the login name, return empty string
            }

            try
            {
                SPClaimProviderManager spClaimProviderManager = SPClaimProviderManager.Local;
                if (spClaimProviderManager != null)
                {
                    if (SPClaimProviderManager.IsEncodedClaim(userName))
                    {
                        // return the normal domain/username without any claims identification data
                        userName = spClaimProviderManager.DecodeClaim(userName).Value;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
                // Logger.Log("An exception occurred in the GetSharePointUserName() method");
            }
            // Return the original username value if it couldn't be resolved as a claims username
            return userName.Replace(@"\\", @"\");
        }
        private static string listTitle = "Corpus Discovery Services v1.0";
        private static string itemType = "Discovery";
        private static string itemField = "DiscoveryURI";
        private static string discoveryServiceURI = "discovery.svc";
        private static string webServiceURI = "onpointservice.svc";
    }
}