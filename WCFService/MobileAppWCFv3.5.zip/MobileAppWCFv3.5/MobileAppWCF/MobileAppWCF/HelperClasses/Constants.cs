﻿
namespace MobileAppWCF.Models
{
    public static class Constants
    {
        // Error Messages
        public static string nullOrEmptyString = "{0} can not be null or blank";
        public static string nullValue = "{0} can not be null";
        public static string recordNotFound = "Record not found";
        public static string invalidRequest = "Invalid Request";

        //Connection Helper Class
        public static string connectString = "ConnectString";
        public static string xmlStartString = "<?xml";
        public static string functionNameCreateConnection = "CreateConnection";
        public static string clssNameConnHelper = "ConnectionHelper";

        //Logger Class        
        public static string stringTrue = "true";
        public static string stringFalse = "false";
        public static string logFileName = "\\OnPointMobileAPILog_{0}.txt";
        public static string logMessageLine = " \tCalling From : {0}  \tSource : {1}  \tLevel : {2} \tMessage : {3}";
        public static string dateTimeFormat = "dd-MM-yyyy HH:mm:ss";
        public static string dateFormat = "dd_MMM_yyyy";
        public static string threeParamString = "{0},{1},{2}";
        public static string category = "OnPoint";

        //DAL class
        public static string classNameDAL = "DAL";
        public static string functNameInitialize = "Initialize";
        public static string functNameGetSAEDetails = "GetSAEDetails";
        public static string functNameGetActionItems = "GetActionItems";
        public static string functNameGetSiteVisit = "GetSiteVisit";
        public static string functNameUpdateActionItem = "UpdateActionItem";
        public static string functNameUpdateSiteVisit = "UpdateSiteVisit";
        public static string functNameUpdateSAEDetail = "UpdateSAEDetail";
        public static string functNameCallStoreProc = "CallStoreProc";
        public static string functNameGetSites = "GetSites";
        public static string functNameGetStudies = "GetStudies";
        public static string functNameGetOnpointUser = "GetOnpointUser";

        //sql Parameters
        public static string sqlParamUserName = "userName";
        public static string sqlParamStudyId = "studyID";
        public static string sqlParamAccountId = "AccountId";

        //GetSAEDetails
        public static string spGetSAEDetails = "[Mobile.SPGetSAEDetails]";
        public static string spGetActionItems = "[Mobile.SPGetActionItems]";
        public static string spGetSiteVisits = "[Mobile.SPGetSiteVisits]";
        public static string spGetSites = "[Mobile.SPGetSites]";
        public static string spGetStudies = "[Mobile.SPGetStudyList]";
        public static string spGetProtocolDeviations = "[Mobile.SPGetProtocolDeviations]";
        public static string spGetUserGUID = "[Mobile.SPGetUserGUID]";
        public static string spInsertMobileUser = "[Mobile.SPInsertMobileUser]";
        public static string spLogoutMobileUser = "[Mobile.SPLogoutMobileUser]";

        //Table Columns
        public static string title = "Title";
        public static string id = "ID";
        public static string saeNumber = "SAE Number";
        public static string saeOnsetDate = "SAE Onset Date";
        public static string saeReportedTerm = "SAE Reported Term";
        public static string dateSiteNotified = "Date Site Notified";
        public static string dateReportedProductContainer = "Date Reported to Product Container";
        public static string irbNotified = "IRB Notified";
        public static string dateReportedIRB = "Date Reported to IRB";
        public static string recordedAELog = "Recorded on AE Log";
        public static string wasSAEExpected = "Was SAE Expected";
        public static string reportType = "Report Type";
        public static string eventGrade = "Event Grade";
        public static string saeDescription = "SAE Description";
        public static string saeComments = "SAE Comments";
        public static string linkedStudy = "Linked Study";
        public static string linkedScreening = "Linked Screening";
        public static string linkedSite = "Linked Site";
        public static string linkedMonitoringVisit = "Linked Monitoring Visit";
        public static string taskName = "Task Name";
        public static string actionItemDeviationNumber = "Action Item/Deviation Number";
        public static string startDate = "Start Date";
        public static string dueDate = "Due Date";
        public static string assignedTo = "Assigned To";
        public static string assignedToId = "Assigned To ID";
        public static string percentComplete = "% Complete";
        public static string description = "Description";
        public static string actionItemDeviationCategory = "Action Item Deviation Category";
        public static string actionItemCreatedBy = "Action Item Created By";
        public static string linkedVisitID = "Linked Visit ID";
        public static string linkedAssignedMonitor = "Linked Assigned Monitor";
        public static string endDate = "End Date";
        public static string allDayEvent = "All Day Event";
        public static string monitoringVisitNumber = "Monitoring Visit Number";
        public static string monitoringVisitStatus = "Monitoring Visit Status";
        public static string visitType = "Visit Type";
        public static string CTM_Modified_Date = "CTM Modified Date";
        public static string linkedVisit = "Linked Visit";
        public static string deviationNumber = "Deviation Number";
        public static string deviationDate = "Deviation Date";
        public static string deviationSubmittedtoIRB = "Deviation Submitted to IRB?";
        public static string CRAReviewer = "CRA Reviewer";
        public static string deviationCategory = "Deviation Category";
        public static string deviationPlanned = "Deviation Planned?";
        public static string sectionReference = "Deviation Protocol Section Reference";
        public static string deviationDateSigned = "Deviation Date Signed";
        public static string deviationSignedBy = "Deviation Signed By";
        public static string deviationComments = "Deviation Comments";
        public static string sendNotificationtoInvestigator = "Send Notification to Investigator";
        public static string newComment = "New Comment";
        public static string resolution = "Resolution";
        public static string Location = "Location";
        public static string SiteNo = "SiteNo";
        public static string StudyStudyNo = "StudyStudyNo";
        public static string StudyObjectId = "StudyObjectId";
        public static string SiteID = "SiteID";
        public static string userName = "UserName";

        //Class variables strings
        public static string classVarPercentComplete = "Percent_Complete";
        public static string classVarStartDate = "Start_Date";
        public static string classVarEndDate = "End_Date";
        public static string classVarSAEComments = "SAE_Comments";
        public static string classVarNewComment = "New_Comment";
        public static string classVarResolution = "Resolution";

        //Clin Bus parameters
        public static string aiText = "AIText";
        public static string complRate = "ComplRate";
        public static string clinbusParamStartDate = "StartDate";
        public static string clinbusParamEndDate = "EndDate";
        public static string clinBUSParamNewComment = "NewComment";
        public static string clinBUSParamComments = "Comments";

        //Config AppSetting Keys
        //public static string clinBUSBaseAddress = "ClinBUSBaseAddress";
        public static string actionItemServiceName = "ActionItemRecords.svc";
        public static string siteVisitServiceName = "SiteVisitRecords.svc";
        public static string saeDetailsServiceName = "SAERecords.svc";
        public static string ProtocolDeviationServiceName = "ProtocolDeviationRecords.svc";
        public static string logFilePath = "LogFilePath";
        public static string configKeyLogEnabled = "LogEnabled";
        public static string onPointDataListName = "OnPointDataListName";
        public static string onPointDataConnectionFile = "OnPointDataConnectionFile";

        //Filters
        public static string filterID = "ID = '{0}'";
    }
}
