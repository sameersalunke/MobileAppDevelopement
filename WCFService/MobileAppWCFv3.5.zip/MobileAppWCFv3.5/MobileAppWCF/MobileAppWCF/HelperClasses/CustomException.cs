﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.Text;

namespace MobileAppWCF.HelperClasses
{

    public class CustomErrorHandler : IErrorHandler
    {
        IErrorHandler originalErrorHandler;
        public CustomErrorHandler(IErrorHandler originalErrorHandler)
        {
            this.originalErrorHandler = originalErrorHandler;
        }

        public bool HandleError(Exception error)
        {
            return error is UnauthorizedAccessException || this.originalErrorHandler.HandleError(error);
        }

        public void ProvideFault(Exception error, MessageVersion version, ref Message fault)
        {

            if (error.GetType() == typeof(UnauthorizedAccessException))
            {

                HttpResponseMessageProperty prop = new HttpResponseMessageProperty();
                prop.StatusCode = HttpStatusCode.BadRequest;
                prop.Headers[HttpResponseHeader.ContentType] = "application/json; charset=utf-8";
                fault.Properties.Add(HttpResponseMessageProperty.Name, prop);
                fault.Properties.Add(WebBodyFormatMessageProperty.Name, new WebBodyFormatMessageProperty(WebContentFormat.Json));
            }
            else
            {
                this.originalErrorHandler.ProvideFault(error, version, ref fault);
            }
        }

    }

    public class WebHttpCustomBehavior : WebHttpBehavior
    {
        protected override void AddServerErrorHandlers(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher)
        {
            int errorHandlerCount = endpointDispatcher.ChannelDispatcher.ErrorHandlers.Count;
            base.AddServerErrorHandlers(endpoint, endpointDispatcher);
            IErrorHandler webHttpErrorHandler = endpointDispatcher.ChannelDispatcher.ErrorHandlers[errorHandlerCount];
            endpointDispatcher.ChannelDispatcher.ErrorHandlers.RemoveAt(errorHandlerCount);
            CustomErrorHandler newHandler = new CustomErrorHandler(webHttpErrorHandler);
            endpointDispatcher.ChannelDispatcher.ErrorHandlers.Add(newHandler);
        }

        public override void ApplyDispatchBehavior(ServiceEndpoint endpoint, EndpointDispatcher endpointDispatcher)
        {
            base.ApplyDispatchBehavior(endpoint, endpointDispatcher);            
        }
    }
}
