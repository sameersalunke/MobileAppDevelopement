﻿using Microsoft.SharePoint;
using MobileAppWCF.Models;
using System;
using System.Configuration;
using System.Diagnostics;
using System.Web;
using System.Xml;

namespace MobileAppWCF.HelperClasses
{
    class Helperclass
    {
        public string CreateConnection()
        {
            try
            {
                string connectionString = string.Empty;
                string siteUrl = Convert.ToString(HttpContext.Current.Request.Url);
                string data = string.Empty;
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        var currentuser = web.CurrentUser;
                        SPList docLib = web.Lists[ConfigurationManager.AppSettings[Constants.onPointDataListName].ToString()];
                        foreach (SPListItem item in docLib.Items)
                        {
                            SPFile file = item.File;
                            if (file != null && file.Name == ConfigurationManager.AppSettings[Constants.onPointDataConnectionFile].ToString())
                            {
                                byte[] bArray = file.OpenBinary();
                                data = System.Text.Encoding.UTF8.GetString(bArray, 0, bArray.Length);
                                data = data.Substring(data.IndexOf(Constants.xmlStartString));
                                XmlDocument doc = new XmlDocument();
                                doc.LoadXml(data);
                                XmlNode connStringElement = doc.GetElementsByTagName(Constants.connectString)[0];
                                connectionString = connStringElement.InnerText;
                                break;
                            }
                        }
                    }
                }
                return connectionString;
            }
            catch (Exception ex)
            {
                Logger log = new Logger();
                log.WriteInfoToTextFile(ex.Message, Constants.functionNameCreateConnection, Constants.clssNameConnHelper, EventLogEntryType.Error);
                log = null;
                throw ex;
            }
           
        }
    }
}
