﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TranSenda.Corpus.Synchronization.Utilities
{
    public static class EncodeUtils
    {
        private const int InitialCapacityForQuotedColunmName = 80;
        /// <summary>
        ///  This method makes input string a valid SQL Server delimited identifier.
        /// </summary>
        /// <param name="columnName">Name of the column.</param>
        /// <returns></returns>
        public static string GetQuotedSqlFieldName(string columnName)
        {
            if (String.IsNullOrEmpty(columnName))
                throw new ArgumentNullException("columnName");

            StringBuilder sb = new StringBuilder("[", InitialCapacityForQuotedColunmName);
            sb.Append(columnName);
            sb.Replace("'", "''");
            sb.Replace("]", "]]");
            sb.Append("]");
            return sb.ToString();
        }

        /*
        /// <summary>
        /// Method to escape the wildcard characters in the passed query variable for usage it
        /// in the expression with equality condition.
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string GetQuotedValueForEqualityExpression(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }

            StringBuilder quotedValue = new StringBuilder(value);

            quotedValue.Replace("'", @"''");

            return quotedValue.ToString();
        }

        /// <summary>
        /// Method to escape the wildcard characters in the passed query variable for usage it
        /// in the expression with 'LIKE' keyword.
        /// </summary>
        /// <param name="value">query variable value</param>
        /// <returns>escaped query variable value</returns>
        
        public static string GetQuotedValueForADOLikeExpression(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }

            StringBuilder quotedValue = new StringBuilder(value);

            quotedValue.Replace('[', (char)0x00);
            quotedValue.Replace("]", "[]]");
            quotedValue.Replace(((char)0x00).ToString(), "[[]");
            quotedValue.Replace("'", @"''");
            quotedValue.Replace("*", "[*]");
            quotedValue.Replace("%", "[%]");

            return quotedValue.ToString();
        }

        /// <summary>
        /// Method to escape the wildcard characters in the passed query variable for usage it
        /// in the expression with 'LIKE' keyword.
        /// </summary>
        /// <param name="value">query variable value</param>
        /// <returns>escaped query variable value</returns>
        public static string GetQuotedValueForSQLLikeExpression(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }

            StringBuilder quotedValue = new StringBuilder(value);

            quotedValue.Replace("[", "[[]");
            quotedValue.Replace("'", @"''");
            quotedValue.Replace("_", "[_]");
            quotedValue.Replace("%", "[%]");
            return quotedValue.ToString();
        }

        /// <summary>
        /// This method makes input string a valid ADO.NET delimited identifier.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public static string GetQuotedADOFieldName(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return string.Empty;
            }

            StringBuilder quotedValue = new StringBuilder(value);
            quotedValue = quotedValue.Replace(@"\", @"\\");
            quotedValue = quotedValue.Replace("]", @"\]");
            quotedValue.Insert(0, "[");
            quotedValue.Append("]");
            return quotedValue.ToString();
        }
         */
    }
}
