﻿using System;
using System.Globalization;

namespace TranSenda.Corpus.Synchronization
{
    public static class GuidExtensions
    {
        public static string GetCTMObjectId(this Guid? input)
        {
            if (input.HasValue)
            {
                return GetCTMObjectId(input.Value);
            }

            return String.Empty;
        }

        public static string GetCTMObjectId(this Guid input)
        {
            if (input != Guid.Empty)
            {
                return input.ToString("D", CultureInfo.InvariantCulture).ToUpperInvariant();
            }

            return String.Empty;
        }

        public static bool TryParse(string input, out Guid result)
        {
            if (String.IsNullOrEmpty(input))
            {
                result = Guid.Empty;
                return false;
            }

            try
            {
                result = new Guid(input);
                return true;
            }
            catch (FormatException)
            {
                result = Guid.Empty;
            }
            catch (OverflowException)
            {
                result = Guid.Empty;
            }
            return false;
        }
    }
}
