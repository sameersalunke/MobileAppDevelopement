﻿using System;

/// <summary>
/// This class is the auxiliary utility that used to validate passed arguments.
/// </summary>
internal static class ArgumentUtilities
{
    /// <summary>
    /// The method raises an exception if the specified parameter is null.
    /// </summary>
    /// <param name="param">parameter value to be validated</param>
    /// <param name="paramName">parameter name</param>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
    public static void EnsureArgumentNotNull(object param, string paramName)
    {
        if (param == null)
        {
            throw new ArgumentNullException(paramName);
        }
    }

    /// <summary>
    /// The method raises an exception if the specified parameter string is null or empty.
    /// </summary>
    /// <param name="param">parameter value to be validated</param>
    /// <param name="paramName">parameter name</param>
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
    public static void EnsureArgumentNotNullOrEmpty(string param, string paramName)
    {
        if (String.IsNullOrEmpty(param))
        {
            throw new ArgumentNullException(paramName);
        }
    }

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
    public static void EnsureArgumentEnumDefined<TEnum>(TEnum value, string paramName)
    {
        if (Enum.IsDefined(typeof(TEnum), value) == false)
        {
            throw new ArgumentException(typeof(TEnum).ToString(), paramName);
        }
    }
}
