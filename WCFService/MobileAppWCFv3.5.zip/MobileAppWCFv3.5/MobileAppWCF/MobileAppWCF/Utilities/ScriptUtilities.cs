﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.ServiceModel;
using System.Xml.Linq;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using TranSenda.Corpus.Core.Connections;
using TranSenda.Corpus.Services.Wss;
using TranSenda.Corpus.Services.Wss.Query;
using TranSenda.Corpus.Synchronization.SourceServiceReference;
using TranSenda.Corpus.Synchronization.Utilities;
using SourceFilterOperation = TranSenda.Corpus.Synchronization.SourceServiceReference.FilterOperation;

namespace TranSenda.Corpus.Synchronization
{
    public static class ScriptUtilities
    {
        private const string PredefinedColumnName_Modified = "Modified";
        private const string PredefinedColumnName_Id = "Id";

        private static readonly DateTime SqlMinDate = new DateTime(1900, 1, 1); //smalldatetime: January 1, 1900
        private static readonly DateTime SqlMaxDate = new DateTime(2079, 6, 6); //smalldatetime: June 6, 2079

        private const string MultiUserSourceDelimeter = ";";
        private const int MaxAcceptableLengthForWssTextField = 255;

        private const string WssTextFieldEllipsis = "...";

        private const int DefaultPageSize = 1500;

        public const char DeleteMethodIdPrefix = 'D';
        public const char UpdateMethodIdPrefix = 'U';

        private static readonly int LengthWitoutEllipsisForWssTextField =
            MaxAcceptableLengthForWssTextField -
            WssTextFieldEllipsis.Length;

        private const string NullObjectText = "NULL";


        private static DateTime AdjustSqlDateTime(DateTime time)
        {
            if (time < SqlMinDate)
            {
                return SqlMinDate;
            }

            if (time > SqlMaxDate)
            {
                return SqlMaxDate;
            }
            return time;
        }

        public static DateTime Max(DateTime left, DateTime right)
        {
            if (DateTime.Compare(left, right) > 0)
            {
                return left;
            }
            else
            {
                return right;
            }
        }

        public static object BuildLookupValue(Nullable<int> value)
        {
            return value.HasValue ? value.Value : (object)"0;#";
        }


        /// <summary>
        /// The function prepares a ClinBUS arguments to get modified data
        /// for the specified period.
        ///
        /// Data is sorted ascendant by "Object Id".
        /// </summary>
        /// <param name="lastUpdatedObjectId"></param>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <returns></returns>
        public static QueryArguments CreateSyncPeriodArguments(Guid? lastUpdatedObjectId, DateTime from, DateTime to)
        {
            from = AdjustSqlDateTime(from);
            to = AdjustSqlDateTime(to);

            QueryArguments modifiedBetween = QueryArguments.BuildEmptyQueryArguments();

            if (lastUpdatedObjectId.HasValue)
            {
                // lastUpdatedObjectId < 'Id'
                modifiedBetween.Filter.Add(new TableFilterItem
            {
                ColumnName = PredefinedColumnName_Id,
                Operation = SourceFilterOperation.GreaterThan,
                Value = lastUpdatedObjectId.Value
            });
            }

            // from < 'Modified'
            modifiedBetween.Filter.Add(new TableFilterItem
            {
                ColumnName = PredefinedColumnName_Modified,
                Operation = SourceFilterOperation.GreaterThan,
                Value = from
            });

            // 'Modified' <= to
            modifiedBetween.Filter.Add(new TableFilterItem
            {
                ColumnName = PredefinedColumnName_Modified,
                Operation = SourceFilterOperation.LessOrEqual,
                Value = to
            });

            // ORDER BY 'Id' ASC
            modifiedBetween.Sorting.Add(new TableSortingItem
            {
                ColumnName = PredefinedColumnName_Id,
                Order = SortingOrder.Asc
            });

            return modifiedBetween;
        }

        /// <summary>
        /// The function prepares a ClinBUS arguments to get data
        /// with Id greater than specified.
        ///
        /// Data is sorted ascendant by "Object Id".
        /// </summary>
        /// <param name="lastUpdatedObjectId"></param>
        /// <returns></returns>
        public static QueryArguments CreateGreaterThanArguments(Guid? lastUpdatedObjectId)
        {
            QueryArguments greaterThanLast = QueryArguments.BuildEmptyQueryArguments();

            if (lastUpdatedObjectId.HasValue)
            {
                // lastUpdatedObjectId < 'Id'
                greaterThanLast.Filter.Add(new TableFilterItem
                {
                    ColumnName = PredefinedColumnName_Id,
                    Operation = SourceFilterOperation.GreaterThan,
                    Value = lastUpdatedObjectId.Value
                });
            }

            // ORDER BY 'Id' ASC
            greaterThanLast.Sorting.Add(new TableSortingItem
            {
                ColumnName = PredefinedColumnName_Id,
                Order = SortingOrder.Asc
            });

            return greaterThanLast;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
        public static FilterContext DeserializeFilterContext(IDictionary<string, string> data)
        {
            FilterContext filter = new FilterContext();
            if (data != null)
            {
                filter.AddRange(
                    data.Select(p => new FilterContextItem
                    {
                        ColumnName = p.Key,
                        Value = p.Value
                    }));
            }

            return filter;
        }

        public static int OneThirdDecrement(int size)
        {
            size -= (int)Math.Ceiling(0.333d * size);
            if (size <= 0)
            {
                size = 1;
            }

            return size;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1011:ConsiderPassingBaseTypesAsParameters")]
        public static bool CheckIfQuotaExceededException(CommunicationException ex)
        {
            ArgumentUtilities.EnsureArgumentNotNull(ex, "ex");
            QuotaExceededException qEx = ex.InnerException as QuotaExceededException;
            if (qEx != null)
            {
                return qEx.Message.StartsWith("The maximum message size quota for incoming messages", StringComparison.Ordinal);
            }
            return false;
        }

        /// <summary>
        /// The function returns all records from the 1st data table.
        /// </summary>
        /// <param name="data">dataset that contains ClinBUS data</param>
        /// <returns>data rows</returns>
        public static IEnumerable<DataRow> SelectAllRows(DataSet data)
        {
            ArgumentUtilities.EnsureArgumentNotNull(data, "data");
            return data.Tables[0].Select();
        }

        /// <summary>
        /// Compares two object items.
        /// </summary>
        /// <param name="left">The object to compare.</param>
        /// <param name="right">The object to compare to.</param>
        public static bool AreEqual(object left, object right)
        {
            if (left == null && right == null)
            {
                return true;
            }

            if (left == null || right == null)
            {
                return false;
            }

            if (left.GetType() == right.GetType())
            {
                if (left.GetType() == typeof(UserIndicationCollection))
                {
                    return ((UserIndicationCollection)left).IsIdenticalTo((UserIndicationCollection)right);
                }

                if (left.GetType() == typeof(DateTime))
                {
                    return ((DateTime)left).Equals((DateTime)right);
                }
            }

            // If the types of items differ or no specific comparison was applied, then compare like strings.
            return string.Equals(ObjectToString(left), ObjectToString(right), StringComparison.Ordinal);
        }

        public static object ProcessBoolean(object source)
        {
            ArgumentUtilities.EnsureArgumentNotNull(source, "source");

            if (source.GetType() == typeof(bool))
            {
                return (bool)source;
            }

            bool boolValue;
            if (bool.TryParse(source.ToString(), out boolValue))
            {
                return boolValue;
            }

            TraceSource.Instance.TraceEvent(TraceEventType.Warning, 0, "Unable to parse the value '{0}' as boolean.", source);
            return null;
        }

        public static object ProcessBinChoice(Type sourceDataType, object source)
        {
            ArgumentUtilities.EnsureArgumentNotNull(source, "source");

            if (sourceDataType == typeof(bool))
            {
                object value = ProcessBoolean(source);
                return (value != null) ?
                    (((bool)value) ? "Yes" : "No") :
                    null;
            }

            if (sourceDataType == typeof(string)) // The casual choice field type populated with string values.
            {
                return source.ToString();
            }

            return null;
        }

        public static object ProcessUsers(object source, UserIndicationCache userCache)
        {
            ArgumentUtilities.EnsureArgumentNotNull(source, "source");
            ArgumentUtilities.EnsureArgumentNotNull(userCache, "userCache");

            UserIndicationCollection identities = new UserIndicationCollection();

            string[] userNames = source.ToString().Split(new string[] { MultiUserSourceDelimeter },
                StringSplitOptions.RemoveEmptyEntries);

            foreach (string userName in userNames)
            {
                UserIndication who = userCache.GetUserIndication(userName);

                if (who != null)
                {
                    identities.Add(who);
                }
                else
                {
                    TraceSource.Instance.TraceEvent(TraceEventType.Warning, 0, "Unable to resolve '{0}' to SPUser or SPGroup.", userName);
                }
            }

            return (identities.Count > 0) ? identities : null;
        }

        public static object NormalizeText(object fieldValue)
        {
            ArgumentUtilities.EnsureArgumentNotNull(fieldValue, "fieldValue");

            string stringValue = fieldValue.ToString();

            if (stringValue.Length > MaxAcceptableLengthForWssTextField)
            {
                return String.Concat(stringValue.Substring(0, LengthWitoutEllipsisForWssTextField), WssTextFieldEllipsis);
            }

            return stringValue;
        }

        /// <summary>
        /// Converts complex objects to their string representation.
        /// </summary>
        /// <param name="value">Object to convert.</param>
        public static string ObjectToString(object value)
        {
            return ObjectToString(value, NullObjectText);
        }

        /// <summary>
        /// Converts complex objects to their string representation.
        /// </summary>
        /// <param name="value">Object to convert.</param>
        public static string ObjectToString(object value, string nullValueText)
        {
            return value == null ? nullValueText : value.ToString();
        }

        /// <summary>
        /// Performs final data processing in accordance with the field type.
        /// </summary>
        /// <param name="fieldType">The type of the field.</param>
        /// <param name="sourceDataType">The type of the source data.</param>
        /// <param name="source">The value from the data source.</param>
        public static object DoConversions(UserIndicationCache userCache, SPFieldType fieldType, Type sourceDataType, object source)
        {
            if ((source == null) || string.IsNullOrEmpty(source.ToString()))
            {
                return null;
            }

            switch (fieldType)
            {
                case SPFieldType.Text:
                    return ScriptUtilities.NormalizeText(source);

                case SPFieldType.Choice: // This is the case when nullable boolean data Yes/No/[Null] is stored in the SPFieldType.Choice field on the SharePoint side.
                    return ScriptUtilities.ProcessBinChoice(sourceDataType, source);

                case SPFieldType.Boolean:
                    return ScriptUtilities.ProcessBoolean(source);

                case SPFieldType.User:
                    return ScriptUtilities.ProcessUsers(source, userCache);

                default:
                    return source;
            }
        }

        /// <summary>
        /// Returns the connection field that corresponds to the ObjectId column in accordance with the specified mapping.
        /// </summary>
        /// <param name="mapping">The collections of column mappings to inspect.</param>
        public static ConnectionField GetObjectIdConnectionField(IEnumerable<ConnectionField> mapping, string wssListTitle)
        {
            ConnectionField objectIdField = mapping.FirstOrDefault(f => f.IsObjectId);

            if (objectIdField == null)
            {
                string error = String.Format(
                    CultureInfo.InvariantCulture,
                    "Unable to find an Object Id field for the List '{0}'.",
                    wssListTitle);

                throw new SyncException(error);
            }

            return objectIdField;
        }

        internal static SPQuery PrepareQueryFindItemsByObjectId(Guid objectId, ConnectionField objectIdField,
            IEnumerable<MappingField> mapping)
        {
            ArgumentUtilities.EnsureArgumentNotNull(objectIdField, "objectIdField");
            IEnumerable<FieldRef> fields = QueryBuilder.CreateFieldRefsIfAny(mapping.Select(r => r.ListFieldId));
            Where whereObjectId = CommonQueries.CreateTextQuery(objectIdField.ListFieldId, objectId.ToString());
            OrderBy orderBy = new OrderBy();
            SPQuery query = QueryBuilder.CreateQuery(fields, whereObjectId, orderBy);
#if SP2010
            query.ViewFieldsOnly = true;
#endif
#if SP2013
            query.ViewFieldsOnly = true;
#endif
            return query;
        }

        public static SPQuery PrepareLookupProcessingQuery(string[] fields)
        {
            IEnumerable<FieldRef> viewFields = fields == null ? null : QueryBuilder.CreateFieldRefsIfAny(fields);
            OrderBy queryOrderBy = CommonQueries.CreateOrderById();
            SPQuery query = QueryBuilder.CreateQuery(viewFields, new Where(), queryOrderBy);
            query.RowLimit = DefaultPageSize;
            query.ItemIdQuery = false;
#if SP2010
            query.ViewFieldsOnly = true;
#endif
#if SP2013
            query.ViewFieldsOnly = true;
#endif
            return query;
        }

        internal static void ProcessResults(string results, SyncListCache listCache, string listTitle,
            out int numSuccess, out int numErrors)
        {
            numErrors = 0;
            numSuccess = 0;

            if (string.IsNullOrEmpty(results))
            {
                return;
            }

            XElement search = XElement.Parse(results);
            IEnumerable<XElement> resultItems = search.Descendants("Result");

            if (resultItems == null)
            {
                return;
            }

            foreach (XElement e in resultItems)
            {
                BatchResult result = BatchDataBuilder.ParseResultItem(e);

                if (!result.Success)
                {
                    ++numErrors;

                    TraceSource.Instance.TraceEvent(TraceEventType.Error, 0,
                        "An error occurred while processing a batch. Method Id: {0:s}; List Title: {1:s}; Error: {2:s};",
                        result.MethodId, listTitle, result.ErrorMessage);
                }
                else
                {
                    ++numSuccess;

                    char head = result.MethodId.FirstOrDefault();
                    if (listCache != null && head != 0 && head != UpdateMethodIdPrefix && head != DeleteMethodIdPrefix)
                    {
                        // For 'add new' operations, MethodId is an Object Id of a record
                        listCache.AddToCache(new Guid(result.MethodId), result.ItemId);
                    }
                }
            }
        }

        public static bool IsRelationOutdated(DateTime targetListLastModifiedDate, DateTime? relationshipLastUpdateDate, DateTime? lookupListLastModifiedDate)
        {
            // Relationship shall be refreshed when the Relationship is processed for the first time.
            if (!relationshipLastUpdateDate.HasValue)
            {
                return true;
            }
            // Relationship shall be refreshed again, when a target list or a lookup list has been modified since the Relationship was processed last time.
            if (relationshipLastUpdateDate < targetListLastModifiedDate || relationshipLastUpdateDate < lookupListLastModifiedDate)
            {
                return true;
            }

            return false;
        }

        internal static SPQuery PrepareQueryFindItemById(int id, IEnumerable<MappingField> mapping)
        {
            IEnumerable<FieldRef> fields = QueryBuilder.CreateFieldRefsIfAny(mapping.Select(r => r.ListFieldId));
            Where whereId = CommonQueries.CreateQueryById(id);
            OrderBy orderBy = new OrderBy();
            SPQuery query = QueryBuilder.CreateQuery(fields, whereId, orderBy);
            query.ItemIdQuery = true;
#if SP2010
            query.ViewFieldsOnly = true;
#endif
#if SP2013
            query.ViewFieldsOnly = true;
#endif
            return query;
        }

        internal static object NormalizeSource(MappingField map, object source)
        {
            if (source == null)
            {
                return source;
            }

            if (map.ListFieldType == SPFieldType.Note && map.RichText)
            {
                string text = source.ToString();
                source = SPHttpUtility.HtmlEncodeAllowSimpleTextFormatting(text);
            }

            return source;
        }

        internal static object NormalizeDestination(MappingField map, object destination)
        {
            if (destination == null)
            {
                return destination;
            }

            if (map.ListFieldType == SPFieldType.Note && map.RichText)
            {
                string text = destination.ToString();
                return SPHttpUtility.ConvertSimpleHtmlToText(text, -1);
            }

            return destination;
        }
    }
}
