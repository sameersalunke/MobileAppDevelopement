﻿using TranSenda.Corpus.Synchronization.Properties;

namespace TranSenda.Corpus.Synchronization.Utilities
{
    internal static class SynchronizationSettings
    {
        private const int DefaultTaskPoolMaxCapacity = 20;
        private const int DefaultFullRefreshPriority = 3;
        private const int DefaultSynchronizeListPriority = 2;
        private const int DefaultHyperlinksResolvingPriority = 1;
        private const int DefaultConnectionTimeout = 15;
        private const int DefaultCommandTimeout = 1200;

        public static int TaskPoolMaxCapacity
        {
            get
            {
                int taskPoolMaxCapacity = Settings.Default.TaskPoolMaxCapacity;
                if (taskPoolMaxCapacity <= 0)
                {
                    return DefaultTaskPoolMaxCapacity;
                }

                return taskPoolMaxCapacity;
            }
        }

        public static int QueueMaxCapacity
        {
            get
            {
                int taskPoolMaxCapacity = TaskPoolMaxCapacity;
                int queueMaxCapacity = Settings.Default.QueueMaxCapacity;

                if (queueMaxCapacity < 0)
                {
                    queueMaxCapacity = 0;
                }

                if (queueMaxCapacity < taskPoolMaxCapacity)
                {
                    return taskPoolMaxCapacity;
                }

                return queueMaxCapacity;
            }
        }

        public static int FullRefreshPriority
        {
            get
            {
                int priority = Settings.Default.FullRefreshPriority;

                if (priority <= 0)
                {
                    priority = DefaultFullRefreshPriority;
                }

                return priority;
            }
        }

        public static int SynchronizeListPriority
        {
            get
            {
                int priority = Settings.Default.SynchronizeListPriority;

                if (priority <= 0)
                {
                    priority = DefaultSynchronizeListPriority;
                }

                return priority;
            }
        }

        public static int HyperlinksResolvingPriority
        {
            get
            {
                int priority = Settings.Default.HyperlinksResolvingPriority;

                if (priority <= 0)
                {
                    priority = DefaultHyperlinksResolvingPriority;
                }

                return priority;
            }
        }

        public static int ConnectionTimeout
        {
            get
            {
                int timeout = Settings.Default.ConnectionTimeout;

                if (timeout <= 0)
                {
                    timeout = DefaultConnectionTimeout;
                }

                return timeout;
            }
        }

        public static int CommandTimeout
        {
            get
            {
                int timeout = Settings.Default.CommandTimeout;

                if (timeout <= 0)
                {
                    timeout = DefaultCommandTimeout;
                }

                return timeout;
            }
        }
    }
}
