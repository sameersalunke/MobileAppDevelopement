﻿using System;
using System.Globalization;

namespace TranSenda.Corpus.Synchronization
{
    internal static class StringExtensions
    {
        public static string ApplyArgumentsInvariantCulture(this string value, params string[] args)
        {
            return String.Format(CultureInfo.InvariantCulture, value, args);
        }

        public static string ApplyArgumentsInvariantCulture(this string value, params object[] args)
        {
            return String.Format(CultureInfo.InvariantCulture, value, args);
        }

        public static bool EqualsOrdinalIgnoreCase(this string left, string right)
        {
            return String.Equals(left, right, StringComparison.OrdinalIgnoreCase);
        }
    }
}
