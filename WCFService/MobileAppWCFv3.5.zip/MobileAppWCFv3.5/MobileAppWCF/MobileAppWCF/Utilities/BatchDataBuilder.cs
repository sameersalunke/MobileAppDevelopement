﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml;
using TranSenda.Corpus.Core.Connections;
using System.Xml.Linq;
using System.Globalization;

namespace TranSenda.Corpus.Synchronization.Utilities
{
    public class FieldValue
    {
        public string Name
        {
            get;
            set;
        }

        public string Value
        {
            get;
            set;
        }

        public bool IsSystem
        {
            get;
            set;
        }

        public FieldValue(string fieldName, object fieldValue, bool systemField)
        {
            Name = fieldName;
            IsSystem = systemField;

            if (fieldValue == null)
            {
                Value = "";
            }
            else
            {
                if (fieldValue is DateTime)
                {
                    Value = XmlConvert.ToString((DateTime)fieldValue, XmlDateTimeSerializationMode.Unspecified);
                }
                else
                {
                    Value = fieldValue.ToString();
                }
            }
        }

        public FieldValue(string fieldName, object fieldValue)
            : this(fieldName, fieldValue, false)
        {
        }
    }
    
    public enum HandleErrorKind
    {
        Return,
        Continue
    }

    public class BatchResult
    {
        public int ErrorCode
        {
            get;
            set;
        }

        public bool Success
        {
            get
            {
                return ErrorCode == 0;
            }
        }

        public string ErrorMessage
        {
            get;
            set;
        }

        public int ItemId
        {
            get;
            set;
        }

        public string MethodId
        {
            get;
            set;
        }
    }

    // The class BatchDataBuilder helps to prepare an xml-string suitable for SPWeb.ProcessBatchData(...).
    // SPWeb.ProcessBatchData(...) allows adding, updating, deleting several List Items in a single "transaction"
    public class BatchDataBuilder
    {
        #region Constants

        // Initial capacity for StringBuilder
        const int BatchInitialCapacity = 1024 * 4096;


        #endregion Constants

        #region Fields

        private StringBuilder _batch = new StringBuilder(BatchInitialCapacity);
        private string _listId;
        private bool _needsFooter;
        private bool _hasCommands;
        private HandleErrorKind _howToHandleErrors;

        #endregion Fields

        #region Properties

        private StringBuilder Batch
        {
            get { return _batch; }
        }

        private string ListId
        {
            get
            {
                return _listId;
            }
        }

        private bool NeedsFooter
        {
            get
            {
                return _needsFooter;
            }

            set
            {
                _needsFooter = value;
            }
        }

        private HandleErrorKind HowToHandleErrors
        {
            get
            {
                return _howToHandleErrors;
            }
        }

        public bool HasCommands
        {
            get
            {
                return _hasCommands;
            }
        }

        #endregion Properties

        #region Formatting

        private void MakeHeader()
        {
            Batch.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><ows:Batch OnError=\"");
            Batch.Append(HowToHandleErrors.ToString());
            Batch.Append("\">");
        }

        private void MakeFooter()
        {
            Batch.Append("</ows:Batch>");
            NeedsFooter = false;
        }

        private void SerializeFields(DataRow record, IEnumerable<ConnectionField> normalizedMapping)
        {
            XmlWriter writer = null;

            try
            {
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = false;
                settings.ConformanceLevel = ConformanceLevel.Fragment;
                settings.OmitXmlDeclaration = true;

                writer = XmlWriter.Create(Batch, settings);

                foreach (ConnectionField field in normalizedMapping)
                {
                    writer.WriteStartElement("SetVar");

                    writer.WriteAttributeString("Name", "urn:schemas-microsoft-com:office:office#" + field.ListFieldId);

                    writer.WriteValue(record[field.SourceFieldId]);

                    writer.WriteEndElement();
                }

                writer.Flush();
            }
            finally
            {
                if (writer != null)
                {
                    writer.Close();
                }
            }
        }

        private void SerializeFields(IList<FieldValue> fieldValues)
        {
            XmlWriter writer = null;

            try
            {
                XmlWriterSettings settings = new XmlWriterSettings();
                settings.Indent = false;
                settings.ConformanceLevel = ConformanceLevel.Fragment;
                settings.OmitXmlDeclaration = true;

                writer = XmlWriter.Create(Batch, settings);

                foreach (FieldValue field in fieldValues)
                {
                    string fieldName = (field.IsSystem) ? field.Name : "urn:schemas-microsoft-com:office:office#" + field.Name;

                    writer.WriteStartElement("SetVar");
                    writer.WriteAttributeString("Name", fieldName);
                    writer.WriteValue(field.Value);
                    writer.WriteEndElement();

                    writer.Flush();
                }
            }
            finally
            {
                if (writer != null)
                {
                    writer.Close();
                }
            }
        }

        #endregion Formatting

        #region Public Methods

        /// <summary>
        /// Constructs an instance of the BatchDataBuilder class
        /// </summary>
        /// <param name="listId">Guid of the SharePoint list being updated with the batch.</param>
        /// <param name="howToHandleErrors">What to do if an error occurs? Possible values: Return | Continue</param>
        public BatchDataBuilder(Guid listId, HandleErrorKind howToHandleErrors)
        {
            _listId = listId.ToString();
            _howToHandleErrors = howToHandleErrors;
            _needsFooter = true;
            _hasCommands = false;
            MakeHeader();
        }

        // Add Item
        public void PutAddMethod(string methodId, DataRow record, IEnumerable<ConnectionField> normalizedMapping)
        {
            if (!NeedsFooter)
            {
                throw new InvalidOperationException("You cannot put any methods to the Batch after it has been completed.");
            }

            if (string.IsNullOrEmpty(methodId))
            {
                throw new ArgumentNullException("methodId");
            }

            Batch.Append("<Method ID=\"");
            Batch.Append(methodId);
            Batch.Append("\"><SetList>");
            Batch.Append(ListId);
            Batch.Append("</SetList><SetVar Name=\"ID\">New</SetVar><SetVar Name=\"Cmd\">Save</SetVar>");

            SerializeFields(record, normalizedMapping);

            Batch.Append("</Method>");
            _hasCommands = true;
        }

        // Add Item
        public void PutAddMethod(string methodId, IList<FieldValue> fieldValues)
        {
            if (!NeedsFooter)
            {
                throw new InvalidOperationException("You cannot put any methods to the Batch after it has been completed.");
            }

            if (string.IsNullOrEmpty(methodId))
            {
                throw new ArgumentNullException("methodId");
            }

            Batch.Append("<Method ID=\"");
            Batch.Append(methodId);
            Batch.Append("\"><SetList>");
            Batch.Append(ListId);
            Batch.Append("</SetList><SetVar Name=\"ID\">New</SetVar><SetVar Name=\"Cmd\">Save</SetVar>");

            SerializeFields(fieldValues);

            Batch.Append("</Method>");
            _hasCommands = true;
        }

        // Update Item
        public void PutUpdateMethod(string methodId, int itemId, DataRow record, IEnumerable<ConnectionField> normalizedMapping)
        {
            if (!NeedsFooter)
            {
                throw new InvalidOperationException("You cannot put any methods to the Batch after it has been completed.");
            }

            if (string.IsNullOrEmpty(methodId))
            {
                throw new ArgumentNullException("methodId");
            }

            Batch.Append("<Method ID=\"");
            Batch.Append(methodId);
            Batch.Append("\"><SetList>");
            Batch.Append(ListId);
            Batch.Append("</SetList><SetVar Name=\"ID\">");
            Batch.Append(itemId);
            Batch.Append("</SetVar><SetVar Name=\"Cmd\">Save</SetVar>");

            SerializeFields(record, normalizedMapping);

            Batch.Append("</Method>");
            _hasCommands = true;
        }

        // Update Item
        public void PutUpdateMethod(string methodId, int itemId, IList<FieldValue> fieldValues)
        {
            if (!NeedsFooter)
            {
                throw new InvalidOperationException("You cannot put any methods to the Batch after it has been completed.");
            }

            if (string.IsNullOrEmpty(methodId))
            {
                throw new ArgumentNullException("methodId");
            }

            Batch.Append("<Method ID=\"");
            Batch.Append(methodId);
            Batch.Append("\"><SetList>");
            Batch.Append(ListId);
            Batch.Append("</SetList><SetVar Name=\"ID\">");
            Batch.Append(itemId);
            Batch.Append("</SetVar><SetVar Name=\"Cmd\">Save</SetVar>");

            SerializeFields(fieldValues);

            Batch.Append("</Method>");
            _hasCommands = true;
        }

        // Delete Item
        public void PutDeleteMethod(string methodId, int itemId)
        {
            if (!NeedsFooter)
            {
                throw new InvalidOperationException("You cannot put any methods to the Batch after it has been completed.");
            }

            if (string.IsNullOrEmpty(methodId))
            {
                throw new ArgumentNullException("methodId");
            }

            Batch.Append("<Method ID=\"");
            Batch.Append(methodId);
            Batch.Append("\"><SetList>");
            Batch.Append(ListId);
            Batch.Append("</SetList><SetVar Name=\"ID\">");
            Batch.Append(itemId);
            Batch.Append("</SetVar><SetVar Name=\"Cmd\">Delete</SetVar>");
            Batch.Append("</Method>");
            _hasCommands = true;
        }

        /// <summary>
        /// Commits the Batch to a string for passing it to SPWeb.ProcessBatchData
        /// </summary>
        /// <returns>String object from StringBuilder. The Batch footer is added automatically in case of need.</returns>
        public string CompleteScript()
        {
            if (NeedsFooter)
            {
                MakeFooter();
            }

            return Batch.ToString();
        }

        /// <summary>
        /// Clear the Data Batch, the resulting Batch obtains the header.
        /// </summary>
        public void Reset()
        {
            Batch.Length = 0;
            NeedsFooter = true;
            _hasCommands = false;
            MakeHeader();
        }

        static public BatchResult ParseResultItem(XElement element)
        {
            if (element == null)
            {
                throw new ArgumentNullException("element");
            }

            BatchResult result = new BatchResult();

            XAttribute idAttribute = element.Attribute("ID");
            result.MethodId = (idAttribute != null) ? idAttribute.Value : "?";

            XAttribute codeAttribute = element.Attribute("Code");
            result.ErrorCode = (codeAttribute != null) ? 
                int.Parse(codeAttribute.Value, CultureInfo.InvariantCulture) : 0;

            result.ItemId = -1;

            if (result.ErrorCode == 0)
            {
                result.ErrorMessage = string.Empty;

                if (element.HasElements)
                {
                    XElement i = element.Element("ID");
                    if (i != null && !string.IsNullOrEmpty(i.Value))
                    {
                        result.ItemId = int.Parse(i.Value, CultureInfo.InvariantCulture);
                    }
                }
            }
            else
            {
                XElement txt = element.Element("ErrorText");
                if (txt != null)
                {
                    result.ErrorMessage = element.Value;
                }
            }

            return result;
        }

        #endregion Public Methods
    }
}
