﻿using System.Text;
using TranSenda.Corpus.Synchronization.SourceServiceReference;

namespace TranSenda.Corpus.Synchronization
{
    internal sealed class FilterContextDumper
    {
        #region Fields

        private readonly FilterContext _context;

        #endregion

        #region Constructors

        public FilterContextDumper(FilterContext context)
        {
            ArgumentUtilities.EnsureArgumentNotNull(context, "context");
            _context = context;
        }

        #endregion

        #region Properties

        private FilterContext Context
        {
            get
            {
                return _context;
            }
        }

        #endregion

        #region Methods

        public override string ToString()
        {
            StringBuilder ret = new StringBuilder().AppendLine();

            ret.AppendLine(typeof(FilterContext).ToString());
            foreach (FilterContextItem item in Context)
            {
                ret.Append('\t').AppendLine(item.ToString());
            }

            return ret.ToString();
        }

        #endregion
    }
}
