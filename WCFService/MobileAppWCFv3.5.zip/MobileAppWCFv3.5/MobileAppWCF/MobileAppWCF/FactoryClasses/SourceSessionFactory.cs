﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MobileAppWCF;
namespace MobileAppWCF.FactoryClasses
{
  
    internal class SourceSessionFactory
    {
        private readonly MobileAppWCF.HelperClasses.Helper.AuthenticationType _authenticationType;

        public SourceSessionFactory(MobileAppWCF.HelperClasses.Helper.AuthenticationType authenticationType)
        {
            _authenticationType = authenticationType;
        }

        public SourceSession CreateSourceSession(Uri sourceUri)
        {

            return (_authenticationType == MobileAppWCF.HelperClasses.Helper.AuthenticationType.Claims)
                       ? SourceSessionFederationBinding.CreateSession(sourceUri)
                       : SourceSessionHttpBinding.CreateSession(sourceUri);

        }
    }

}
