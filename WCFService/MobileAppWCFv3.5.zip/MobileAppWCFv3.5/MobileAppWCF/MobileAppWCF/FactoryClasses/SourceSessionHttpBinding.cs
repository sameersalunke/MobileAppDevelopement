﻿using System;
using System.ServiceModel;


namespace MobileAppWCF.FactoryClasses
{
    using SourceService;
    internal sealed class SourceSessionHttpBinding : SourceSession
    {
        private const string EndpointConfigurationName = "BasicHttpBinding_ISource";

        #region Fields

        private readonly SourceClient _client;

        #endregion

        #region Constructors

        private SourceSessionHttpBinding(SourceClient sourceClient)
        {
            if (sourceClient == null)
            {
                throw new ArgumentNullException("sourceClient");
            }
            this._client = sourceClient;
        }

        #endregion

        #region Properties

        public override ISource Client
        {
            get
            {
                return this._client;
            }
        }

        protected override SourceClient SourceClient
        {
            get
            {
                return this._client;
            }
        }

        #endregion

        #region Static Methods

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope")]
        public static SourceSessionHttpBinding CreateSession(Uri sourceUri)
        {
            if (ConfigurationValidatorFactory.GetValidator().CheckEndpointDefined(EndpointConfigurationName))
            {
                SourceClient sourceClient = new SourceClient(EndpointConfigurationName, new EndpointAddress(sourceUri));

                return new SourceSessionHttpBinding(sourceClient);
            }
            else
            {
                BasicHttpBinding basicHttpBinding = new BasicHttpBinding(BasicHttpSecurityMode.TransportCredentialOnly);
                basicHttpBinding.Security.Transport.ClientCredentialType = HttpClientCredentialType.Windows;
                basicHttpBinding.MaxReceivedMessageSize = 2048000;
                SourceClient sourceClient = new SourceClient(basicHttpBinding, new EndpointAddress(sourceUri));

                return new SourceSessionHttpBinding(sourceClient);
            }
        }

        #endregion
    }
}
