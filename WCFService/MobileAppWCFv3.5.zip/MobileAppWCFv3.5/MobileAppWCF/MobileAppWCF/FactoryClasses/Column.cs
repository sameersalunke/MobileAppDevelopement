﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Diagnostics;

namespace MobileAppWCF
{
    [DataContract(Namespace = Namespace.TransendaCorpusMappingUri)]
    [DebuggerDisplay("ListFieldId = {ListFieldId}, SourceFieldId = {SourceFieldId}")]
    class Column
    {
        /// <summary>
        ///		Gets or sets the identifier of the list field.
        /// </summary>
        /// <value>The identifier of the list field.</value>
        [DataMember]
        public string ListFieldId
        {
            get;
            set;
        }

        /// <summary>
        ///		Gets or sets the identifier of the source field.
        /// </summary>
        /// <value>The identifier of the source field.</value>
        [DataMember]
        public string SourceFieldId
        {
            get;
            set;
        }

        [DataMember]
        public RelationshipLookup Relationship
        {
            get;
            set;
        }

        #region Equals realization
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != typeof(Column)) return false;
            return Equals((Column)obj);
        }

        public bool Equals(Column other)
        {
            if (ReferenceEquals(null, other)) return false;
            if (ReferenceEquals(this, other)) return true;
            return Equals(other.ListFieldId, ListFieldId) && Equals(other.SourceFieldId, SourceFieldId) && Equals(other.Relationship, Relationship);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int result = (ListFieldId != null ? ListFieldId.GetHashCode() : 0);
                result = (result * 397) ^ (SourceFieldId != null ? SourceFieldId.GetHashCode() : 0);
                result = (result * 397) ^ (Relationship != null ? Relationship.GetHashCode() : 0);
                return result;
            }
        }
        #endregion
    }
}
