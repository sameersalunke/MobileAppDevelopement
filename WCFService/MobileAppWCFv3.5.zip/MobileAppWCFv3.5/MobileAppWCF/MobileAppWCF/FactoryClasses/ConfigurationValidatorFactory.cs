﻿using System;
using System.Configuration;
using System.IO;
using System.ServiceModel.Configuration;
using System.Web.Configuration;

namespace MobileAppWCF.FactoryClasses
{
    /// <summary>
    /// The class is intended to return an instance of the ConfigurationValidator class
    /// </summary>
    internal static class ConfigurationValidatorFactory
    {
        private const string SystemServiceModelNodeName = "system.serviceModel/client";
        private const string WebConfigurationFilename = "web.config";

        private static bool IsIssHosted
        {
            get
            {
                return Path.GetFileName(AppDomain.CurrentDomain.SetupInformation.ConfigurationFile) == WebConfigurationFilename;
            }
        }

        /// <summary>
        /// Returns the instance of the validator that base on web.config or app.config configuration.
        /// </summary>
        /// <returns>The isntance of Configuration Validator base on configuration of the services host.</returns>
        public static ConfigurationValidator GetValidator()
        {
            ClientSection section = IsIssHosted
                ? GetSectionFromWebConfig()
                : GetSectionFromApplicationConfig();

            return new ConfigurationValidator(section);
        }

        private static ClientSection GetSectionFromApplicationConfig()
        {
            return ConfigurationManager.GetSection(SystemServiceModelNodeName) as ClientSection;
        }

        private static ClientSection GetSectionFromWebConfig()
        {
            return WebConfigurationManager.GetWebApplicationSection(SystemServiceModelNodeName) as ClientSection;
        }
    }
}
