﻿using System;
using System.ServiceModel;
using Microsoft.SharePoint;



namespace MobileAppWCF.FactoryClasses
{
    using SourceService;
    using System.Text;
    internal sealed class SourceSessionFederationBinding : SourceSession
    {
        private const string EndpointFederationConfigurationName = "WS2007FederationHttpBinding_ISource";

        #region Fields

        private readonly ISource _client;
        private readonly SourceClient _sourceClient;

        #endregion

        #region Constructors

        private SourceSessionFederationBinding(SourceClient sourceClient, ISource contract)
        {
            if (sourceClient == null)
            {
                throw new ArgumentNullException("sourceClient");
            }
            if (contract == null)
            {
                throw new ArgumentNullException("contract");
            }
            this._client = contract;
            this._sourceClient = sourceClient;
        }

        #endregion

        #region Properties

        public override ISource Client
        {
            get
            {
                return this._client;
            }
        }

        protected override SourceClient SourceClient
        {
            get
            {
                return this._sourceClient;
            }
        }

        #endregion

        public static SourceSession CreateSession(Uri sourceUri)
        {
            if (ConfigurationValidatorFactory.GetValidator().CheckEndpointDefined(EndpointFederationConfigurationName))
            {
                EndpointAddress svcEndPt = new EndpointAddress(sourceUri + "/federation");

                SourceClient cust = new SourceClient(EndpointFederationConfigurationName);

                //configure the channel the SharePoint way 
                SPChannelFactoryOperations.ConfigureCredentials(cust.ChannelFactory, SPServiceAuthenticationMode.Claims);

                ISource sourceClient =
                    SPChannelFactoryOperations.CreateChannelActingAsLoggedOnUser
                        (cust.ChannelFactory, svcEndPt);

                return new SourceSessionFederationBinding(cust, sourceClient);
            }
            else
            {
                EndpointAddress svcEndPt = new EndpointAddress(sourceUri + "/federation");

                SourceClient cust = new SourceClient(ConfigWS2007FederationHttpBinding(), svcEndPt);

                //configure the channel the SharePoint way 
                SPChannelFactoryOperations.ConfigureCredentials(cust.ChannelFactory, SPServiceAuthenticationMode.Claims);

                ISource sourceClient =
                    SPChannelFactoryOperations.CreateChannelActingAsLoggedOnUser
                        (cust.ChannelFactory, svcEndPt);

                return new SourceSessionFederationBinding(cust, sourceClient);
               
            }
        }
        public static WS2007FederationHttpBinding ConfigWS2007FederationHttpBinding()
        {
            // ----- Programmatic definition of the WS2007FederationHttpBinding Binding -----
            var siteFederationCreationBinding = new WS2007FederationHttpBinding();

            siteFederationCreationBinding.Name = "WS2007FederationHttpBinding_ISource";
            siteFederationCreationBinding.CloseTimeout = TimeSpan.FromMinutes(1);
            siteFederationCreationBinding.OpenTimeout = TimeSpan.FromMinutes(1);
            siteFederationCreationBinding.ReceiveTimeout = TimeSpan.FromMinutes(10);
            siteFederationCreationBinding.SendTimeout = TimeSpan.FromMinutes(1);
            siteFederationCreationBinding.BypassProxyOnLocal = false;
            siteFederationCreationBinding.TransactionFlow = false;
            siteFederationCreationBinding.HostNameComparisonMode = HostNameComparisonMode.StrongWildcard;
            siteFederationCreationBinding.MaxBufferPoolSize = 524288;
            siteFederationCreationBinding.MaxReceivedMessageSize = 2048000;
            siteFederationCreationBinding.MessageEncoding = WSMessageEncoding.Text;
            siteFederationCreationBinding.TextEncoding = Encoding.UTF8;
            siteFederationCreationBinding.UseDefaultWebProxy = true;

            siteFederationCreationBinding.ReaderQuotas.MaxDepth = 32;
            siteFederationCreationBinding.ReaderQuotas.MaxArrayLength = 16384;
            siteFederationCreationBinding.ReaderQuotas.MaxStringContentLength = 8192;
            siteFederationCreationBinding.ReaderQuotas.MaxBytesPerRead = 4096;
            siteFederationCreationBinding.ReaderQuotas.MaxNameTableCharCount = 16384;

            siteFederationCreationBinding.ReliableSession.Ordered = true;
            siteFederationCreationBinding.ReliableSession.InactivityTimeout = TimeSpan.FromMinutes(10);
            siteFederationCreationBinding.ReliableSession.Enabled = false;

            siteFederationCreationBinding.Security.Mode = WSFederationHttpSecurityMode.TransportWithMessageCredential;
            siteFederationCreationBinding.Security.Message.IssuedKeyType = System.IdentityModel.Tokens.SecurityKeyType.AsymmetricKey;
            siteFederationCreationBinding.Security.Message.NegotiateServiceCredential = true;
            siteFederationCreationBinding.Security.Message.AlgorithmSuite = System.ServiceModel.Security.SecurityAlgorithmSuite.Default;

            siteFederationCreationBinding.Security.Message.IssuerAddress = new EndpointAddress(new Uri(@"http://" + Environment.MachineName + "/_vti_bin/sts/spsecuritytokenservice.svc/windows"));
            siteFederationCreationBinding.Security.Message.IssuerMetadataAddress = new EndpointAddress(new Uri(@"http://" + Environment.MachineName + "/_vti_bin/sts/spsecuritytokenservice.svc?wsdl"));

            // ----------- End Programmatic definition of the WS2007FederationHttpBinding --------------

            return siteFederationCreationBinding;

        }
    }
}
