﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MobileAppWCF
{
    [DataContract(Namespace = V10Namespace.UrnTransendaCorpusContextFilter)]
    class FilterContext
    {
        #region Fields

        private List<FilterContextItem> _items;

        #endregion

        #region Properties

        [DataMember]
        public List<FilterContextItem> Items
        {
            get
            {
                if (this._items == null)
                {
                    this._items = new List<FilterContextItem>();
                }

                return this._items;
            }
            set
            {
                this._items = value;
            }
        }

        #endregion
    }
}
