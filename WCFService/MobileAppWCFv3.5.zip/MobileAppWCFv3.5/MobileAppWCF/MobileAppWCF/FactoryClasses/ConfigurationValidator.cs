﻿using System;
using System.Linq;
using System.ServiceModel.Configuration;

namespace MobileAppWCF.FactoryClasses
{
    /// <summary>
    /// The class is intended to verify the configuration is properly set.
    /// </summary>
    internal class ConfigurationValidator
    {
        private readonly ClientSection _clientSection;

        internal ConfigurationValidator(ClientSection clientSection)
        {
            _clientSection = clientSection;
        }

        /// <summary>
        /// Verifies wther the client with specified end point name is configurated on the configuration section.
        /// </summary>
        /// <param name="endpointName">Name of endpoint to find in configuration.</param>
        /// <returns>True if the endpoint with the specified exists in configuration.</returns>
        public bool CheckEndpointDefined(string endpointName)
        {
            if (_clientSection != null)
            {
                return _clientSection.Endpoints.Cast<ChannelEndpointElement>().Any(endpoint =>
                    string.Equals(endpoint.Name, endpointName, StringComparison.OrdinalIgnoreCase));
            }

            return false;
        }
    }
}
