﻿using System.Runtime.Serialization;
namespace MobileAppWCF
{
    [DataContract(Namespace = Namespace.TransendaCorpusMappingUri)]
    class RelationshipLookup
    {
        [DataMember]
        public string LookupFieldId
        {
            get;
            set;
        }

        #region Equals realization
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj))
            {
                return false;
            }

            if (ReferenceEquals(this, obj))
            {
                return true;
            }

            if (obj.GetType() != typeof(RelationshipLookup))
            {
                return false;
            }

            return Equals((RelationshipLookup)obj);
        }

        public bool Equals(RelationshipLookup other)
        {
            if (ReferenceEquals(null, other))
            {
                return false;
            }

            if (ReferenceEquals(this, other))
            {
                return true;
            }

            return Equals(other.LookupFieldId, LookupFieldId);
        }

        public override int GetHashCode()
        {
            return (LookupFieldId != null ? LookupFieldId.GetHashCode() : 0);
        }
        #endregion
    }
}
