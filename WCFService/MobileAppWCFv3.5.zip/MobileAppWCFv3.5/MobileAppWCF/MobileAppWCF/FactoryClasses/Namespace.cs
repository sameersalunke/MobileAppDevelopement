﻿namespace MobileAppWCF
{
    class Namespace
    {
        public const string TransendaCorpusMappingUri = "urn:transenda:corpus:mapping-v1.0";
    }
}
