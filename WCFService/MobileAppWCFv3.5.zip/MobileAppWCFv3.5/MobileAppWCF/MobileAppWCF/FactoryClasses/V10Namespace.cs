﻿namespace MobileAppWCF
{
    class V10Namespace
    {
        public const string UrnTransendaCorpusContextFilter = "urn:transenda:corpus:filter-context-v1.0";
    }
}
