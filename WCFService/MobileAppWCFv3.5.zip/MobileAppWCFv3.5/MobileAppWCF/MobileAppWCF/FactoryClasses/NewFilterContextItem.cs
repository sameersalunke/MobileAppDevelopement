﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MobileAppWCF
{
    [DataContract(Namespace = V10Namespace.UrnTransendaCorpusContextFilter)]
    class FilterContextItem
    {
        [DataMember]
        public string FilterId
        {
            get;
            set;
        }

        [DataMember]
        public string Value
        {
            get;
            set;
        }
    }
}
