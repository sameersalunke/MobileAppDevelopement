﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MobileAppWCF.FactoryClasses
{
    using System;
    using System.ServiceModel;
    using SourceService;

    internal abstract class SourceSession : IDisposable
    {
        public abstract ISource Client
        {
            get;
        }

        protected abstract SourceClient SourceClient
        {
            get;
        }

        #region IDisposable Members

        /// <summary>
        /// IDisposable.Dispose implementation, calls Dispose(true).
        /// </summary>
        void IDisposable.Dispose()
        {
            Dispose(true);
        }

        /// <summary>
        /// Dispose worker method. Handles graceful shutdown of the
        /// client even if it is an faulted state.
        /// </summary>
        /// <param name="disposing">Are we disposing (alternative
        /// is to be finalizing)</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                try
                {
                    if (this.SourceClient.State != CommunicationState.Faulted)
                    {
                        this.SourceClient.Close();
                    }
                }
                finally
                {
                    if (this.SourceClient.State != CommunicationState.Closed)
                    {
                        this.SourceClient.Abort();
                    }
                }
            }
        }

        /// <summary>
        /// Finalizer.
        /// </summary>
        ~SourceSession()
        {
            Dispose(false);
        }

        #endregion
    }
}
