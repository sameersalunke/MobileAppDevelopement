﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint;

namespace MobileAppWCF.FactoryClasses
{
    public class CorpusConnectionItems
    {
        public string Title{ get; set; }

        public Guid ListID { get; set; }

        public Guid WebID { get; set; }

        public SPFieldLookupValue DiscoveryService { get; set; }

        public string SourceID { get; set; }

        public string FilterContext { get; set; }

        public int SynchronizationInterval { get; set; }

        public int SynchronizationEnabled { get; set; }

        public string Mappings { get; set; }

    }
}
