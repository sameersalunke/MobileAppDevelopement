﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MobileAppWCF
{
    [DataContract(Namespace = Namespace.TransendaCorpusMappingUri)]
    class MappingEnvelope
    {
        public MappingEnvelope()
        {
            Columns = new List<Column>();
        }

        [DataMember]
        public List<Column> Columns
        {
            get;
            set;
        }

        public static MappingEnvelope Build()
        {
            return new MappingEnvelope
            {
                Columns = new List<Column>()
            };
        }
    }
}
