﻿using System;
using System.Collections.Generic;
using System.Data.Services;
using System.Data.Services.Common;
using System.Linq;
using System.ServiceModel.Web;
using System.Web;
using MobileAppWCF.Models;
using System.Linq.Expressions;
using MobileAppWCF.HelperClasses;
using Microsoft.SharePoint;
namespace WCFData
{
    public partial class OrderItemData
    {
        DAL dal = new DAL();
        // GET: /SiteVisits/
        /**
        * @api {get} /SiteVisits Listing Site Visits
        * @apiName SiteVisits
        * @apiGroup SiteVisits
        *
        * @apiHeader {String} Cookie FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…
         * 
         *@apiParam {Number} $top Query string param to select top records.
         *@apiParam {Number} $skip Query string param to skip number of records.
         *@apiParam {Number} $orderby Query string param to sort records.
         *@apiParam {Number} $filter Query string param to apply filter.
         * 
         * @apiExample Example usage:
         *  /SiteVisits?$top=10&$skip=20                                                //For Paging
         *  /SiteVisits?$orderby=Title                                                  //For Sorting
         *  /SiteVisits?$filter=ID eq '93675ca8-0941-487f-afb3-0451c1e28eed'            //For Filter
        *
        * @apiSuccess {String} Title
        * @apiSuccess {String} ID  Unique Id of SiteVisits
        * @apiSuccess {String} Start_Date
        * @apiSuccess {String} End_Date
        * @apiSuccess {String} All_Day_Event
        * @apiSuccess {String} Monitoring_Visit_Number
        * @apiSuccess {String} Monitoring_Visit_status
        * @apiSuccess {String} Visit_Type
        * @apiSuccess {String} Assigned_To
        * @apiSuccess {String} Linked_Study
        * @apiSuccess {String} Linked_Site
        * @apiSuccess {String} Linked_Monitor
        * @apiSuccess {String} Location      
        * 
        *
        * @apiSuccessExample Success-Response:
        *     HTTP/1.1 200 OK
        *       {
        *           "d":[
        *                   {
        *                       "__metadata":{
        *                       "uri":"https://uvo1m9f8ggv60cbfnu3.env.cloudshare.com/_vti_bin/anonsvc/MobileAPI/ListData.svc/SiteVisits('3a0cb59d-c64e-4a53-9f9e-03b39a52808f')",
        *                       "type":"MobileAppWCF.Models.SiteVisit"
        *                       },
        *                       "Title":"VIS-00005 (SMV): 001 - Rehm",
        *                       "ID":"3a0cb59d-c64e-4a53-9f9e-03b39a52808f",
        *                       "Start_Date":"2016-07-30T00:00:00Z",
        *                       "End_Date":"2016-08-04T00:00:00Z",
        *                       "All_Day_Event":"True",
        *                       "Monitoring_Visit_Number":"VIS-00005",
        *                       "Monitoring_Visit_status":"Planned",
        *                       "Visit_Type":"SMV",
        *                       "Assigned_To":"Rehm, Jeremiah",
        *                       "Linked_Study":"SDY-005",
        *                       "Linked_Site":"001",
        *                       "Linked_Monitor":"Rehm, Jeremiah",
        *                       "Location":"1959 NE Pacific, Suite 250, Seattle 98195, Phone: 206-555-5555, Fax: 206-555-5556"
        *                   }
        *              ]
        *       }
        */
        public IQueryable<SiteVisit> SiteVisits
        {
            get { return dal.GetSiteVisit().AsQueryable<SiteVisit>(); }
        }
        // GET: /SAEDetails/
        /**
        * @api {get} ListData.svc/SAEDetails Listing SAE records
        * @apiName GetSAEDetails
        * @apiGroup SAE
        *
        * @apiHeader {String} Cookie FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…
        * @apiHeader {String} Accept 'application/json'
        * 
        * @apiParam {Number} top Query string param to select top records.
        * @apiParam {Number} skip Query string param to skip number of records.
        * @apiParam {Number} orderby Query string param to sort records.
        * @apiParam {Number} filter Query string param to apply filter.
        * 
        * 
        * @apiExample Example usage:
        *  /SAEDetails?$top=10&$skip=20                                                //For Paging
        *  /SAEDetails?$orderby=Title                                                  //For Sorting
        *  /SAEDetails?$filter=ID eq '93675ca8-0941-487f-afb3-0451c1e28eed'            //For Filter
        *
        * @apiSuccess {String} Date_Reported_to_Product_Container
        * @apiSuccess {String} Date_Reported_to_IRB
        * @apiSuccess {String} Date_Site_Notified
        * @apiSuccess {String} Event_Grade
        * @apiSuccess {String} ID Unique ID for SAE Record.
        * @apiSuccess {String} IRB_Notified
        * @apiSuccess {String} Linked_Monitoring_Visit
        * @apiSuccess {String} Linked_Screening
        * @apiSuccess {String} Linked_Site
        * @apiSuccess {String} Linked_Study
        * @apiSuccess {String} Recorded_on_AE_Log
        * @apiSuccess {String} Report_Type
        * @apiSuccess {String} SAE_Comments
        * @apiSuccess {String} SAE_Description
        * @apiSuccess {String} SAE_Number
        * @apiSuccess {String} SAE_Onset_Date
        * @apiSuccess {String} SAE_Reported_Term
        * @apiSuccess {String} Title
        * @apiSuccess {String} Was_SAE_Expected
        * 
        *
        * @apiSuccessExample Success-Response:
        *     HTTP/1.1 200 OK
        *     {
        *       "d":[
        *               {
        *                   "__metadata":{
        *                                   "uri":"https://uvo1m9f8ggv60cbfnu3.env.cloudshare.com/_vti_bin/anonsvc/MobileAPI/ListData.svc/SAEDetails('069cadd1-976b-49ac-9b29-14e6ca313a7d')",
        *                                   "type":"MobileAppWCF.Models.SAEDetails"
        *                                },
        *                   "Title":"SAE-00006",
        *                   "ID":"069cadd1-976b-49ac-9b29-14e6ca313a7d",
        *                   "SAE_Number":"SAE-00006",
        *                   "SAE_Onset_Date":"2016-07-15T00:00:00Z",
        *                   "SAE_Reported_Term":"",
        *                   "Date_Site_Notified":"2016-07-21T00:00:00Z",
        *                   "Date_Reported_to_Product_Container":"2016-07-20T00:00:00Z",
        *                   "IRB_Notified":"",
        *                   "Date_Reported_to_IRB":"2016-07-12T00:00:00Z",
        *                   "Recorded_on_AE_Log":"True",
        *                   "Was_SAE_Expected":"True",
        *                   "Report_Type":"Routine",
        *                   "Event_Grade":"3 (Severe)",
        *                   "SAE_Description":"",
        *                   "SAE_Comments":"Test sam",
        *                   "Linked_Study":"SDY-005",
        *                   "Linked_Site":"002",
        *                   "Linked_Monitoring_Visit":"VIS-00011",
        *                   "Linked_Screening":"002-003"
        *               }
        *           ]
        *     }
        *
        */
        public IQueryable<SAEDetails> SAEDetails
        {
            get { return dal.GetSAEDetails().AsQueryable<SAEDetails>(); }
        }
        // GET: /ActionItems/
        /**
        * @api {get} ListData.svc/ActionItems Listing Action Items
        * @apiName ActionItems
        * @apiGroup ActionItems
        *
        * @apiHeader {String} Cookie FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…
         * @apiHeader {String} Accept 'application/json'
         * 
         *@apiParam {Number} top Query string param to select top records.
         *@apiParam {Number} skip Query string param to skip number of records.
         *@apiParam {Number} orderby Query string param to sort records.
         *@apiParam {Number} filter Query string param to apply filter.
         * 
         * 
         * @apiExample Example usage:
         *  /ActionItems?$top=10&$skip=20                                                //For Paging
         *  /ActionItems?$orderby=Title                                                  //For Sorting
         *  /ActionItems?$filter=ID eq '93675ca8-0941-487f-afb3-0451c1e28eed'            //For Filter
        *
        * @apiSuccess {String} Task_Name
        * @apiSuccess {String} ID  Unique Id of Action Item
        * @apiSuccess {String} Action_Item_Deviation_Number
        * @apiSuccess {String} Start_Date
        * @apiSuccess {String} Due_Date
        * @apiSuccess {String} Assigned_To
        * @apiSuccess {String} Percent_Complete  Action Item Completion Status
        * @apiSuccess {String} Description       Action Item Comments
        * @apiSuccess {String} Action_Item_Deviation_Category
        * @apiSuccess {String} Action_Item_Created_By
        * @apiSuccess {String} Linked_Study
        * @apiSuccess {String} Linked_Site
        * @apiSuccess {String} Linked_Visit
        * @apiSuccess {String} AIRRecs_Linked_Visit
        * @apiSuccess {String} Linked_Assigned_Monitor
        * 
        *
        * @apiSuccessExample Success-Response:
        *     HTTP/1.1 200 OK
        *      {
        *           "d":[
        *                   {
        *                       "__metadata":{
        *                       "uri":"https://op34110-portal.bioclinica.com/_vti_bin/anonsvc/MobileAPI/ListData.svc/ActionItems('9d78306f-1826-42ef-89c7-8f01a1040687')",
        *                       "type":"MobileAppWCF.Models.ActionItems"
        *                       },
        *                       "Task_Name":"File IRB approval of Protocol Amendment 2",
        *                       "ID":"9d78306f-1826-42ef-89c7-8f01a1040687",
        *                       "Action_Item_Deviation_Number":"AIT-00011",
        *                       "Start_Date":"2008-05-23T00:00:00Z",
        *                       "Due_Date":"2008-05-23T00:00:00Z",
        *                       "Assigned_To":"Clinical Administrator",
        *                       "Assigned_To_Id":" 1B0F355E-E267-4569-9DB8-06185782311A, 5FCBDDED-C6B6-43BA-95DA-CF6A35822588",
        *                       "Status":"0",
        *                       "Description":"File IRB approval of Protocol Amendment 2 upon its receipt (pending, it was submitted 6/02/08), per IRB ",
        *                       "Action_Item_Deviation_Category":"Protocol Deviation",
        *                       "Action_Item_Created_By":"3f8a4442-9e8f-4f6a-825c-455acf8ca593",
        *                       "Linked_Study":"SDY-001",
        *                       "Linked_Site":"003",
        *                       "Linked_Visit":"VIS-00003",
        *                       "AIRRecs_Linked_Visit":"fbb69daa-5dac-48d6-a0a6-0ab6c955814b",
        *                       "Linked_Assigned_Monitor":"Rehm, Jeremiah"
        *                   }
        *               ]
        *      }
        */
        public IQueryable<ActionItems> ActionItems
        {
            get { return dal.GetActionItems().AsQueryable<ActionItems>(); }
        }
        // GET: /ProtocolDeviations/
        /**
        * @api {get} ListData.svc/ProtocolDeviations Listing Protocol Deviations
        * @apiName ProtocolDeviations
        * @apiGroup ProtocolDeviations
        *
        * @apiHeader {String} Cookie FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…
         * @apiHeader {String} Accept 'application/json'
         * 
         *@apiParam {Number} top Query string param to select top records.
         *@apiParam {Number} skip Query string param to skip number of records.
         *@apiParam {Number} orderby Query string param to sort records.
         *@apiParam {Number} filter Query string param to apply filter.
         * 
         * 
         * @apiExample Example usage:
         *  /ProtocolDeviations?$top=10&$skip=20                                                //For Paging
         *  /ProtocolDeviations?$orderby=Title                                                  //For Sorting
         *  /ProtocolDeviations?$filter=ID eq '93675ca8-0941-487f-afb3-0451c1e28eed'            //For Filter
        *
        * @apiSuccess {String} Title
        * @apiSuccess {String} ID  Unique Id of Protocol Deviation
        * @apiSuccess {String} Modified_Date
        * @apiSuccess {String} Linked_Site
        * @apiSuccess {String} Linked_Study
        * @apiSuccess {String} Linked_Visit
        * @apiSuccess {String} Linked_Screening
        * @apiSuccess {String} Deviation_Number
        * @apiSuccess {String} Deviation_Date
        * @apiSuccess {String} Description
        * @apiSuccess {String} Deviation_Submitted_to_IRB
        * @apiSuccess {String} Deviation_CRA_Reviewer
        * @apiSuccess {String} Deviation_Category
        * @apiSuccess {String} Deviation_Planned
        * @apiSuccess {String} Deviation_Protocol_Section_Reference
        * @apiSuccess {String} Deviation_Date_Signed
        * @apiSuccess {String} Deviation_Signed_By
        * @apiSuccess {String} Deviation_Comments   We get Deviation Comments at this field
        * @apiSuccess {String} Send_Notification_to_Investigator
        * @apiSuccess {String} New_Comment  New comments to be sent through this field and that then gets appended to Deviation_Comments
        * @apiSuccess {String} Resolution   Resolution to Deviation
        * 
        *
        * @apiSuccessExample Success-Response:
        *     HTTP/1.1 200 OK
        *       {
        *           "d":[
        *                   {
        *                       "__metadata":{
        *                       "uri":"https://uvo1m9f8ggv60cbfnu3.env.cloudshare.com/_vti_bin/anonsvc/MobileAPI/ListData.svc/ProtocolDeviations('91a45753-495b-444e-b4e8-5b6471118b98')",
        *                       "type":"MobileAppWCF.Models.ProtocolDeviation"
        *                       },
        *                       "Title":"DEV-00010 - Inclusion/Exclusion Criteria",
        *                       "ID":"91a45753-495b-444e-b4e8-5b6471118b98",
        *                       "Modified_Date":"2016-07-28T07:53:04Z",
        *                       "Linked_Site":"002",
        *                       "Linked_Study":"SDY-005",
        *                       "Linked_Visit":"VIS-00006",
        *                       "Linked_Screening":"002-009",
        *                       "Deviation_Number":"DEV-00010",
        *                       "Deviation_Date":"2016-07-14T00:00:00Z",
        *                       "Description":"Inclusion/Exclusion Criteria",
        *                       "Deviation_Submitted_to_IRB":"False",
        *                       "Deviation_CRA_Reviewer":"CRA2 CRA2",
        *                       "Deviation_Category":"Waiver",
        *                       "Deviation_Planned":"True",
        *                       "Deviation_Protocol_Section_Reference":"as",
        *                       "Deviation_Date_Signed":"",
        *                       "Deviation_Signed_By":"",
        *                       "Deviation_Comments":"28Jul2016 00:53 [jrehm]: MyNewComm\r\n19Jul2016 09:15 [cra1]: First comment",
        *                       "Send_Notification_to_Investigator":"False",
        *                       "New_Comment":"",
        *                       "Resolution":"dsad"
        *                   }
        *               ]
        *       }
        */
        public IQueryable<ProtocolDeviation> ProtocolDeviations
        {
            get { return dal.GetProtocolDeviations().AsQueryable<ProtocolDeviation>(); }
        }
        // GET: /Studies/
        /**
        * @api {get} ListData.svc/Studies Listing Site Visits
        * @apiName Studies
        * @apiGroup Studies
        *
        * @apiHeader {String} Cookie FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…      
 	* @apiHeader {String} Accept 'application/json'   
        *
        * @apiSuccess {String} StudyNo
        * @apiSuccess {String} ID  Unique Id of Study           
        * 
        *
        * @apiSuccessExample Success-Response:
        *     HTTP/1.1 200 OK
        *       {
        *           "d":[
        *                   {
        *                       "__metadata":{
        *                           "uri":"https://uvo1m9f8ggv60cbfnu3.env.cloudshare.com/_vti_bin/anonsvc/MobileAPI/ListData.svc/Studies('aea01232-4945-4362-a8eb-b99848335dc0')",
        *                           "type":"MobileAppWCF.Models.Study"
        *                       },
        *                   "StudyNo":"_STUDY-001",
        *                   "ID":"aea01232-4945-4362-a8eb-b99848335dc0"
        *                   }
        *               ]
        *       }
        */
        public IQueryable<Study> Studies
        {
            get { return dal.GetStudies().AsQueryable<Study>(); }
        }
        // GET api/<controller>/5
        /**
        * @api {get} ListData.svc/OnpointUser Onpoint User Account Details
        * @apiName OnpointUser
        * @apiGroup OnpointUser
        *
        * @apiHeader {String} Cookie FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…
        * @apiHeader {String} Accept 'application/json'
        * 
        *@apiParam {Number} top Query string param to select top records.
        *@apiParam {Number} skip Query string param to skip number of records.
        *@apiParam {Number} orderby Query string param to sort records.
        *@apiParam {Number} filter Query string param to apply filter.
        *        
        * @apiSuccess {String} ID  
        * @apiSuccess {String} OnpointUserName
        *
        * @apiSuccessExample Success-Response:
        *     HTTP/1.1 200 OK
        *       {
        *           "d" : [
        *                   {
        *                      "__metadata": {
        *                             "uri": "https://op34110-portal.bioclinica.com/_vti_bin/anonsvc/MobileAPI/ListData.svc/OnpointUser('904ef048-3697-478c-a986-98a897c32768')", "type": "MobileAppWCF.Models.UserDetails"
        *                       }, "OnpointUserName": "jrehm", "ID": "904ef048-3697-478c-a986-98a897c32768"
        *                   }
        *                 ]
        *       }
        */
        public IQueryable<UserDetails> OnpointUser
        {
            get { return dal.GetOnpointUser().AsQueryable<UserDetails>(); }
        }

    }
    
    [JSONPSupportBehavior]
    public class ListData : DataService<OrderItemData>
    {
        public ListData()
        {
            if (SPContext.Current != null)
            {
                string userName = string.Empty;
                var user = SharePointHelper.GetSharePointUserName(SPContext.Current.Web.CurrentUser);
                var username = user.Split('\\');
                if (username.Length > 1)
                    userName = username[1];
                else
                    userName = user;
                if (userName == string.Empty)
                {
                    HttpContext.Current.Response.StatusCode = 401;
                    HttpContext.Current.Response.StatusDescription = "Unauthorized";
                    HttpContext.Current.Response.ContentType = "application/json";
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                    HttpContext.Current.Response.End();
                }

            }
        }
        public static void InitializeService(IDataServiceConfiguration config)
        {
            config.SetEntitySetAccessRule("SAEDetails", EntitySetRights.AllRead);
            config.SetEntitySetAccessRule("SiteVisits", EntitySetRights.AllRead);
            config.SetEntitySetAccessRule("ActionItems", EntitySetRights.AllRead);
            config.SetEntitySetAccessRule("ProtocolDeviations", EntitySetRights.AllRead);
            config.SetEntitySetAccessRule("Studies", EntitySetRights.AllRead);
            config.SetEntitySetAccessRule("OnpointUser", EntitySetRights.AllRead);
            config.SetServiceOperationAccessRule("Sites", ServiceOperationRights.AllRead);
            
        }
        // GET: ListData.svc/Sites
        /**
        * @api {get} ListData.svc/Sites Listing SAE records
        * @apiName Sites
        * @apiGroup Sites
        *
        * @apiHeader {String} Cookie FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…   
         * @apiHeader {String} Accept 'application/json'
         * 
         * @apiParam {String} StudyId Linked study to serch sites.
         * 
         * * @apiExample {url} Example usage:
         *          https://uvo1m9f8ggv60cbfnu3.env.cloudshare.com/_vti_bin/anonsvc/MobileAPI/ListData.svc/Sites?StudyId='aea01232-4945-4362-a8eb-b99848335dc0'
        *
        * @apiSuccess {String} SiteNo
        * @apiSuccess {String} ID Unique ID of site
        * 
        *
        * @apiSuccessExample Success-Response:
        *     HTTP/1.1 200 OK
        *       {
        *           "d":[
        *                   {
        *                       "__metadata":{
        *                                       "type":"MobileAppWCF.Models.Site"
        *                                    },
        *                       "SiteNo":"_SITE-001",
        *                       "ID":"264bc5f3-5ac7-41bb-b92c-9be3a16eed37"
        *                   }
        *               ]
        *       }
        */
        [WebGet]
        public IQueryable<Site> Sites(string StudyId)
        {
            DAL dal = new DAL();
            return dal.GetSites(StudyId).AsQueryable<Site>();
        }

        // Define a query interceptor for the Orders entity set.
        
    }
}
