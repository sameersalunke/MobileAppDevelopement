﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.Services;
using Microsoft.SharePoint.Security;
using MobileAppWCF.HelperClasses;
using MobileAppWCF.Models;
using System.Collections.Generic;
using System.Security.Permissions;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Web;


namespace MobileAppWCF.anonsvc
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "MobileApi" in both code and config file together.
   [ServiceBehavior(Namespace = "http://schemas.microsoft.com/sharepoint/soap/"),
    AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed),
    ClientRequestServiceBehavior,
    BasicHttpBindingServiceMetadataExchangeEndpoint,
    SharePointPermission(SecurityAction.Demand, ObjectModel = true),
    AspNetHostingPermission(SecurityAction.Demand, Level = AspNetHostingPermissionLevel.Minimal)]
   
    public class UpdateData : IUpdateData
    {
        public UpdateData()
        {
            if (SPContext.Current != null)
            {
                string userName = string.Empty;
                var user = SharePointHelper.GetSharePointUserName(SPContext.Current.Web.CurrentUser);
                var username = user.Split('\\');
                if (username.Length > 1)
                    userName = username[1];
                else
                    userName = user;
                if (userName == string.Empty)
                {
                    //WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Unauthorized;
                    //WebOperationContext.Current.OutgoingResponse.SuppressEntityBody = true;
                    //WebOperationContext.Current.OutgoingResponse.ContentType = "application/json";
                    //WebOperationContext.Current.OutgoingResponse.StatusDescription = "Unauthorise access";

                    //HttpContext.Current.Response.AddHeader("WWW-Authenticate", "Basic realm=\"Northwind\"");
                    //throw new DataServiceException(401, "Unauthorized");
                    HttpContext.Current.Response.StatusCode = 401;
                    HttpContext.Current.Response.StatusDescription = "Unauthorized";
                    HttpContext.Current.Response.ContentType = "application/json";
                    HttpContext.Current.ApplicationInstance.CompleteRequest();
                    HttpContext.Current.Response.End();
                    //return null;
                    //.Current.Response.End();//throw new UnauthorizedAccessException();//401, "Unauthorized");
                    //throw new FaultException<UnauthorizedAccessException>(new UnauthorizedAccessException());
                    //throw new FaultException(new FaultReason("Unauthorized"), new FaultCode("401"));

                }

            }
        }
        // POST /UpdateActionItem/
        /**
        * @api {post} UpdateData.svc/ActionItem Updating Action Items
        * @apiName UpdateActionItem
        * @apiGroup ActionItem
	    *
	    * @apiHeader {String} Cookie FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…
        * @apiHeader {String} Content-Type application/json 
        * 
        * 
        * @apiParam {string} ID Unique GUID of Action Item
        * @apiParam {string} Description Comments to be updated
        * @apiParam {string} Percent_Complete Completion status in boolean value
	    *
	    * @apiParamExample {json} Request-Example:
        *         {
        *           "ID":"cbf1406c-43be-4515-a1a3-07877e54db2f",
        *           "Percent_Complete":"0",
        *           "Description":"Follow-up on the waiver for this site's protocol deviation DEV-00001",
        *         }
        *
        * @apiSuccess {String} errorMessage If error occurs its description comes here
        * @apiSuccess {string} result In case of success message you get Guid here
        * @apiSuccess {string} success True or false in case of success or failure respectively
        *
        * @apiSuccessExample Success-Response:
        *    
        *    {
        *     "errorMessage": null,
        *     "result": "fc4fd955-08eb-4a53-b88b-fec6dff5e66c",
        *     "success": "true"
        *     }
        *
        *
        * @apiErrorExample Error-Response:
        *    
        *     {
        *          "errorMessage": "ID can not be null or blank",
        *          "result": null,
        *          "success": "false"
        *     }
        */
        [WebInvoke(Method = "POST",
                  ResponseFormat = WebMessageFormat.Json,
                  RequestFormat = WebMessageFormat.Json,
                  UriTemplate = "/ActionItem")]
        public APIResponse UpdateActionItem(ActionItems item)
        {
            DAL dal = new DAL();
            return dal.UpdateActionItem(item);
        }
        // POST /UpdateSiteVisit/
        /**
        * @api {post} UpdateData.svc/SiteVisit Updating Site Visit
        * @apiName UpdateSiteVisit
        * @apiGroup SiteVisit
	    *
	    * @apiHeader {String} Cookie FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…
        * @apiHeader {String} Content-Type application/json 
        * 
        * 
        * @apiParam {string} ID Unique GUID of Site Visit
        * @apiParam {string} Start_Date 
        * @apiParam {string} End_Date
	    *
	    * @apiParamExample {json} Request-Example:
        *         {"ID":"3a0cb59d-c64e-4a53-9f9e-03b39a52808f","Start_Date":"7\/16\/2008 12:00:00 AM","End_Date":"7\/18\/2008 12:00:00 AM"}
        *
        * @apiSuccess {String} errorMessage If error occurs its description comes here
        * @apiSuccess {string} result In case of success message you get Guid here
        * @apiSuccess {string} success True or false in case of success or failure respectively
        *
        * @apiSuccessExample Success-Response:
        *    
        *    {
        *     "errorMessage": null,
        *     "result": "fc4fd955-08eb-4a53-b88b-fec6dff5e66c",
        *     "success": "true"
        *     }
        *
        *
        * @apiErrorExample Error-Response:
        *    
        *     {
        *          "errorMessage": "ID can not be null or blank",
        *          "result": null,
        *          "success": "false"
        *     }
        */
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   UriTemplate = "/SiteVisit")]
        public APIResponse UpdateSiteVisit(SiteVisit item)
        {
            DAL dal = new DAL();
            return dal.UpdateSiteVisit(item);
        }
        // POST /UpdateProtocolDeviation/
        /**
        * @api {post} UpdateData.svc/ProtocolDeviation Updating Protocol Deviation
        * @apiName UpdateProtocolDeviation
        * @apiGroup ProtocolDeviation
	    *
	    * @apiHeader {String} Cookie FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…
        * @apiHeader {String} Content-Type application/json 
        * 
        * 
        * @apiParam {string} ID Unique GUID of Protocol Deviation
        * @apiParam {string} New_Comment Comments to be updated
        * @apiParam {string} Resolution Resolution for the deviation
	    *
	    * @apiParamExample {json} Request-Example:
        *         {"ID":"2984f2cb-87f8-4e0c-8b94-8dbe7905e680","New_Comment":"Some New Comment Here","Resolution":"Some Resolution"} 
        *
        * @apiSuccess {String} errorMessage If error occurs its description comes here
        * @apiSuccess {string} result In case of success message you get Guid here
        * @apiSuccess {string} success True or false in case of success or failure respectively
        *
        * @apiSuccessExample Success-Response:
        *    
        *    {
        *     "errorMessage": null,
        *     "result": "fc4fd955-08eb-4a53-b88b-fec6dff5e66c",
        *     "success": "true"
        *     }
        *
        *
        * @apiErrorExample Error-Response:
        *    
        *     {
        *          "errorMessage": "ID can not be null or blank",
        *          "result": null,
        *          "success": "false"
        *     }
        */
        [WebInvoke(Method = "POST",
                   ResponseFormat = WebMessageFormat.Json,
                   RequestFormat = WebMessageFormat.Json,
                   UriTemplate = "/ProtocolDeviation")]
        public APIResponse UpdateProtocolDeviation(ProtocolDeviation item)
        {
            DAL dal = new DAL();
            return dal.UpdateProtocolDeviation(item);
        }
       // POST /UpdateSAEDetail/
        /**
        * @api {post} UpdateData.svc/SAEDetail Updating SAE Comments
        * @apiName UpdateSAEDetail
        * @apiGroup SAE
        *
        * @apiHeader {String} Cookie FedAuth=77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbm…
        * @apiHeader {String} Content-Type application/json 
        * 
        * 
        * @apiParam {string} ID Unique GUID of SAE Record.
        * @apiParam {string} SAE_Comments Comments to be updated.
        *
        * @apiParamExample {json} Request-Example:
        *         {"ID":"fc4fd955-08eb-4a53-b88b-fec6dff5e66c","SAE_Comments":"This case was withdrawn because it is not a reportable event."}
        *
        * @apiSuccess {String} errorMessage If error occurs its description comes here
        * @apiSuccess {string} result In case of success message you get Guid here
        * @apiSuccess {string} success True or false in case of success or failure respectively
        *
        * @apiSuccessExample Success-Response:
        *    
        *    {
        *     "errorMessage": null,
        *     "result": "fc4fd955-08eb-4a53-b88b-fec6dff5e66c",
        *     "success": "true"
        *     }
        *
        *
        * @apiErrorExample Error-Response:
        *    
        *     {
        *          "errorMessage": "ID can not be null or blank",
        *          "result": null,
        *          "success": "false"
        *     }
       */
        [WebInvoke(Method = "POST",
                    ResponseFormat = WebMessageFormat.Json,
                    RequestFormat = WebMessageFormat.Json,
                    UriTemplate = "/SAEDetail")]
        public APIResponse UpdateSAEDetail(SAEDetails item)
        {
            DAL dal = new DAL();
            return dal.UpdateSAEDetail(item);
        }
        
        [WebInvoke(Method = "POST",
                     ResponseFormat = WebMessageFormat.Json,
                     RequestFormat = WebMessageFormat.Json,
                     UriTemplate = "/Logout")]
        public APIResponse LogoutUser()
        {
            DAL dal = new DAL();
            return dal.Logout();
        }
    }
}
