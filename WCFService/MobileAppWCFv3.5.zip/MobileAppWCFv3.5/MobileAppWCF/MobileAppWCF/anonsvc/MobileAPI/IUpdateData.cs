﻿using MobileAppWCF.Models;
using System.Collections.Generic;
using System.ServiceModel;

namespace MobileAppWCF.anonsvc
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IMobileApi" in both code and config file together.
    [ServiceContract]
    public interface IUpdateData
    {
        //[OperationContract]
        //List<SAEDetails> GetSAEDetails();
        //[OperationContract]
        //List<SiteVisit> GetSiteVisits();
        //[OperationContract]
        //List<ActionItems> GetActionItems();
        //[OperationContract]
        //List<ProtocolDeviation> GetProtocolDeviations();
        //[OperationContract]
        //List<ActionItems> GetActionItemsFromClinbus();
        //[OperationContract]
        //List<SAEDetails> GetSAEDetailsFromClinbus();
        [OperationContract]
        APIResponse UpdateActionItem(ActionItems item);
        [OperationContract]
        APIResponse UpdateSiteVisit(SiteVisit item);
        [OperationContract]
        APIResponse UpdateProtocolDeviation(ProtocolDeviation item);
        [OperationContract]
        APIResponse UpdateSAEDetail(SAEDetails item);
        [OperationContract]
        APIResponse LogoutUser();
    }
}
