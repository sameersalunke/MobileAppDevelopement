﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;

namespace TranSenda.Corpus.Synchronization.ClinBUS
{
    internal sealed class ServiceMetadata
    {
        #region Properties

        public string Id
        {
            get;
            private set;
        }

        public string DbVersion
        {
            get;
            private set;
        }

        public string ConnectionString
        {
            get;
            private set;
        }

        public string TableName
        {
            get;
            private set;
        }

        public DataSet ServiceSchema
        {
            get;
            private set;
        }

        public IEnumerable<FilterMetaInfoItem> FilterSchema
        {
            get;
            private set;
        }

        public CustomFieldsMetadata CustomFieldsInfo
        {
            get;
            private set;
        }

        public DataTableMapping TableMapping
        {
            get;
            private set;
        }

        #endregion

        #region Private Methods

        private ServiceMetadata()
        {
        }

        private void AssignId(string id)
        {
            if (String.IsNullOrEmpty(id))
            {
                throw ExceptionHelper.CreateServiceMetadataIdNotSpecifiedException();
            }
            Id = id;
        }

        private void AssignDbVersion(string dbVersion)
        {
            if (String.IsNullOrEmpty(dbVersion))
            {
                throw ExceptionHelper.CreateServiceMetadataDbVersionNotSpecifiedException();
            }
            DbVersion = dbVersion;
        }

        private void AssignConnectionString(string connectionString)
        {
            if (String.IsNullOrEmpty(connectionString))
            {
                throw ExceptionHelper.CreateServiceMetadataConnectionStringNotSpecifiedException();
            }
            ConnectionString = connectionString;
        }

        private void AssignTableName(string tableName)
        {
            if (String.IsNullOrEmpty(tableName))
            {
                throw ExceptionHelper.CreateServiceMetadataTableNameNotSpecifiedException();
            }
            TableName = tableName;
        }

        private void AssignServiceSchema(DataSet serviceSchema)
        {
            if (serviceSchema == null)
            {
                throw ExceptionHelper.CreateServiceMetadataServiceSchemaNotSpecifiedException();
            }
            ServiceSchema = serviceSchema;
        }

        private void AssignFilterSchema(IEnumerable<FilterMetaInfoItem> filterSchema)
        {
            List<FilterMetaInfoItem> schema = new List<FilterMetaInfoItem>();
            if (filterSchema != null)
            {
                schema.AddRange(filterSchema);
            }
            FilterSchema = schema;
        }

        private void AssignCustomFieldsInfo(string customFieldsSourceTable, string customFieldsLinkField, Nullable<Guid> entityId)
        {
            if (String.IsNullOrEmpty(customFieldsSourceTable) || !entityId.HasValue)
            {
                CustomFieldsInfo = null;
                return;
            }

            CustomFieldsInfo = new CustomFieldsMetadata
            {
                SourceTable = customFieldsSourceTable,
                LinkField = customFieldsLinkField,
                EntityId = entityId.Value
            };
        }

        private void AssignTableMapping(DataTableMapping tableMapping)
        {
            if (tableMapping == null)
            {
                throw ExceptionHelper.CreateServiceMetadataTableMappingNotSpecifiedException();
            }

            TableMapping = new DataTableMapping(
                tableMapping.SourceTable,
                tableMapping.DataSetTable);

            TableMapping.ColumnMappings.AddRange(
                tableMapping.ColumnMappings.Cast<DataColumnMapping>()
                .Select(m => new DataColumnMapping(m.SourceColumn, m.DataSetColumn))
                .ToArray());
        }

        #endregion

        public static ServiceMetadata Build(string dbVersion, string connectionString, DataSet schema, SourceManifest manifest)
        {
            ArgumentUtilities.EnsureArgumentNotNull(manifest, "manifest");

            ServiceMetadata data = new ServiceMetadata();

            data.AssignId(manifest.Id);
            data.AssignDbVersion(dbVersion);
            data.AssignConnectionString(connectionString);
            data.AssignTableName(manifest.TableName);
            data.AssignServiceSchema(schema);
            data.AssignFilterSchema(manifest.FilterSchema);
            data.AssignCustomFieldsInfo(
                manifest.CustomFieldsSourceTable,
                manifest.CustomFieldsLinkField,
                manifest.CustomFieldsEntityId);
            data.AssignTableMapping(manifest.TableMapping);

            return data;
        }
    }
}
