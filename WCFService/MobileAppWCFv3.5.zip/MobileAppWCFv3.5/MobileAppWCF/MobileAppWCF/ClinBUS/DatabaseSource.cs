﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using TranSenda.Corpus.Synchronization.ClinBUS.CustomFields;
using MobileAppWCF.SourceService;
using TranSenda.Corpus.Synchronization.Properties;
using TranSenda.Corpus.Synchronization.Utilities;

namespace TranSenda.Corpus.Synchronization.ClinBUS
{
    internal sealed class DatabaseSource : ISource
    {
        #region Fields

        private ServiceMetadata _serviceInfo;
        private IDatabaseProvider _provider;
        private ICustomFieldsManager _customFieldsManager;

        #endregion

        #region Properties

        private ServiceMetadata ServiceInfo
        {
            get
            {
                return _serviceInfo;
            }
        }

        private IDatabaseProvider Provider
        {
            get
            {
                return _provider;
            }
        }

        private ICustomFieldsManager CustomFieldsManager
        {
            get
            {
                return _customFieldsManager;
            }
        }

        #endregion

        #region Constructors

        public DatabaseSource(
            ServiceMetadata serviceInfo,
            IDatabaseProvider provider,
            ICustomFieldsManager customFieldsManager)
        {
            ArgumentUtilities.EnsureArgumentNotNull(serviceInfo, "serviceInfo");
            ArgumentUtilities.EnsureArgumentNotNull(provider, "provider");
            ArgumentUtilities.EnsureArgumentNotNull(customFieldsManager, "customFieldsManager");

            _serviceInfo = serviceInfo;
            _provider = provider;
            _customFieldsManager = customFieldsManager;
        }

        #endregion

        #region ISource Members

        public DataSet GetSchema()
        {
            using (DatabaseContext database = SetupDatabaseContext())
            {
                DataSet dataSchema = DataSetConverter.GetUntypedDataSetSchema(ServiceInfo.ServiceSchema);
                AddCustomColumnsToSourceDataTable(dataSchema, ServiceInfo.TableMapping.DataSetTable);
                return dataSchema;
            }
        }

        public DataSet GetItems(FilterContext context, QueryArguments arguments, int fromIndex, int pageSize)
        {
            #region Parameters Validation

            new FilterContextValidator(ServiceInfo.FilterSchema).Enforce(context);
            new QueryArgumentsValidator(ServiceInfo.TableMapping.ColumnMappings).Enforce(arguments);
            new PageSizeValidator(Settings.Default.DefaultPageSize).Enforce(pageSize);

            #endregion

            using (DatabaseContext database = SetupDatabaseContext())
            {
                // Build a dataset for data retrieval.
                DataSet resultData = BuildDataSchemaWithCustomFieldXml(ServiceInfo.ServiceSchema, ServiceInfo.CustomFieldsInfo != null);

                // Build mapping of the result dataset to query columns.
                DataTableMapping tableMapping = BuildTableMapping(ServiceInfo.TableMapping);

                // Collect query parameters to select data from the database.
                QueryArguments queryArguments = BuildQueryArguments(arguments, context);

                DbConnection connection = null;
                try
                {
                    connection = Provider.CreateConnection();
                    connection.Open();

                    SyncSqlBuilder commandManager = new SyncSqlBuilder(DatabaseContext.Current);

                    // Build a command for data retrieval.
                    using (DbCommand command = commandManager.GenerateCommand(
                        ServiceInfo.TableName,
                        GetQueryColumns(tableMapping.ColumnMappings),
                        queryArguments.Filter,
                        ServiceInfo.CustomFieldsInfo == null ? null : ServiceInfo.CustomFieldsInfo.SourceTable,
                        ServiceInfo.CustomFieldsInfo == null ? null : ServiceInfo.CustomFieldsInfo.LinkField,
                        pageSize))
                    {
                        command.Connection = connection;
                        // Build an adapter for data retrieval.
                        using (DbDataAdapter adapter = commandManager.BuildDataAdapter(tableMapping))
                        {
                            adapter.SelectCommand = command;

                            // Retrieve result data.
                            adapter.Fill(resultData);
                        }
                    }
                }
                finally
                {
                    if (connection != null)
                    {
                        connection.Close();
                        connection = null;
                    }
                }

                FillCustomColumnsInSourceDataTable(resultData, ServiceInfo.TableMapping.DataSetTable);
                return resultData;
            }
        }

        public List<System.Guid> GetDeletedItemIDs(FilterContext context, QueryArguments arguments, int fromIndex, int pageSize)
        {
            throw FaultExceptionHelper.CreateNotSupportedFault();
        }

        public Guid UpdateItem(DataSet data)
        {
            throw FaultExceptionHelper.CreateNotSupportedFault();
        }

        public FilterSchema GetFilterSchema()
        {
            throw FaultExceptionHelper.CreateNotSupportedFault();
        }

        public DisplayValuesCollection GetFilterData(string filterId, FilterContext currentValues)
        {
            throw FaultExceptionHelper.CreateNotSupportedFault();
        }

        public ActionsCollection GetActions()
        {
            throw FaultExceptionHelper.CreateNotImplementedFault();
        }

        public ActionResult InvokeAction(string actionId, DataSet data)
        {
            throw FaultExceptionHelper.CreateNotImplementedFault();
        }

        public bool IsDataReplicationPermitted()
        {
            return true;
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        private DatabaseContext SetupDatabaseContext()
        {
            return DatabaseContext.Start(Provider);
        }

        private static DataTableMapping BuildTableMapping(DataTableMapping serviceInfo)
        {
            DataTableMapping tableMapping = new DataTableMapping(
                serviceInfo.SourceTable,
                serviceInfo.DataSetTable);

            foreach (DataColumnMapping mapping in serviceInfo.ColumnMappings)
            {
                tableMapping.ColumnMappings.Add(mapping.SourceColumn, mapping.DataSetColumn);
            }

            return tableMapping;
        }

        private static DataSet BuildDataSchemaWithCustomFieldXml(DataSet typedSchema, bool isCustomFieldsSupported)
        {
            DataSet untypedSchema = DataSetConverter.GetUntypedDataSetSchema(typedSchema);
            if (isCustomFieldsSupported)
            {
                untypedSchema.Tables[0].Columns.Add("CustomFields");
            }
            return untypedSchema;
        }

        /// <summary>
        /// Gets the collection of columns' source names in DataColumnMappingCollection.
        /// </summary>
        /// <param name="columnMappings">The collection of column mappings to inspect.</param>
        private static IEnumerable<string> GetQueryColumns(DataColumnMappingCollection columnMappings)
        {
            foreach (DataColumnMapping mapping in columnMappings)
            {
                yield return mapping.SourceColumn;
            }
        }

        private QueryArguments BuildQueryArguments(QueryArguments candidateArguments, FilterContext context)
        {
            // Map the DataSet arguments to correspondent source columns.
            QueryArguments resultArguments = QueryArgumentsManager.MapQueryArgumentsToSourceColumns(candidateArguments, ServiceInfo.TableMapping.ColumnMappings);

            // Map the filter context to correspondent source columns.
            TableFilter contextFilter = QueryArgumentsManager.MapFilterContextToSourceColumns(context, ServiceInfo.FilterSchema);

            // Join the filter context with source arguments
            resultArguments.Filter.AddRange(contextFilter);

            return resultArguments;
        }

        /// <summary>
        /// Add custom columns to the source dataset table with name defined in SourceDataTableName.
        /// </summary>
        /// <param name="dataSet">Source dataset.</param>
        /// <param name="tableName">dataset table name</param>
        private void AddCustomColumnsToSourceDataTable(DataSet dataSet, string tableName)
        {
            ArgumentUtilities.EnsureArgumentNotNull(dataSet, "dataSet");
            ArgumentUtilities.EnsureArgumentNotNullOrEmpty(tableName, "tableName");

            // Process customs fields only if they are supported for this record type
            if (ServiceInfo.CustomFieldsInfo == null)
            {
                return;
            }

            CustomFieldsProcessor customFieldsProcessor = new CustomFieldsProcessor(CustomFieldsManager);
            customFieldsProcessor.AddCustomColumnsToDataSet(dataSet, tableName);
        }

        /// <summary>
        /// Adds the custom columns to the source dataset table with name defined in SourceDataTableName
        /// and try to fill custom columns with data from.
        /// </summary>
        /// <param name="data">Source dataset.</param>
        private void FillCustomColumnsInSourceDataTable(DataSet data, string tableName)
        {
            ArgumentUtilities.EnsureArgumentNotNull(data, "data");

            // Process customs fields only if they are supported for this record type
            if (ServiceInfo.CustomFieldsInfo == null)
            {
                return;
            }

            CustomFieldsProcessor customFieldsProcessor = new CustomFieldsProcessor(CustomFieldsManager);
            customFieldsProcessor.MergeDataSetWithCustomColumns(data, tableName);
        }

        #endregion
    }
}
