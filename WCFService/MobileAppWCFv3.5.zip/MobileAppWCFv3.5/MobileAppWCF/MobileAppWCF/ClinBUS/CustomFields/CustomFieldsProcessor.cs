﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using System.Linq;
using TranSenda.Corpus.Synchronization.CustomFieldsManagement;
using TranSenda.Corpus.Synchronization;

namespace TranSenda.Corpus.Synchronization.ClinBUS.CustomFields
{
    public sealed class CustomFieldsProcessor
    {
        private const string CUSTOM_FIELD_NAME = "Custom Fields";
        private const string OBJECT_ID = "Id";

        private ICustomFieldsManager _customFieldsManager;

        public CustomFieldsProcessor(ICustomFieldsManager customFieldsManager)
        {
            ArgumentUtilities.EnsureArgumentNotNull(customFieldsManager, "customFieldsManager");
            _customFieldsManager = customFieldsManager;
        }

        /// <summary>
        /// Add the custom columns to the source dataset table with name defined in tableName.
        /// </summary>
        /// <param name="dataSet">Source dataset.</param>
        /// <param name="tableName">Name of the source dataset table</param>
        /// <returns>The number of added columns</returns>
        public int AddCustomColumnsToDataSet(DataSet dataSet, string tableName)
        {
            ArgumentUtilities.EnsureArgumentNotNull(dataSet, "dataSet");
            ArgumentUtilities.EnsureArgumentNotNullOrEmpty(tableName, "tableName");

            DataTable table = dataSet.Tables[tableName];
            int columnCount = table.Columns.Count;

            VerifyThatTableDoesNotContainColumsFromCFDefinition(table, _customFieldsManager.FieldDefinitions);

            // Add custom columns to DataSet
            foreach (CustomFieldDef customsFieldDefinition in _customFieldsManager.FieldDefinitions)
            {
                AddCustomColumn(table, customsFieldDefinition);
            }

            // Prevent the system internal CustomFields column display
            if (table.Columns.Contains(CUSTOM_FIELD_NAME))
            {
                table.Columns.Remove(CUSTOM_FIELD_NAME);
            }
            dataSet.AcceptChanges();

            return table.Columns.Count - columnCount;
        }

        public void MergeDataSetWithCustomColumns(DataSet dataSet, string tableName)
        {
            ArgumentUtilities.EnsureArgumentNotNull(dataSet, "dataSet");
            ArgumentUtilities.EnsureArgumentNotNullOrEmpty(tableName, "tableName");

            int numberNewColumns = AddCustomColumnsToDataSet(dataSet, tableName);

            if (numberNewColumns > 0)
            {
                DataTable dataTable = dataSet.Tables[tableName];

                // Fill the custom columns with data
                foreach (DataRow row in dataTable.Rows)
                {
                    IEnumerable<CustomFieldData> rowCustomFieldsData = CustomFieldsDataManager.Extract(row);

                    foreach (CustomFieldData fieldValue in rowCustomFieldsData)
                    {
                        if (IsTableContainCustomColumn(dataTable, fieldValue))
                        {
                            VerifyThatCustomFieldDataTypeMatchesTableColumnType(dataTable, fieldValue);

                            row[fieldValue.ColumnName()] = fieldValue.Value;
                        }
                    }
                }

                dataSet.AcceptChanges();
            }
        }

        #region Helper methods

        /*
        private IEnumerable<CustomFieldData> GatherDataFromDataTable(DataTable dataTable)
        {
            // Gather data from the first record only
            DataRow row = dataTable.Rows[0];
            List<CustomFieldData> customFieldsData = new List<CustomFieldData>();

            foreach (CustomFieldDef fieldDef in _customFieldsManager.FieldDefinitions)
            {
                string customColumnName = fieldDef.ColumnName();
                if (dataTable.Columns.Contains(customColumnName))
                {
                    VerifyThatTableContainsColumnWithCorrectType(dataTable, fieldDef);

                    object columnValue = row[customColumnName];
                    if (columnValue != null)
                    {
                        string value = columnValue.ToString();
                        if (!string.IsNullOrEmpty(value))
                        {
                            CustomFieldData data = CustomFieldData.CreateData(fieldDef, value);
                            customFieldsData.Add(data);
                        }
                    }
                }
            }
            return customFieldsData;
        }
        */
        private static bool IsStringConverted(string input, Type targetType)
        {
            try
            {
                TypeDescriptor.GetConverter(targetType).ConvertFromString(input);
                return true;
            }
            catch (NotSupportedException)
            {
                return false;
            }
        }

        #endregion

        #region Validate rules

        private static void VerifyThatCustomFieldDataTypeMatchesTableColumnType(DataTable table, CustomFieldData fieldData)
        {
            string columnName = fieldData.ColumnName();
            if (!IsStringConverted(fieldData.Value, table.Columns[columnName].DataType))
            {
                throw new OperationException(
                    string.Format(CultureInfo.InvariantCulture, "Custom field processing: '{0}' field value cannot be converted to the data set column type", fieldData.Id.GetCTMObjectId()));
            }
        }

        private static void VerifyThatTableDoesNotContainColumsFromCFDefinition(DataTable table, IEnumerable<CustomFieldDef> customFieldsDef)
        {
            IEnumerable<string> duplicatedColumns = customFieldsDef
                .Where(def => table.Columns.Contains(def.ColumnName()))
                .Select(def => def.Alias);
            if (duplicatedColumns.Count() > 0)
            {
                throw new OperationException(
                    string.Format(CultureInfo.InvariantCulture, "Custom field processing: The data set already contains the following columns: {0}.",
                                  string.Join(",", duplicatedColumns.ToArray())));
            }
        }

        private static bool IsTableContainCustomColumn(DataTable table, CustomFieldData fieldData)
        {
            return table.Columns.Contains(fieldData.ColumnName());
        }

        /*
        private static void VerifyThatTableContainsColumnWithCorrectType(DataTable dataTable, CustomFieldDef fieldDef)
        {
            string columnName = fieldDef.ColumnName();
            if (dataTable.Columns.Contains(columnName))
            {
                if (dataTable.Columns[columnName].DataType != CustomFieldTypeConvertor.ConvertToDotNetType(fieldDef.FieldType))
                {
                    throw new OperationException(
                        string.Format(CultureInfo.InvariantCulture, "Custom field processing: Type of the {0} data set column doesn't match the meta info type.", fieldDef.Alias));
                }
            }
        }
         */ 

        private static void AddCustomColumn(DataTable table, CustomFieldDef fieldDef)
        {
            DataColumn column = table.Columns.Add(fieldDef.ColumnName(), CustomFieldTypeConvertor.ConvertToDotNetType(fieldDef.FieldType));
            column.Caption = fieldDef.Alias;
            column.AllowDBNull = true;
            column.ReadOnly = false;

            if (fieldDef.FieldType == CustomFieldType.Text)
            {
                column.MarkAsSingleLine();
            }
        }

        #endregion

    }
}
