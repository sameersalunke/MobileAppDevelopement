﻿using System;
using System.Collections.Generic;
using TranSenda.Corpus.Synchronization.CustomFieldsManagement;

namespace TranSenda.Corpus.Synchronization.ClinBUS.CustomFields
{
    public interface ICustomFieldsManager
    {
        IEnumerable<CustomFieldDef> FieldDefinitions
        {
            get;
        }
    }
}
