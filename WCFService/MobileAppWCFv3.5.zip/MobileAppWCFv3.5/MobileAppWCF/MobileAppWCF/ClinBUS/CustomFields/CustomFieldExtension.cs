﻿using System;
using System.Text;
using TranSenda.Corpus.Synchronization.CustomFieldsManagement;

namespace TranSenda.Corpus.Synchronization.ClinBUS.CustomFields
{
    internal static class CustomFieldExtension
    {
        public static string ColumnName(this CustomFieldDef field)
        {
            return ToColumnName(field.Id);
        }

        public static string ColumnName(this CustomFieldData field)
        {
            return ToColumnName(field.Id);
        }

        /// <summary>
        /// The method generates the internal column name for a custom column Id.
        /// </summary>
        /// <remarks>
        /// For internal field names, SharePoint follows the convention that
        /// an internal field name is a 32-char length string started from an Alpha character.
        /// </remarks>
        /// <param name="id">a custom column Id</param>
        /// <returns>internal column name</returns>
        private static string ToColumnName(Guid id)
        {
            StringBuilder name = new StringBuilder(id.ToString("N").ToUpperInvariant());
            if (Char.IsDigit(name[0]))
            {
                // Enforce the 1st character to be an Alpha character.
                name[0] = Convert.ToChar(Convert.ToUInt16('G') + Convert.ToUInt16(name[0]) - Convert.ToUInt16('0'));
            }
            return name.ToString();
        }
    }
}
