﻿using System;
using TranSenda.Corpus.Synchronization.CustomFieldsManagement;

namespace TranSenda.Corpus.Synchronization.ClinBUS.CustomFields
{
    public static class CustomFieldTypeConvertor
    {
        public static Type ConvertToDotNetType(CustomFieldType customsFieldType)
        {
            switch (customsFieldType)
            {
                case CustomFieldType.Text:
                    return typeof(String);
                case CustomFieldType.Number:
                    return typeof(Double);
                case CustomFieldType.Date:
                    return typeof(DateTime);
                default:
                    throw new ArgumentOutOfRangeException("customsFieldType");
            }
        }
    }
}
