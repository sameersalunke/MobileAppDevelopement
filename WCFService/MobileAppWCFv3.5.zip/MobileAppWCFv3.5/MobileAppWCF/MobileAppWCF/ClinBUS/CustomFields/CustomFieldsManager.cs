﻿using System;
using System.Collections.Generic;
using TranSenda.Corpus.Synchronization.CustomFieldsManagement;

namespace TranSenda.Corpus.Synchronization.ClinBUS.CustomFields
{
    internal sealed class CustomFieldsManager : ICustomFieldsManager
    {
        #region Fields

        private CustomFieldsMetaInfoManager _customFieldsMetaInfoManager;
        private List<CustomFieldDef> _fieldDefinitions = null;

        #endregion

        #region Constructors

        public CustomFieldsManager(Guid entityId)
            : this(entityId, new CustomFieldsMetaInfoRepository())
        {
        }

        public CustomFieldsManager(Guid entityId, ICustomFieldsMetaInfoRepository customFieldsMetaInfoRepository)
        {
            ArgumentUtilities.EnsureArgumentNotNull(customFieldsMetaInfoRepository, "customFieldsMetaInfoRepository");
            _customFieldsMetaInfoManager = new CustomFieldsMetaInfoManager(entityId, customFieldsMetaInfoRepository);
        }

        #endregion

        public IEnumerable<CustomFieldDef> FieldDefinitions
        {
            get
            {
                if (_fieldDefinitions == null)
                {
                    _fieldDefinitions = new List<CustomFieldDef>(_customFieldsMetaInfoManager.GetFieldDefinitions());
                }

                return _fieldDefinitions;
            }
        }
    }
}
