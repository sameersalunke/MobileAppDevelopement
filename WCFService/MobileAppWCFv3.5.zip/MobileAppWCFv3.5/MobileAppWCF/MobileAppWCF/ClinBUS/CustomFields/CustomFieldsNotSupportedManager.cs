﻿using System.Collections.Generic;
using TranSenda.Corpus.Synchronization.CustomFieldsManagement;

namespace TranSenda.Corpus.Synchronization.ClinBUS.CustomFields
{
    public sealed class CustomFieldsNotSupportedManager : ICustomFieldsManager
    {
        private readonly List<CustomFieldDef> _definitions = new List<CustomFieldDef>();

        #region ICustomFieldsManager Members

        public IEnumerable<CustomFieldDef> FieldDefinitions
        {
            get
            {
                return _definitions;
            }
        }

        #endregion
    }
}
