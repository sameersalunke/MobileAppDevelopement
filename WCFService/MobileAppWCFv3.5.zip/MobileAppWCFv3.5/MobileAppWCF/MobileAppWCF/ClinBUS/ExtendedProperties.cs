﻿using System.Data;

namespace TranSenda.Corpus.Synchronization.ClinBUS
{
    public static class DataColumnExtensions
    {
        public static void MarkAsSingleLine(this DataColumn column)
        {
            ArgumentUtilities.EnsureArgumentNotNull(column, "column");
            column.MaxLength = Constants.MAX_LENGTH_450;
        }
    }
}
