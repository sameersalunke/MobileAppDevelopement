﻿using System;
namespace TranSenda.Corpus.Synchronization.ClinBUS
{
    internal sealed class CustomFieldsMetadata
    {
        public string SourceTable
        {
            get;
            set;
        }

        public string LinkField
        {
            get;
            set;
        }

        public Guid EntityId
        {
            get;
            set;
        }
    }
}
