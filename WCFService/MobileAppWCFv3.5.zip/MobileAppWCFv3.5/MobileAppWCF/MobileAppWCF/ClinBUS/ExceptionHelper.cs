﻿using System;

namespace TranSenda.Corpus.Synchronization.ClinBUS
{
    internal static class ExceptionHelper
    {
        internal static Exception CreateInvalidFilterContextItemException(string columnName)
        {
            string errorMessage = ExceptionResources.InvalidFilterContextItemException.ApplyArgumentsInvariantCulture(columnName);
            return new SyncException(errorMessage);
        }

        internal static Exception CreatePageSizeIsOutOfRangeException(int pageSize)
        {
            string errorMessage = ExceptionResources.PageSizeIsOutOfRangeException.ApplyArgumentsInvariantCulture(pageSize);
            return new SyncException(errorMessage);
        }

        internal static Exception CreateInvalidQueryArgumentItemException(string columnName)
        {
            string errorMessage = ExceptionResources.InvalidQueryArgumentItemException.ApplyArgumentsInvariantCulture(columnName);
            return new SyncException(errorMessage);
        }

        internal static Exception CreateDiscoveryServiceManifestNotFoundException(Uri discoveryUri)
        {
            string errorMessage = ExceptionResources.DiscoveryServiceManifestNotFoundException.ApplyArgumentsInvariantCulture(discoveryUri);
            return new SyncException(errorMessage);
        }

        internal static Exception CreateDiscoveryServiceNotSpecifiedException()
        {
            return new SyncException(ExceptionResources.DiscoveryServiceNotSpecifiedException);
        }

        internal static Exception CreateSourceNotSpecifiedException()
        {
            return new SyncException(ExceptionResources.SourceNotSpecifiedException);
        }

        internal static Exception CreateServiceMetadataIdNotSpecifiedException()
        {
            return new SyncException(ExceptionResources.ServiceMetadataIdNotSpecifiedException);
        }

        internal static Exception CreateServiceMetadataDbVersionNotSpecifiedException()
        {
            return new SyncException(ExceptionResources.ServiceMetadataDbVersionNotSpecifiedException);
        }

        internal static Exception CreateServiceMetadataConnectionStringNotSpecifiedException()
        {
            return new SyncException(ExceptionResources.ServiceMetadataConnectionStringNotSpecifiedException);
        }

        internal static Exception CreateServiceMetadataTableNameNotSpecifiedException()
        {
            return new SyncException(ExceptionResources.ServiceMetadataTableNameNotSpecifiedException);
        }

        internal static Exception CreateServiceMetadataServiceSchemaNotSpecifiedException()
        {
            return new SyncException(ExceptionResources.ServiceMetadataServiceSchemaNotSpecifiedException);
        }

        internal static Exception CreateServiceMetadataTableMappingNotSpecifiedException()
        {
            return new SyncException(ExceptionResources.ServiceMetadataTableMappingNotSpecifiedException);
        }
    }
}
