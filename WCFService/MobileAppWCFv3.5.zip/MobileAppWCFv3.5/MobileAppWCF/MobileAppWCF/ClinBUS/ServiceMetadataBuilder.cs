﻿using System;
using System.Data;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;

namespace TranSenda.Corpus.Synchronization.ClinBUS
{
    internal sealed class ServiceMetadataBuilder
    {
        private readonly MetadataManager _manager;

        private MetadataManager Manager
        {
            get
            {
                return _manager;
            }
        }

        public ServiceMetadataBuilder()
            : this(new MetadataManager(new FileMetadataStorage()))
        {
        }

        public ServiceMetadataBuilder(MetadataManager manager)
        {
            ArgumentUtilities.EnsureArgumentNotNull(manager, "manager");
            _manager = manager;
        }

        /// <summary>
        /// The method creates a new ServiceMetadata instance
        /// with properly collected data.
        /// </summary>
        /// <param name="discoveryUri"></param>
        /// <param name="sourceId"></param>
        /// <returns>created ServiceMetadata instance</returns>
        /// <remarks>To get more details about CA suppression <see cref="http://brokencode.blogspot.com/2005/08/to-call-or-not-to-call-dispose-on.html">
        /// To call or not to call dispose on DataSet</see></remarks>
        [SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope", Justification = "The DataSet does not have a container, we'll never have to call dispose method on DataSets.")]
        public ServiceMetadata Build(Uri discoveryUri, string sourceId)
        {
            #region Arguments Validation

            if (discoveryUri == null)
            {
                throw ExceptionHelper.CreateDiscoveryServiceNotSpecifiedException();
            }

            if (String.IsNullOrEmpty(sourceId))
            {
                throw ExceptionHelper.CreateSourceNotSpecifiedException();
            }

            #endregion

            DiscoveryServiceManifest discoveryManifest = GetDiscoveryManifest(discoveryUri);
            SourceManifest serviceManifest = Manager.GetSourceMetadata(discoveryManifest, sourceId);

            DataSet schema = new DataSet();
            schema.Locale = CultureInfo.CurrentCulture;

            Manager.GetDataSetSchema(discoveryManifest, serviceManifest, schema);

            return ServiceMetadata.Build(discoveryManifest.DbVersion, discoveryManifest.ConnectionString, schema, serviceManifest);
        }

        private DiscoveryServiceManifest GetDiscoveryManifest(Uri discoveryUri)
        {
            DiscoveryServiceManifests registry = Manager.LoadDiscoveryServicesRegistry();
            DiscoveryServiceManifest discoveryManifest = registry.Find(discoveryUri);

            if (discoveryManifest == null)
            {
                if (registry.Count > 0)
                {
                    discoveryManifest = registry.ElementAt(0);
                }
                else
                {
                    throw ExceptionHelper.CreateDiscoveryServiceManifestNotFoundException(discoveryUri);
                }
            }
            return discoveryManifest;
        }
    }
}
