﻿using System.Data;
using System.Diagnostics.CodeAnalysis;

namespace TranSenda.Corpus.Synchronization.Utilities
{
    public static class DataSetConverter
    {
        /// <summary>
        /// The method copies the structure of the typed dataset.
        /// The method does not copy any data from the typed dataset.
        /// </summary>
        /// <param name="typedSchema">typed dataset schema to be copied</param>
        /// <returns>an untyped dataset corresponding to the structure of the typed dataset</returns>
        /// <remarks>To get more details about CA suppression <see cref="http://brokencode.blogspot.com/2005/08/to-call-or-not-to-call-dispose-on.html">
        /// To call or not to call dispose on DataSet</see></remarks>
        [SuppressMessage("Microsoft.Reliability", "CA2000:Dispose objects before losing scope", Justification = "The DataSet does not have a container, we'll never have to call dispose method on DataSets.")]
        public static DataSet GetUntypedDataSetSchema(DataSet typedSchema)
        {
            ArgumentUtilities.EnsureArgumentNotNull(typedSchema, "typedSchema");

            // Clones the schema for the specified typed DataSet.
            DataSet cloneSchema = typedSchema.Clone();

            // Creates an untyped DataSet.
            DataSet untypedSchema = new DataSet();
            untypedSchema.Locale = cloneSchema.Locale;
            untypedSchema.DataSetName = cloneSchema.DataSetName;
            untypedSchema.Prefix = cloneSchema.Prefix;
            untypedSchema.Namespace = cloneSchema.Namespace;
            //untypedSchema.EnforceConstraints = ConfigurationSettings.Default.EnableConstraints && cloneSchema.EnforceConstraints;
            untypedSchema.EnforceConstraints = false;
            untypedSchema.SchemaSerializationMode = cloneSchema.SchemaSerializationMode;

            while (cloneSchema.Tables.Count > 0)
            {
                DataTable cloneDataTable = cloneSchema.Tables[0];
                cloneSchema.Tables.RemoveAt(0);
                untypedSchema.Tables.Add(cloneDataTable);
            }

            return untypedSchema;
        }
    }
}
