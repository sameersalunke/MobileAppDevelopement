﻿using System.ServiceModel;
using TranSenda.Corpus.Synchronization.SourceServiceReference;

namespace TranSenda.Corpus.Synchronization.Utilities
{
    internal static class FaultExceptionHelper
    {
        #region Not Implemented Fault

        public static FaultException<NotImplementedFault> CreateNotImplementedFault()
        {
            return new FaultException<NotImplementedFault>(new NotImplementedFault(), Resource.NotImplemented);
        }

        public static FaultException<NotImplementedFault> CreateNotSupportedFault()
        {
            return new FaultException<NotImplementedFault>(new NotImplementedFault(), Resource.NotSupported);
        }

        #endregion

    }
}
