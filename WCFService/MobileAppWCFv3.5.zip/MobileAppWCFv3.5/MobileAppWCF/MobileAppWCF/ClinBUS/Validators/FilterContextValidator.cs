﻿using System;
using System.Collections.Generic;
using System.Linq;
using MobileAppWCF.SourceService;

namespace TranSenda.Corpus.Synchronization.ClinBUS
{
    /// <summary>
    /// The class ensures that provided FilterContext instance contains supported FilterSchemaItem items only.
    /// </summary>
    internal sealed class FilterContextValidator
    {
        /// <summary>
        /// The FilterSchema instance contains supported FilterShemaItem items only.
        /// </summary>
        private List<FilterMetaInfoItem> Schema
        {
            get;
            set;
        }

        public FilterContextValidator(IEnumerable<FilterMetaInfoItem> schema)
        {
            ArgumentUtilities.EnsureArgumentNotNull(schema, "schema");
            Schema = new List<FilterMetaInfoItem>(schema);
        }

        /// <summary>
        /// The method ensures that the provided FilterContext instance contains supported FilterSchemaItem items only.
        /// If the provided FilterContext instance contains unsupported columns, the method raises an exception.
        /// </summary>
        /// <param name="context">FilterContext instance to validate</param>
        public void Enforce(FilterContext context)
        {
            if (context == null)
            {
                return;
            }

            List<string> supportedColumnNames = Schema.Select(schemaItem => schemaItem.ColumnName).ToList();
            foreach (FilterContextItem contextItem in context)
            {
                bool isSchemaContainItem = supportedColumnNames.Any(columnName => String.Equals(columnName, contextItem.ColumnName, StringComparison.OrdinalIgnoreCase));
                if (!isSchemaContainItem)
                {
                    throw ExceptionHelper.CreateInvalidFilterContextItemException(contextItem.ColumnName);
                }
            }
        }
    }
}
