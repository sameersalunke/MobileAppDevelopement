﻿using System.Data.Common;
using MobileAppWCF.SourceService;

namespace TranSenda.Corpus.Synchronization.ClinBUS
{
    /// <summary>
    /// The class ensures that provided QueryArguments instance contains supported column names only.
    /// </summary>
    internal sealed class QueryArgumentsValidator
    {
        /// <summary>
        /// The supported column names collection.
        /// </summary>
        private DataColumnMappingCollection Mapping
        {
            get;
            set;
        }

        public QueryArgumentsValidator(DataColumnMappingCollection mapping)
        {
            ArgumentUtilities.EnsureArgumentNotNull(mapping, "mapping");
            Mapping = mapping;
        }

        /// <summary>
        /// The method ensures that the provided QueryArguments instance contains supported column names only.
        /// If the provided QueryArguments instance contains unsupported columns, the method raises an exception.
        /// </summary>
        /// <param name="arguments">QueryArguments instance to validate</param>
        public void Enforce(QueryArguments arguments)
        {
            if (arguments == null)
            {
                return;
            }

            if (arguments.Filter != null)
            {
                foreach (TableFilterItem filter in arguments.Filter)
                {
                    if (Mapping.IndexOfDataSetColumn(filter.ColumnName) == -1)
                    {
                        throw ExceptionHelper.CreateInvalidQueryArgumentItemException(filter.ColumnName);
                    }
                }
            }

            if (arguments.Sorting != null)
            {
                foreach (TableSortingItem orderBy in arguments.Sorting)
                {
                    if (Mapping.IndexOfDataSetColumn(orderBy.ColumnName) == -1)
                    {
                        throw ExceptionHelper.CreateInvalidQueryArgumentItemException(orderBy.ColumnName);
                    }
                }
            }
        }
    }
}
