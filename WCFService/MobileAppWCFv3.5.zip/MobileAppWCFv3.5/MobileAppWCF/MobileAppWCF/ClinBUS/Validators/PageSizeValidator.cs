﻿using System;

namespace TranSenda.Corpus.Synchronization.ClinBUS
{
    /// <summary>
    /// The class ensures that requested page size conforms to configuration settings.
    /// </summary>
    internal sealed class PageSizeValidator
    {
        /// <summary>
        /// Configuration settings page size
        /// </summary>
        private int PageSizeSetting
        {
            get;
            set;
        }

        public PageSizeValidator(int pageSizeSetting)
        {
            PageSizeSetting = pageSizeSetting;
        }

        /// <summary>
        /// The method ensures that requested page size conforms to configuration settings.
        /// If the requested page size does not conform configuration settings, the method raises an exception.
        /// </summary>
        /// <param name="pageSize">page size to be validated</param>
        public void Enforce(int pageSize)
        {
            if (pageSize <= 0
                || pageSize > PageSizeSetting)
            {
                throw ExceptionHelper.CreatePageSizeIsOutOfRangeException(pageSize);
            }
        }
    }
}
