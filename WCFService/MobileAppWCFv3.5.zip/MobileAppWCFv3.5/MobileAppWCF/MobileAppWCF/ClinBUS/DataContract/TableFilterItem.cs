﻿using System;
using System.Globalization;
using TranSenda.Corpus.Synchronization.Utilities;
using MetadataFilterOperation = TranSenda.Corpus.Synchronization.FilterOperation;

namespace MobileAppWCF.SourceService
{
    public partial class TableFilterItem
    {
        private const string DefaultSearchConditionFormat = "{3:s}{0:s} {1:s} {2:s}";

        private const string ContainedSearchConditionFormat = @"{1:s}(CHARINDEX(CAST({3:s}{0:s} AS VARCHAR(36)), {2:s}) > 0)";
        private const string ContainsSearchConditionFormat = @"{1:s}(CHARINDEX(CAST({2:s} AS VARCHAR(36)), {3:s}{0:s}) > 0)";

        private const string ContainedSearchConditionFormatNull = @"{1:s}({3:s}{0:s} IS NULL){2:s}"; // 2 - will be empty. The placeholder is left to simplify the algorithm
        private const string ContainsSearchConditionFormatNull = @"{1:s}({3:s}{0:s} IS NULL){2:s}"; // 2 - will be empty. The placeholder is left to simplify the algorithm

        private const string AddNotSpecifiedRegionIdFormat = @"{3:s}{0:s} OR {1:s} = '{2:s}'"; // 0 - Current condition string, 1 - ColumnName, 2 - NotSpecified RegionID

        public TableFilterItem()
        {
        }

        public TableFilterItem(string columnName, FilterOperation operation, object value)
        {
            if (string.IsNullOrEmpty(columnName))
            {
                throw new ArgumentNullException("columnName");
            }

            if (value == null)
            {
                Value = DBNull.Value;
            }
            else
            {
                Value = value;
            }

            ColumnName = columnName;
            Operation = operation;
        }

        public override string ToString()
        {
            return String.Format("{0} {1} '{2}'", ColumnName, Operation, Value);
        }

        public virtual string ToExpression(string parameterName, string tableAlias)
        {
            if (string.IsNullOrEmpty(parameterName))
            {
                throw new ArgumentNullException("parameterName");
            }

            if (string.IsNullOrEmpty(ColumnName))
            {
                throw new InvalidOperationException("A column name must not be empty!");
            }

            string valueString = parameterName;
            string expressionFormat = DefaultSearchConditionFormat;
            string action = string.Empty;
            string fieldSuffix = string.Empty;
            string valueSuffix = string.Empty;

            MetadataFilterOperation operation = (MetadataFilterOperation)((int)Operation);

            if ((operation & MetadataFilterOperation.ContainedIn) != 0)
            {
                if (Value == DBNull.Value)
                {
                    expressionFormat = ContainedSearchConditionFormatNull;
                    action = ((operation & MetadataFilterOperation.Not) == 0) ? string.Empty : "NOT ";
                    valueString = string.Empty;
                }
                else
                {
                    expressionFormat = ContainedSearchConditionFormat;
                    action = ((operation & MetadataFilterOperation.Not) == 0) ? string.Empty : "NOT (ISNULL";
                    valueSuffix = ((operation & MetadataFilterOperation.Not) == 0) ? string.Empty : "), 0";
                }
            }
            else if ((operation & MetadataFilterOperation.Contains) != 0)
            {
                if (Value == DBNull.Value)
                {
                    expressionFormat = ContainsSearchConditionFormatNull;
                    action = ((operation & MetadataFilterOperation.Not) == 0) ? string.Empty : "NOT ";
                    valueString = string.Empty;
                }
                else
                {
                    expressionFormat = ContainsSearchConditionFormat;
                    action = ((operation & MetadataFilterOperation.Not) == 0) ? string.Empty : "NOT (ISNULL";
                    fieldSuffix = ((operation & MetadataFilterOperation.Not) == 0) ? string.Empty : "), 0";
                }
            }
            else if ((operation & MetadataFilterOperation.Like) != 0)
            {
                action = ((operation & MetadataFilterOperation.Not) == 0) ? "LIKE" : "NOT LIKE";
            }
            else if ((operation & MetadataFilterOperation.GreaterThan) != 0)
            {
                action = ((operation & MetadataFilterOperation.Not) == 0) ? ">" : "<=";
            }
            else if ((operation & MetadataFilterOperation.LessThan) != 0)
            {
                action = ((operation & MetadataFilterOperation.Not) == 0) ? "<" : ">=";
            }
            else
            {
                if (Value == DBNull.Value) // IS [NOT] NULL
                {
                    action = ((operation & MetadataFilterOperation.Not) == 0) ? "IS" : "IS NOT";
                    valueString = "NULL";
                }
                else
                {
                    action = ((operation & MetadataFilterOperation.Not) == 0) ? "=" : "<>";
                }
            }

            string alias = string.Empty;
            if (!string.IsNullOrEmpty(tableAlias))
            {
                alias = tableAlias + '.';
            }

            return string.Format(CultureInfo.InvariantCulture, expressionFormat, EncodeUtils.GetQuotedSqlFieldName(ColumnName) + fieldSuffix,
                action, valueString + valueSuffix, alias);
        }

        public static bool TryParseOperator(string operationName, out MetadataFilterOperation operation)
        {
            operation = MetadataFilterOperation.Equal; // Defaulting the operation type: Equal is 0.

            if (string.IsNullOrEmpty(operationName))
            {
                return false;
            }

            try
            {
                string[] names = operationName.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);

                for (int i = 0; i < names.Length; ++i)
                {
                    operation |= (MetadataFilterOperation)Enum.Parse(typeof(MetadataFilterOperation), names[i].Trim(), true);
                }

                return true;
            }
            catch (ArgumentException)
            {
                return false;
            }
        }
    }
}
