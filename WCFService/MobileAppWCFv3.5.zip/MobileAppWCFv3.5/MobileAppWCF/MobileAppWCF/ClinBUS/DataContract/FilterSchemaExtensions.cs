﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace MobileAppWCF.SourceService
{
    internal static class FilterSchemaExtensions
    {
        [SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
        public static FilterSchemaItem FindItemByColumnName(this FilterSchema schema, string columnName)
        {
            ArgumentUtilities.EnsureArgumentNotNull(schema, "schema");
            ArgumentUtilities.EnsureArgumentNotNullOrEmpty(columnName, "columnName");

            return schema.Find(new FilterSchemaItem(columnName).Match);
        }
    }
}
