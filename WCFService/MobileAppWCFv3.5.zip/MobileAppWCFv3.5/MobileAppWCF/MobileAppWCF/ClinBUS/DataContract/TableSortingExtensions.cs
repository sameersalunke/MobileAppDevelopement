﻿namespace MobileAppWCF.SourceService
{
    internal static class TableSortingExtensions
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
        public static TableSorting BuildEmptyTableSorting()
        {
            TableSorting sorting = new TableSorting();
            return sorting;
        }
    }
}
