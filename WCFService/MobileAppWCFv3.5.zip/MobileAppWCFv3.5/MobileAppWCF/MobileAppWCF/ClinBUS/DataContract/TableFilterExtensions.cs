﻿namespace MobileAppWCF.SourceService
{
    internal static class TableFilterExtensions
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1002:DoNotExposeGenericLists")]
        public static TableFilter BuildEmptyTableFilter()
        {
            TableFilter filters = new TableFilter();
            return filters;
        }
    }
}
