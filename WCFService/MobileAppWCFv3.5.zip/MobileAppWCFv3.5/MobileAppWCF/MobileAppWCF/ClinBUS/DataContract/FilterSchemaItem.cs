﻿using System;

namespace MobileAppWCF.SourceService
{
    public partial class FilterSchemaItem
    {
        public FilterSchemaItem(string columnName, string title)
        {
            ArgumentUtilities.EnsureArgumentNotNullOrEmpty(columnName, "columnName");
            ArgumentUtilities.EnsureArgumentNotNullOrEmpty(title, "title");

            ColumnName = columnName;
            Title = title;
        }

        public FilterSchemaItem(string columnName)
            : this(columnName, columnName)
        {
        }

        public bool Match(FilterSchemaItem searched)
        {
            if (searched == null)
            {
                return false;
            }

            return String.Equals(ColumnName, searched.ColumnName, StringComparison.OrdinalIgnoreCase);
        }
    }
}
