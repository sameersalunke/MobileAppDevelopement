﻿using System;

namespace MobileAppWCF.SourceService
{
    public partial class FilterContextItem
    {
        public override string ToString()
        {
            return String.Format("{0} = '{1}'", ColumnName, Value);
        }
    }
}
