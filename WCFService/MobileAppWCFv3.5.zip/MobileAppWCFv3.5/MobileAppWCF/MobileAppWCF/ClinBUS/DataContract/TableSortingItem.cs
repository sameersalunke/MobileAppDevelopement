﻿using System;

namespace MobileAppWCF.SourceService
{
    public partial class TableSortingItem
    {
        public override string ToString()
        {
            return String.Format("{0} {1}", ColumnName, Order);
        }
    }
}
