﻿using System.Text;

namespace MobileAppWCF.SourceService
{
    public partial class QueryArguments
    {
        public static QueryArguments BuildEmptyQueryArguments()
        {
            QueryArguments arguments = new QueryArguments();
            arguments.Filter = TableFilterExtensions.BuildEmptyTableFilter();
            arguments.Sorting = TableSortingExtensions.BuildEmptyTableSorting();

            return arguments;
        }

        public override string ToString()
        {
            StringBuilder ret = new StringBuilder();
            ret.AppendLine(typeof(QueryArguments).ToString());

            ret.AppendLine("Filter:");
            foreach (TableFilterItem item in Filter)
                ret.Append('\t').AppendLine(item.ToString());

            ret.AppendLine("Sorting:");
            foreach (TableSortingItem item in Sorting)
                ret.Append('\t').AppendLine(item.ToString());

            return ret.ToString();
        }
    }
}
