﻿using System.Runtime.Serialization;

namespace MobileAppWCF.SourceService
{
    [DataContract]
    internal class NotImplementedFault : DefaultFault
    {
        public NotImplementedFault()
            : base()
        {
        }

        public NotImplementedFault(string errorMessage)
            : this()
        {
            Message = errorMessage;
        }
    }
}
