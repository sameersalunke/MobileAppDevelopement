﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using MobileAppWCF.SourceService;

namespace TranSenda.Corpus.Synchronization.ClinBUS
{
    internal static class QueryArgumentsManager
    {
        /// <summary>
        /// The predefined "magic" number means that a user selects entities, which are not linked with any region.
        /// </summary>
        public static readonly Guid RegionNotSpecified = new Guid("6D8E8659-9046-47E3-A9DB-8231B291F3A6");

        public static QueryArguments MapQueryArgumentsToSourceColumns(QueryArguments candidateArguments, DataColumnMappingCollection columnMappings)
        {
            ArgumentUtilities.EnsureArgumentNotNull(columnMappings, "columnMappings");

            QueryArguments resultArguments = QueryArguments.BuildEmptyQueryArguments();

            if (candidateArguments == null)
            {
                return resultArguments;
            }

            if (candidateArguments.Filter != null)
            {
                foreach (TableFilterItem candidateFilter in candidateArguments.Filter)
                {
                    string sourceColumn = columnMappings.GetByDataSetColumn(candidateFilter.ColumnName).SourceColumn;
                    TableFilterItem filter = new TableFilterItem
                    {
                        ColumnName = sourceColumn,
                        Operation = candidateFilter.Operation,
                        Value = candidateFilter.Value
                    };
                    resultArguments.Filter.Add(filter);
                }
            }

            if (candidateArguments.Sorting != null)
            {
                foreach (TableSortingItem candidateSorting in candidateArguments.Sorting)
                {
                    string sourceColumn = columnMappings.GetByDataSetColumn(candidateSorting.ColumnName).SourceColumn;
                    TableSortingItem sorting = new TableSortingItem
                    {
                        ColumnName = sourceColumn,
                        Order = candidateSorting.Order
                    };
                    resultArguments.Sorting.Add(sorting);
                }
            }

            return resultArguments;
        }

        public static TableFilter MapFilterContextToSourceColumns(FilterContext context, IEnumerable<FilterMetaInfoItem> filterSchema)
        {
            ArgumentUtilities.EnsureArgumentNotNull(filterSchema, "filterSchema");

            TableFilter filter = TableFilterExtensions.BuildEmptyTableFilter();

            if (context == null)
            {
                return filter;
            }

            foreach (FilterContextItem contextItem in context)
            {
                FilterMetaInfoItem filterSchemaItem = filterSchema.Single(item => String.Equals(item.ColumnName, contextItem.ColumnName, StringComparison.OrdinalIgnoreCase));
                filter.Add(new TableFilterItem
                    {
                        ColumnName = filterSchemaItem.ColumnName,
                        Operation = (MobileAppWCF.SourceService.FilterOperation)((int)filterSchemaItem.Operation),
                        Value = RemoveRegionNotSpecifiedIdentifier(contextItem.Value)
                    });
            }
            return filter;
        }

        /// <summary>
        /// The function finds the predefined "magic" number in the filter context
        /// and replaces this "magic" value with the "IS NULL" condition.
        ///
        /// IMPORTANT NOTE:
        /// It hopes that the RegionItem contains Guid values only.
        /// </summary>
        /// <param name="candidateValue"></param>
        private static object RemoveRegionNotSpecifiedIdentifier(object candidateValue)
        {
            if (ConvertAsGuid(candidateValue) == RegionNotSpecified)
            {
                return null;
            }
            else
            {
                return candidateValue;
            }
        }

        private static Guid? ConvertAsGuid(object input)
        {
            if (input is Guid)
            {
                return (Guid)input;
            }

            string candidateId = input as string;
            if (!String.IsNullOrEmpty(candidateId))
            {
                Guid resultId;
                if (GuidExtensions.TryParse(candidateId, out resultId))
                {
                    return resultId;
                }
            }
            return null;
        }
    }
}
