﻿namespace TranSenda.Corpus.Synchronization.ClinBUS
{
    internal static class Constants
    {
        public const int MAX_LENGTH_1GB = 1073741823;
        public const int MAX_LENGTH_450 = 450;
    }
}
