﻿
using System.Data.Services.Common;
namespace MobileAppWCF.Models
{
     [DataServiceKeyAttribute("ID")]
    public class SAEDetails
    {
        public string Title{get; set;}
        public string ID { get; set; }
        public string SAE_Number { get; set; }
        public string SAE_Onset_Date { get; set; }
        public string SAE_Reported_Term { get; set; }
        public string Date_Site_Notified { get; set; }
        public string Date_Reported_to_Product_Container { get; set; }
        public string IRB_Notified { get; set; }
        public string Date_Reported_to_IRB { get; set; }
        public string Recorded_on_AE_Log { get; set; }
        public string Was_SAE_Expected { get; set; }
        public string Report_Type { get; set; }
        public string Event_Grade { get; set; }
        public string SAE_Description { get; set; }
        public string SAE_Comments { get; set; }
        public string Linked_Study { get; set; }
        public string Linked_Site { get; set; }
        public string Linked_Monitoring_Visit { get; set; }
        public string Linked_Screening { get; set; }
    }
}
