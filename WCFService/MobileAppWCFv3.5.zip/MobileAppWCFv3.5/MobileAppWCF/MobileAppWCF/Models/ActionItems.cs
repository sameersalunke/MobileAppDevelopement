﻿using System;
using System.Data.Services.Common;
using System.Runtime.Serialization;

namespace MobileAppWCF.Models
{
    [DataServiceKeyAttribute("ID")]
    public class ActionItems
    {

        public string Task_Name { get; set; }
        
        public string ID { get; set; }

        public string Action_Item_Deviation_Number { get; set; }

        public string Start_Date { get; set; }

        public string Due_Date { get; set; }

        public string Assigned_To { get; set; }

        public string Assigned_To_Id { get; set; }
        
        public string Status { get; set; }
        
        public string Description { get; set; }

        public string Action_Item_Deviation_Category { get; set; }

        public string Action_Item_Created_By { get; set; }

        public string Linked_Study { get; set; }

        public string Linked_Site { get; set; }

        public string Linked_Visit { get; set; }

        public string AIRRecs_Linked_Visit { get; set; }

        public string Linked_Assigned_Monitor { get; set; } 
    }
}
