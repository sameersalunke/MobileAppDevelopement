﻿
namespace MobileAppWCF
{
    public class APIResponse
    {
        public string success { get; set; }
        public string errorMessage { get; set; }
        public string result { get; set; }       

    }
}
