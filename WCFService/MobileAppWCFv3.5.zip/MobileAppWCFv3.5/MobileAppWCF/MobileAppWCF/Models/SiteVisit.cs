﻿
using System.Data.Services.Common;
namespace MobileAppWCF.Models
{
    [DataServiceKeyAttribute("ID")]
    public class SiteVisit
    {
        public string Title { get; set; }
        public string ID { get; set; }
        public string Start_Date { get; set; }
        public string End_Date { get; set; }
        public string All_Day_Event { get; set; }
        public string Monitoring_Visit_Number { get; set; }
        public string Monitoring_Visit_status { get; set; }
        public string Visit_Type { get; set; }
        public string Assigned_To { get; set; }
        public string Linked_Study { get; set; }
        public string Linked_Site { get; set; }
        public string Linked_Monitor { get; set; }
        public string Location { get; set; }
    }
}
