﻿using Microsoft.SharePoint;
using MobileAppWCF.FactoryClasses;
using MobileAppWCF.HelperClasses;
using MobileAppWCF.SourceService;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Services;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.ServiceModel.Web;
using System.Text;
using System.Web;
namespace MobileAppWCF.Models
{
    public class DAL
    {
        string connString = string.Empty;
        Logger log = null;
        public DAL()
        {
            this.Initialize();
        }
       
        public void Initialize()
        {
            try
            {
                log = new Logger();
                Helperclass helperclass = new Helperclass();
                connString = connString = helperclass.CreateConnection();                
            }
            catch (Exception ex)
            {
                
                log.WriteInfoToTextFile(ex.Message, Constants.functNameInitialize,Constants.classNameDAL, EventLogEntryType.Error);
                throw ex;
                //HttpContext context = HttpContext.Current;
                //context.Response.StatusCode = 401;
                //context.Response.End();
            }
        }
        public List<SAEDetails> GetSAEDetails()
        {
            try
            {
                SqlParameter[] paramArray = new SqlParameter[1];
                string userName = string.Empty;
                if (SPContext.Current != null)
                {
                    var user = SharePointHelper.GetSharePointUserName(SPContext.Current.Web.CurrentUser);
                    var username = user.Split('\\');
                    if (username.Length > 1)
                        userName = username[1];
                    else
                        userName = user;
                }
                paramArray[0] = new SqlParameter(Constants.sqlParamUserName, userName);
                DataSet ds = CallStoreProc(Constants.spGetSAEDetails, paramArray);
                if (ds != null)
                {
                    List<SAEDetails> rows = new List<SAEDetails>();
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        rows.Add(new SAEDetails()
                        {
                            Title = dr[Constants.title].ToString(),
                            ID = dr[Constants.id].ToString(),
                            SAE_Number = dr[Constants.saeNumber].ToString(),
                            SAE_Onset_Date = GetUTCDate(dr[Constants.saeOnsetDate].ToString()),
                            SAE_Reported_Term = dr[Constants.saeReportedTerm].ToString(),
                            Date_Site_Notified = GetUTCDate(dr[Constants.dateSiteNotified].ToString()),
                            Date_Reported_to_Product_Container = GetUTCDate(dr[Constants.dateReportedProductContainer].ToString()),
                            IRB_Notified = dr[Constants.irbNotified].ToString(),
                            Date_Reported_to_IRB = GetUTCDate(dr[Constants.dateReportedIRB].ToString()),
                            Recorded_on_AE_Log = dr[Constants.recordedAELog].ToString(),
                            Was_SAE_Expected = dr[Constants.wasSAEExpected].ToString(),
                            Report_Type = dr[Constants.reportType].ToString(),
                            Event_Grade = dr[Constants.eventGrade].ToString(),
                            SAE_Description = dr[Constants.saeDescription].ToString(),
                            SAE_Comments = dr[Constants.saeComments].ToString(),
                            Linked_Study = dr[Constants.linkedStudy].ToString(),
                            Linked_Screening = dr[Constants.linkedScreening].ToString(),
                            Linked_Site = dr[Constants.linkedSite].ToString(),
                            Linked_Monitoring_Visit = dr[Constants.linkedMonitoringVisit].ToString()

                        });
                        
                    }
                    ds.Dispose();
                    return rows;                    
                }
               

                //string JSONString = string.Empty;
                //JSONString = JsonConvert.SerializeObject(ds.Tables[0]);
                //return JSONString;  

                //System.Web.Script.Serialization.JavaScriptSerializer serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                //List<Dictionary<string, object>> rows = new List<Dictionary<string, object>>();
                //Dictionary<string, object> row;
                //foreach (DataRow dr in ds.Tables[0].Rows)
                //{
                //    row = new Dictionary<string, object>();
                //    foreach (DataColumn col in ds.Tables[0].Columns)
                //    {
                //        row.Add(col.ColumnName, dr[col]);
                //    }
                //    rows.Add(row);
                //}
                //return serializer.Serialize(rows);
                //return ds.Tables[0];

                //}
            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, Constants.functNameGetSAEDetails,Constants.classNameDAL, EventLogEntryType.Error);
            }
            return null;
        }
        public List<ProtocolDeviation> GetProtocolDeviations()
        {
            try
            {
                SqlParameter[] paramArray = new SqlParameter[1];
                string userName = string.Empty;
                if (SPContext.Current != null)
                {
                    var user = SharePointHelper.GetSharePointUserName(SPContext.Current.Web.CurrentUser);
                    var username = user.Split('\\');
                    if (username.Length > 1)
                        userName = username[1];
                    else
                        userName = user;
                }
                paramArray[0] = new SqlParameter(Constants.sqlParamUserName, userName);
                DataSet ds = CallStoreProc(Constants.spGetProtocolDeviations, paramArray);
                if (ds != null)
                {
                    List<ProtocolDeviation> rows = new List<ProtocolDeviation>();
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        rows.Add(new ProtocolDeviation()
                        {            
                            Title  = dr[Constants.title].ToString(),
                            ID = dr[Constants.id].ToString(),
                            Modified_Date = GetUTCDate(dr[Constants.CTM_Modified_Date].ToString()),
                            Linked_Site = dr[Constants.linkedSite].ToString(),
                            Linked_Study = dr[Constants.linkedStudy].ToString(),
                            Linked_Visit  = dr[Constants.linkedVisit].ToString(),
                            Linked_Screening = dr[Constants.linkedScreening].ToString(),
                            Deviation_Number  = dr[Constants.deviationNumber].ToString(),
                            Deviation_Date = GetUTCDate(dr[Constants.deviationDate].ToString()),
                            Description  = dr[Constants.description].ToString(),
                            Deviation_Submitted_to_IRB  = dr[Constants.deviationSubmittedtoIRB].ToString(),
                            Deviation_CRA_Reviewer  = dr[Constants.CRAReviewer].ToString(),
                            Deviation_Category  = dr[Constants.deviationCategory].ToString(),
                            Deviation_Planned  = dr[Constants.deviationPlanned].ToString(),
                            Deviation_Protocol_Section_Reference  = dr[Constants.sectionReference].ToString(),
                            Deviation_Date_Signed = GetUTCDate(dr[Constants.deviationDateSigned].ToString()),
                            Deviation_Signed_By  = dr[Constants.deviationSignedBy].ToString(),
                            Deviation_Comments  = dr[Constants.deviationComments].ToString(),
                            Send_Notification_to_Investigator  = dr[Constants.sendNotificationtoInvestigator].ToString(),
                            New_Comment  = dr[Constants.newComment].ToString(),
                            Resolution  = dr[Constants.resolution].ToString(),

                        });
                    }
                    ds.Dispose();
                    return rows;
                }
            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, Constants.functNameGetSAEDetails, Constants.classNameDAL, EventLogEntryType.Error);
            }
            return null;
        }
        public List<ActionItems> GetActionItems()
        {
            try
            {
                DateTime startDateTime = System.DateTime.Now;
                SqlParameter[] paramArray = new SqlParameter[1];
                string userName = string.Empty;
                if (SPContext.Current != null)
                {
                    var user=SharePointHelper.GetSharePointUserName(SPContext.Current.Web.CurrentUser);
                    var username=user.Split('\\');
                    if (username.Length > 1)
                        userName = username[1];
                    else
                        userName = user;
                }
                
                paramArray[0] = new SqlParameter(Constants.sqlParamUserName, userName);
                
                DataSet ds = CallStoreProc(Constants.spGetActionItems, paramArray);
               
                if (ds != null)
                {
                    List<ActionItems> rows = new List<ActionItems>();
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        rows.Add(new ActionItems()
                        {
                            Task_Name = dr[Constants.taskName].ToString(),
                            ID = dr[Constants.id].ToString(),
                            Action_Item_Deviation_Number = dr[Constants.actionItemDeviationNumber].ToString(),
                            Start_Date = GetUTCDate(dr[Constants.startDate].ToString()),
                            Due_Date = GetUTCDate(dr[Constants.dueDate].ToString()),
                            Assigned_To = dr[Constants.assignedTo].ToString(),
                            Assigned_To_Id = dr[Constants.assignedToId].ToString(),
                            Status = dr[Constants.percentComplete].ToString(),
                            Description = dr[Constants.description].ToString(),
                            Action_Item_Deviation_Category = dr[Constants.actionItemDeviationCategory].ToString(),
                            Action_Item_Created_By = dr[Constants.actionItemCreatedBy].ToString(),
                            Linked_Study = dr[Constants.linkedStudy].ToString(),
                            Linked_Site = dr[Constants.linkedSite].ToString(),
                            Linked_Visit = dr[Constants.linkedMonitoringVisit].ToString(),
                            AIRRecs_Linked_Visit = dr[Constants.linkedVisitID].ToString(),
                            Linked_Assigned_Monitor = dr[Constants.linkedAssignedMonitor].ToString()                                    
                        });
                    }
                    ds.Dispose();
                    log.WriteInfoToTextFile((System.DateTime.Now - startDateTime).ToString(), Constants.functNameGetActionItems, Constants.classNameDAL, EventLogEntryType.Information);
                    return rows;
                }

            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, Constants.functNameGetActionItems, Constants.classNameDAL, EventLogEntryType.Error);
            }
            return null;
        }
        public List<SiteVisit> GetSiteVisit()
        {
            try
            {
                SqlParameter[] paramArray = new SqlParameter[1];
                string userName = string.Empty;
                if (SPContext.Current != null)
                {
                    var user = SharePointHelper.GetSharePointUserName(SPContext.Current.Web.CurrentUser);
                    var username = user.Split('\\');
                    if (username.Length > 1)
                        userName = username[1];
                    else
                        userName = user;
                }

                paramArray[0] = new SqlParameter(Constants.sqlParamUserName, userName);
                DataSet ds = CallStoreProc(Constants.spGetSiteVisits, paramArray);
                if (ds != null)
                {
                    List<SiteVisit> rows = new List<SiteVisit>();
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        rows.Add(new SiteVisit()
                        {
                            Title = dr[Constants.title].ToString(),
                            ID = dr[Constants.id].ToString(),
                            Start_Date = GetUTCDate(dr[Constants.startDate].ToString()),
                            End_Date = GetUTCDate(dr[Constants.endDate].ToString()),
                            Assigned_To = dr[Constants.assignedTo].ToString(),
                            All_Day_Event = dr[Constants.allDayEvent].ToString(),
                            Monitoring_Visit_Number = dr[Constants.monitoringVisitNumber].ToString(),
                            Monitoring_Visit_status = dr[Constants.monitoringVisitStatus].ToString(),
                            Visit_Type = dr[Constants.visitType].ToString(),
                            Linked_Study = dr[Constants.linkedStudy].ToString(),
                            Linked_Site = dr[Constants.linkedSite].ToString(),
                            Linked_Monitor = dr[Constants.linkedAssignedMonitor].ToString(),
                            Location = dr[Constants.Location].ToString()
                        });
                    }
                    ds.Dispose();
                    return rows;
                }

            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, Constants.functNameGetSiteVisit, Constants.classNameDAL, EventLogEntryType.Error);
            }
            return null;
        }
        public List<Site> GetSites(string studyId)
        {
            try
            {
                SqlParameter[] paramArray = new SqlParameter[2];
                string userName = string.Empty;
                if (SPContext.Current != null)
                {
                    var user = SharePointHelper.GetSharePointUserName(SPContext.Current.Web.CurrentUser);
                    var username = user.Split('\\');
                    if (username.Length > 1)
                        userName = username[1];
                    else
                        userName = user;
                }

                paramArray[0] = new SqlParameter(Constants.sqlParamUserName, userName);
                paramArray[1] = new SqlParameter(Constants.sqlParamStudyId, studyId);
                
                DataSet ds = CallStoreProc(Constants.spGetSites, paramArray);
                if (ds != null)
                {
                    List<Site> rows = new List<Site>();
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        rows.Add(new Site()
                        {
                            ID = dr[Constants.SiteID].ToString(),
                            SiteNo = dr[Constants.SiteNo].ToString()
                        });
                    }
                    ds.Dispose();
                    return rows;
                }

            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, Constants.functNameGetSites, Constants.classNameDAL, EventLogEntryType.Error);
            }
            return null;
        }
        public List<Study> GetStudies()
        {
            try
            {
                SqlParameter[] paramArray = new SqlParameter[1];
                string userName = string.Empty;
                if (SPContext.Current != null)
                {
                    var user = SharePointHelper.GetSharePointUserName(SPContext.Current.Web.CurrentUser);
                    var username = user.Split('\\');
                    if (username.Length > 1)
                        userName = username[1];
                    else
                        userName = user;
                }

                paramArray[0] = new SqlParameter(Constants.sqlParamUserName, userName);
                
                DataSet ds = CallStoreProc(Constants.spGetStudies, paramArray);
                if (ds != null)
                {
                    List<Study> rows = new List<Study>();
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        rows.Add(new Study()
                        {
                            ID = dr[Constants.StudyObjectId].ToString(),
                            StudyNo = dr[Constants.StudyStudyNo].ToString()
                        });
                    }
                    ds.Dispose();
                    return rows;
                }

            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, Constants.functNameGetStudies, Constants.classNameDAL, EventLogEntryType.Error);
            }
            return null;
        }
        public List<UserDetails> GetOnpointUser()
        {
            try
            {
                SqlParameter[] paramArray = new SqlParameter[1];
                string userName = string.Empty;
                if (SPContext.Current != null)
                {
                    var user = SharePointHelper.GetSharePointUserName(SPContext.Current.Web.CurrentUser);
                    var username = user.Split('\\');
                    if (username.Length > 1)
                        userName = username[1];
                    else
                        userName = user;
                }

                paramArray[0] = new SqlParameter(Constants.sqlParamUserName, userName);

                DataSet ds = CallStoreProc(Constants.spGetUserGUID, paramArray);
                if (ds != null)
                {
                    List<UserDetails> rows = new List<UserDetails>();
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        rows.Add(new UserDetails()
                        {
                            ID = dr[Constants.id].ToString(),
                            OnpointUserName = dr[Constants.userName].ToString()
                        });
                    }
                    if (rows.Count > 0)
                    {
                        SqlParameter[] paramArrayInsert = new SqlParameter[2];

                        paramArrayInsert[0] = new SqlParameter(Constants.sqlParamUserName, rows[0].OnpointUserName);
                        paramArrayInsert[1] = new SqlParameter(Constants.sqlParamAccountId, rows[0].ID);

                        int rowCount = ExecuteNonQuery(Constants.spInsertMobileUser, paramArrayInsert);
                    }
                    ds.Dispose();
                    return rows;
                }

            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, Constants.functNameGetOnpointUser, Constants.classNameDAL, EventLogEntryType.Error);
            }
            return null;
            //string resp = string.Empty;
            //string userName = string.Empty;
            //if (SPContext.Current != null)
            //{
            //    var user = SharePointHelper.GetSharePointUserName(SPContext.Current.Web.CurrentUser);
            //    var username = user.Split('\\');
            //    if (username.Length > 1)
            //        userName = username[1];
            //    else
            //        userName = user;
            //}
            //SPSecurity.RunWithElevatedPrivileges(delegate
            //{
            //    string connString = SharePointHelper.GetOnPointServiceURL();
            //    connString = connString.Remove(connString.LastIndexOf('/'));
            //    HttpWebRequest GETRequest = (HttpWebRequest)WebRequest.Create(connString + "/" + "onpointservice.svc/getonpointaccount?username=" + userName);
            //    GETRequest.Method = "GET";
            //    GETRequest.Credentials = CredentialCache.DefaultCredentials;
            //    HttpWebResponse GETResponse = (HttpWebResponse)GETRequest.GetResponse();
            //    Stream stream = GETResponse.GetResponseStream();
            //    using (var reader = new StreamReader(stream, Encoding.UTF8))
            //    {
            //        resp = reader.ReadToEnd();
            //        // Do something with the value
            //    }
            //});
            //return resp;
        }
        public APIResponse UpdateActionItem(ActionItems item)
        {
            Guid guid;
            APIResponse response = new APIResponse();
            try
            {
                if (item == null)
                {
                    throw new Exception(string.Format(Constants.invalidRequest));
                }
                else if (string.IsNullOrEmpty(item.ID))
                {
                    throw new Exception(string.Format(Constants.nullOrEmptyString, Constants.id));
                }
                else if (string.IsNullOrEmpty(item.Description))
                {
                    throw new Exception(string.Format(Constants.nullOrEmptyString, Constants.description));
                }
                else if (string.IsNullOrEmpty(item.Status))
                {
                    throw new Exception(string.Format(Constants.nullOrEmptyString, Constants.classVarPercentComplete));
                }
                int MaxPageSize = 250;
                string responseData = string.Empty;
                string connString = string.Empty;
                DataRow row = null;
                var authenticationType = Helper.GetAuthenticationType(SPContext.Current.Site.WebApplication);
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    connString = SharePointHelper.GetOnPointServiceURL();
                
                connString = connString.Remove(connString.LastIndexOf('/'));
                //var authenticationType = Helper.GetAuthenticationType(SPContext.Current.Site.WebApplication);
                SourceSession session = this.CreateSourceSession(new Uri(connString + "/" + Constants.actionItemServiceName), authenticationType);

                //ISource.SourceClient SourceClient = new ISource.SourceClient();
                //SourceClient.Endpoint.Address = new EndpointAddress(connString+'/'
                //                                                  + ConfigurationManager.AppSettings[Constants.actionItemServiceName].ToString());
                SourceService.FilterContext filterContext = new SourceService.FilterContext { };
                SourceService.QueryArguments queryArguments = new SourceService.QueryArguments();

                TableFilter filterbyId = new TableFilter();
                filterbyId.Add(new TableFilterItem()
                {
                    ColumnName = "ID",
                    Operation = FilterOperation.Equal,
                    Value = item.ID
                });

                queryArguments.Filter =  filterbyId ;
                //SourceService.SourceClient request = new SourceService.SourceClient();
                //GetItemsRequest request = new GetItemsRequest(filterContext, queryArguments, 0, MaxPageSize);
                DataSet dataSetGetItems = session.Client.GetItems(filterContext, queryArguments, 0, MaxPageSize);
                //DataSet dataSetGetItems = session.Client.GetItems(request).GetItemsResult;//(filterContext2, queryArguments2, 0, MaxPageSize);
                //DataSet dataSetGetItems = SourceClient.GetItems(filterContext, queryArguments, 0, MaxPageSize);
                string filter = string.Format(Constants.filterID, item.ID);
                row = dataSetGetItems.Tables[0].Select(filter)[0];
                if (row == null)
                {
                    throw new Exception(Constants.recordNotFound);
                }
                row[Constants.aiText] = item.Description;
                row[Constants.complRate] = item.Status;
                });
                SourceSession session2 = this.CreateSourceSession(new Uri(connString + "/" + Constants.actionItemServiceName), authenticationType);
                
                //GetSchemaRequest schemarequest = new GetSchemaRequest();
                DataSet dataSet = session2.Client.GetSchema();//(filterContext2, queryArguments2, 0, MaxPageSize);//(schemarequest).GetSchemaResult;
                dataSet.Tables[0].Rows.Add(row.ItemArray);

                // Update

                //UpdateItemRequest updateRequest = new UpdateItemRequest(dataSet);// SourceClient.UpdateItem(dataSet);
                guid = session2.Client.UpdateItem(dataSet);//(updateRequest).UpdateItemResult;//(filterContext2, queryArguments2, 0, MaxPageSize);

                response.success = Constants.stringTrue; response.result = guid.ToString();
            }
            catch (Exception ex)
            {
                response.success = Constants.stringFalse; response.errorMessage = ex.Message;
                log.WriteInfoToTextFile(ex.Message, Constants.functNameUpdateActionItem, Constants.classNameDAL, EventLogEntryType.Error);
            }
            return response;
        }
        public APIResponse UpdateSiteVisit(SiteVisit item)
        {
            Guid guid;
            APIResponse response = new APIResponse();
            try
            {
                if (item == null)
                {
                    throw new Exception(string.Format(Constants.invalidRequest));
                }
                else if (string.IsNullOrEmpty(item.ID))
                {
                    throw new Exception(string.Format(Constants.nullOrEmptyString, Constants.id));
                }
                else if (string.IsNullOrEmpty(item.Start_Date))
                {
                    throw new Exception(string.Format(Constants.nullOrEmptyString, Constants.classVarStartDate));
                }
                else if (string.IsNullOrEmpty(item.End_Date))
                {
                    throw new Exception(string.Format(Constants.nullOrEmptyString, Constants.classVarEndDate));
                }
                int MaxPageSize = 250;
                string responseData = string.Empty;
                string connString = string.Empty;
                var authenticationType = Helper.GetAuthenticationType(SPContext.Current.Site.WebApplication);
                DataRow row = null;
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    connString = SharePointHelper.GetOnPointServiceURL();
                
                connString = connString.Remove(connString.LastIndexOf('/'));

                
                SourceSession session = this.CreateSourceSession(new Uri(connString + "/" + Constants.siteVisitServiceName), authenticationType);

                //ISource.SourceClient SourceClient = new ISource.SourceClient();
                //SourceClient.Endpoint.Address = new EndpointAddress(connString+'/'
                //                                                  + ConfigurationManager.AppSettings[Constants.actionItemServiceName].ToString());
                SourceService.FilterContext filterContext = new SourceService.FilterContext { };
                SourceService.QueryArguments queryArguments = new SourceService.QueryArguments();

                TableFilter filterbyId = new TableFilter();
                filterbyId.Add(new TableFilterItem()
                {
                    ColumnName = "ID",
                    Operation = FilterOperation.Equal,
                    Value = item.ID
                });
                queryArguments.Filter = filterbyId;
                //GetItemsRequest request = new GetItemsRequest(filterContext, queryArguments, 0, MaxPageSize);
                DataSet dataSetGetItems = session.Client.GetItems(filterContext, queryArguments, 0, MaxPageSize); ;//(request).GetItemsResult;//(filterContext2, queryArguments2, 0, MaxPageSize);
                //DataSet dataSetGetItems = SourceClient.GetItems(filterContext, queryArguments, 0, MaxPageSize);
                string filter = string.Format(Constants.filterID, item.ID);
                row = dataSetGetItems.Tables[0].Select(filter)[0];
                if (row == null)
                {
                    throw new Exception(Constants.recordNotFound);
                }
                row[Constants.clinbusParamStartDate] = GetDateTime(item.Start_Date);
                row[Constants.clinbusParamEndDate] = GetDateTime(item.End_Date);
                });
                SourceSession session2 = this.CreateSourceSession(new Uri(connString + "/" + Constants.siteVisitServiceName), authenticationType);

                //GetSchemaRequest schemarequest = new GetSchemaRequest();
                DataSet dataSet = session2.Client.GetSchema();// (schemarequest).GetSchemaResult;//(filterContext2, queryArguments2, 0, MaxPageSize);
                dataSet.Tables[0].Rows.Add(row.ItemArray);

                // Update
                //UpdateItemRequest updateRequest = new UpdateItemRequest(dataSet);// SourceClient.UpdateItem(dataSet);
                guid = session2.Client.UpdateItem(dataSet);//(updateRequest).UpdateItemResult;//(filterContext2, queryArguments2, 0, MaxPageSize);
                
                response.success = Constants.stringTrue; response.result = guid.ToString();
            }
            catch (Exception ex)
            {
                response.success = Constants.stringFalse; response.errorMessage = ex.Message;
                log.WriteInfoToTextFile(ex.Message, Constants.functNameUpdateSiteVisit, Constants.classNameDAL, EventLogEntryType.Error);
                //throw ex;
            }
            return response;
        }
        public APIResponse UpdateProtocolDeviation(ProtocolDeviation item)
        {
            Guid guid;
            APIResponse response = new APIResponse();
            try
            {
                if (item == null)
                {
                    throw new Exception(string.Format(Constants.invalidRequest));
                }
                else if (string.IsNullOrEmpty(item.ID))
                {
                    throw new Exception(string.Format(Constants.nullOrEmptyString, Constants.id));
                }
                //else if (item.New_Comment == null)
                //{
                //    throw new Exception(string.Format(Constants.nullValue, Constants.classVarNewComment));
                //}
                //else if (item.Resolution == null)
                //{
                //    throw new Exception(string.Format(Constants.nullValue, Constants.classVarResolution));
                //}
                int MaxPageSize = 250;
                string responseData = string.Empty;
                string connString = string.Empty;
                DataRow row = null;
                var authenticationType = Helper.GetAuthenticationType(SPContext.Current.Site.WebApplication);
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    connString = SharePointHelper.GetOnPointServiceURL();
                
                connString = connString.Remove(connString.LastIndexOf('/'));

                
                SourceSession session = this.CreateSourceSession(new Uri(connString + "/" + Constants.ProtocolDeviationServiceName), authenticationType);

                //ISource.SourceClient SourceClient = new ISource.SourceClient();
                //SourceClient.Endpoint.Address = new EndpointAddress(connString+'/'
                //                                                  + ConfigurationManager.AppSettings[Constants.actionItemServiceName].ToString());
                SourceService.FilterContext filterContext = new SourceService.FilterContext { };
                SourceService.QueryArguments queryArguments = new SourceService.QueryArguments();

                TableFilter filterbyId = new TableFilter();
                filterbyId.Add(new TableFilterItem()
                {
                    ColumnName = "ID",
                    Operation = FilterOperation.Equal,
                    Value = item.ID
                });
                queryArguments.Filter = filterbyId;
                //GetItemsRequest request = new GetItemsRequest(filterContext, queryArguments, 0, MaxPageSize);
                DataSet dataSetGetItems = session.Client.GetItems(filterContext, queryArguments, 0, MaxPageSize); ;// (request).GetItemsResult;//(filterContext2, queryArguments2, 0, MaxPageSize);
                //DataSet dataSetGetItems = SourceClient.GetItems(filterContext, queryArguments, 0, MaxPageSize);
                string filter = string.Format(Constants.filterID, item.ID);
                row = dataSetGetItems.Tables[0].Select(filter)[0];
                if (row == null)
                {
                    throw new Exception(Constants.recordNotFound);
                }
                row[Constants.clinBUSParamNewComment] = item.New_Comment;
                row[Constants.resolution] = item.Resolution;
                });
                SourceSession session2 = this.CreateSourceSession(new Uri(connString + "/" + Constants.ProtocolDeviationServiceName), authenticationType);

                //GetSchemaRequest schemarequest = new GetSchemaRequest();
                DataSet dataSet = session2.Client.GetSchema();// (schemarequest).GetSchemaResult;//(filterContext2, queryArguments2, 0, MaxPageSize);
                dataSet.Tables[0].Rows.Add(row.ItemArray);

                // Update
                //UpdateItemRequest updateRequest = new UpdateItemRequest(dataSet);// SourceClient.UpdateItem(dataSet);
                guid = session2.Client.UpdateItem(dataSet);// (updateRequest).UpdateItemResult;//(filterContext2, queryArguments2, 0, MaxPageSize);

                response.success = Constants.stringTrue; response.result = guid.ToString();
            }
            catch (Exception ex)
            {
                response.success = Constants.stringFalse; response.errorMessage = ex.Message;
                log.WriteInfoToTextFile(ex.Message, Constants.functNameUpdateSiteVisit, Constants.classNameDAL, EventLogEntryType.Error);
            }
            return response;
        }
        public APIResponse UpdateSAEDetail(SAEDetails item)
        {
            Guid guid;
            APIResponse response = new APIResponse();
            try
            {
                if (item == null)
                {
                    throw new Exception(string.Format(Constants.invalidRequest));
                }
                else if (string.IsNullOrEmpty(item.ID))
                {
                    throw new Exception(string.Format(Constants.nullOrEmptyString, Constants.id));
                }
                //else if (string.IsNullOrWhiteSpace(item.SAE_Comments))
                //{
                //    throw new Exception(string.Format(Constants.nullOrEmptyString, Constants.classVarSAEComments));
                //}

                int MaxPageSize = 250;
                string responseData = string.Empty;
                string connString = string.Empty;
                DataRow row = null;
                var authenticationType = Helper.GetAuthenticationType(SPContext.Current.Site.WebApplication);
                SPSecurity.RunWithElevatedPrivileges(delegate
                {
                    connString = SharePointHelper.GetOnPointServiceURL();
                
                connString = connString.Remove(connString.LastIndexOf('/'));

                
                SourceSession session = this.CreateSourceSession(new Uri(connString + "/" + Constants.saeDetailsServiceName), authenticationType);

                //ISource.SourceClient SourceClient = new ISource.SourceClient();
                //SourceClient.Endpoint.Address = new EndpointAddress(connString+'/'
                //                                                  + ConfigurationManager.AppSettings[Constants.actionItemServiceName].ToString());
                SourceService.FilterContext filterContext = new SourceService.FilterContext { };
                SourceService.QueryArguments queryArguments = new SourceService.QueryArguments();

                TableFilter filterbyId = new TableFilter();
                filterbyId.Add(new TableFilterItem()
                {
                    ColumnName = "ID",
                    Operation = FilterOperation.Equal,
                    Value = item.ID
                });
                queryArguments.Filter = filterbyId;
                //GetItemsRequest request = new GetItemsRequest(filterContext, queryArguments, 0, MaxPageSize);
                DataSet dataSetGetItems = session.Client.GetItems(filterContext, queryArguments, 0, MaxPageSize);//(request).GetItemsResult;//(filterContext2, queryArguments2, 0, MaxPageSize);
                //DataSet dataSetGetItems = SourceClient.GetItems(filterContext, queryArguments, 0, MaxPageSize);
                string filter = string.Format(Constants.filterID, item.ID);
                row = dataSetGetItems.Tables[0].Select(filter)[0];
                if (row == null)
                {
                    throw new Exception(Constants.recordNotFound);
                }
                row[Constants.clinBUSParamComments] = item.SAE_Comments;
                });
                SourceSession session2 = this.CreateSourceSession(new Uri(connString + "/" + Constants.saeDetailsServiceName), authenticationType);

                //GetSchemaRequest schemarequest = new GetSchemaRequest();
                DataSet dataSet = session2.Client.GetSchema();//(schemarequest).GetSchemaResult;//(filterContext2, queryArguments2, 0, MaxPageSize);
                dataSet.Tables[0].Rows.Add(row.ItemArray);

                // Update
                //UpdateItemRequest updateRequest = new UpdateItemRequest(dataSet);// SourceClient.UpdateItem(dataSet);
                guid = session2.Client.UpdateItem(dataSet);//(updateRequest).UpdateItemResult;//(filterContext2, queryArguments2, 0, MaxPageSize);

                response.success = Constants.stringTrue; response.result = guid.ToString();
            }
            catch (Exception ex)
            {
                response.success = Constants.stringFalse; response.errorMessage = ex.Message;
                log.WriteInfoToTextFile(ex.Message, Constants.functNameUpdateSAEDetail, Constants.classNameDAL, EventLogEntryType.Error);
            }
            return response;
        }
        public APIResponse Logout()
        {
            //string guid = null;
            APIResponse response = new APIResponse();
            try
            {
                SqlParameter[] paramArray = new SqlParameter[1];
                string userName = string.Empty;
                if (SPContext.Current != null)
                {
                    var user = SharePointHelper.GetSharePointUserName(SPContext.Current.Web.CurrentUser);
                    var username = user.Split('\\');
                    if (username.Length > 1)
                        userName = username[1];
                    else
                        userName = user;
                }

                paramArray[0] = new SqlParameter(Constants.sqlParamUserName, userName);
                int rowCount = ExecuteNonQuery(Constants.spLogoutMobileUser, paramArray);
                response.success = Constants.stringTrue; response.result = Constants.stringTrue;
            }
            catch (Exception ex)
            {
                response.success = Constants.stringFalse; response.errorMessage = ex.Message;
                log.WriteInfoToTextFile(ex.Message, Constants.functNameUpdateSAEDetail, Constants.classNameDAL, EventLogEntryType.Error);
            }
            return response;
        }
        DataSet CallStoreProc(string procName, SqlParameter[] paramArray)
        {
            
            SqlConnection conn = null;
            SqlCommand cmd = null;
            DataSet ds = null;
            SqlDataAdapter dad = null;
            try
            {
                //if (String.IsNullOrEmpty(ConnectionHelper.connectionString))
                //{
                //    Helperclass helperclass = new Helperclass();
                //    ConnectionHelper.connectionString = helperclass.createconnection();
                //}
                //Helperclass helperclass = new Helperclass();
                //connString = helperclass.createconnection();
                SPSecurity.RunWithElevatedPrivileges(delegate
                { 
                    
                    //string user = SPContext.Current.Web.CurrentUser.Email+"|";
                    //user += SPContext.Current.Web.CurrentUser.ID.ToString()+"|";
                    //user += SPContext.Current.Web.CurrentUser.Name + "|";
                    //user += SPContext.Current.Web.CurrentUser.LoginName + "|";
                    //user += SPContext.Current.Web.CurrentUser.UserId.NameId + "|";
                    //File.AppendAllText(System.Configuration.ConfigurationManager.AppSettings["LogFilePath"], user);
                    if (!string.IsNullOrEmpty(connString))
                    {
                        conn = new SqlConnection(connString);
                        cmd = new SqlCommand();
                        ds = new DataSet();
                        cmd.Connection = conn;

                        if (paramArray != null && paramArray.Length != 0)
                        {
                            foreach (var array in paramArray)
                            {
                                cmd.Parameters.Add(array);
                            }
                        }
                        cmd.CommandText = procName;
                        cmd.CommandType = CommandType.StoredProcedure;
                        dad = new SqlDataAdapter();
                        dad.SelectCommand = cmd;
                        dad.Fill(ds);
                    }
                });
            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, Constants.functNameCallStoreProc, Constants.classNameDAL, EventLogEntryType.Error);
            }
            finally
            {
                conn.Dispose();
                cmd.Dispose();
                dad.Dispose();
                
            }
            return ds;
        }
        public int ExecuteNonQuery(string procName, SqlParameter[] paramArray)
        {
            SqlConnection conn = null;
            SqlCommand cmd = null;
            int rowsAffected = 0;
            try
            {
                SPSecurity.RunWithElevatedPrivileges(delegate
               {
                   if (!string.IsNullOrEmpty(connString))
                   {
                       conn = new SqlConnection(connString);
                       cmd = new SqlCommand();
                       cmd.Connection = conn;
                       if (paramArray != null && paramArray.Length != 0)
                       {
                           foreach (var array in paramArray)
                           {
                               cmd.Parameters.Add(array);
                           }
                       }
                       cmd.CommandText = procName;
                       cmd.CommandType = CommandType.StoredProcedure;
                       conn.Open();
                       rowsAffected = cmd.ExecuteNonQuery();
                       conn.Close();
                   }
               });
            }
            catch (Exception ex)
            {
                log.WriteInfoToTextFile(ex.Message, Constants.functNameCallStoreProc, Constants.classNameDAL, EventLogEntryType.Error);
            }
            finally
            {
                conn.Dispose();
                cmd.Dispose();
            }
            return rowsAffected;
        }
        private SourceSession CreateSourceSession(Uri sourceuri, MobileAppWCF.HelperClasses.Helper.AuthenticationType authenticationType)
        {
            return new SourceSessionFactory(authenticationType)
                .CreateSourceSession(sourceuri);
        }
        private string GetUTCDate(string date)
        {
            if(!string.IsNullOrEmpty(date))
            {
                return Convert.ToDateTime(date).ToString("u").Replace(" ", "T");
            }
            else
            {
                return string.Empty;
            }
        }
        private string GetDateTime(string date)
        {
            if (!string.IsNullOrEmpty(date))
            {
                return date.Replace("T", " ").Replace("Z"," ");
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
