﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MobileAppWCF.Models
{
    public class Study
    {
        public string StudyNo { get; set; }
        public string ID { get; set; }
    }
}