﻿using System;
using System.Collections.Generic;
using System.Data.Services.Common;
using System.Linq;
using System.Text;


namespace MobileAppWCF.Models
{
    [DataServiceKeyAttribute("ID")]
    public class ProtocolDeviation
    {
        public string Title { get; set; }
        public string ID { get; set; }
        public string Modified_Date { get; set; }
        public string Linked_Site { get; set; }
        public string Linked_Study { get; set; }
        public string Linked_Visit { get; set; }
        public string Linked_Screening { get; set; }
        public string Deviation_Number { get; set; }
        public string Deviation_Date { get; set; }
        public string Description { get; set; }
        public string Deviation_Submitted_to_IRB { get; set; }
        public string Deviation_CRA_Reviewer { get; set; }
        public string Deviation_Category { get; set; }
        public string Deviation_Planned { get; set; }
        public string Deviation_Protocol_Section_Reference { get; set; }
        public string Deviation_Date_Signed { get; set; }
        public string Deviation_Signed_By { get; set; }
        public string Deviation_Comments { get; set; }
        public string Send_Notification_to_Investigator { get; set; }
        public string New_Comment { get; set; }
        public string Resolution { get; set; }
    }
}
